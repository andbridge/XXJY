// /* ���� */

// $(function () {
//     $("#picx").click(function () {
//         $("#uploadx").click(); //������input:file��ʽ�󣬵��ͷ��Ϳ��Ա����ϴ�

//         $("#uploadx").on("change", function () {
//             var objUrl = getObjectURL(this.files[0]); //��ȡͼƬ��·������·������ͼƬ�ڱ��ص�·��
//             if (objUrl) {
//                 $("#picx").attr("src", objUrl); //��ͼƬ·������src�У���ʾ��ͼƬ
//             }
//         });
//     });
// });
// //����һ���ɴ�ȡ��ԓfile��url
// function getObjectURL(file) {
//     var url = null;
//     if (window.createObjectURL != undefined) { //basic
//         url = window.createObjectURL(file);
//     } else if (window.URL != undefined) { //mozilla(firefox)
//         url = window.URL.createObjectURL(file);
//     } else if (window.webkitURL != undefined) { //webkit or chrome
//         url = window.webkitURL.createObjectURL(file);
//     }
//     return url;
// }







// /* ���� */
// $(function () {
//     $("#picp").click(function () {
//         $("#uploadp").click(); //������input:file��ʽ�󣬵��ͷ��Ϳ��Ա����ϴ�

//         $("#uploadp").on("change", function () {
//             var objUrl = getObjectURL(this.files[0]); //��ȡͼƬ��·������·������ͼƬ�ڱ��ص�·��
//             if (objUrl) {
//                 $("#picp").attr("src", objUrl); //��ͼƬ·������src�У���ʾ��ͼƬ
//             }
//         });
//     });
// });
// //����һ���ɴ�ȡ��ԓfile��url
// function getObjectURL(file) {
//     var url = null;
//     if (window.createObjectURL != undefined) { //basic
//         url = window.createObjectURL(file);
//     } else if (window.URL != undefined) { //mozilla(firefox)
//         url = window.URL.createObjectURL(file);
//     } else if (window.webkitURL != undefined) { //webkit or chrome
//         url = window.webkitURL.createObjectURL(file);
//     }
//     return url;
// }


// /* ���� */
// $(function () {
//     $("#picn").click(function () {
//         $("#uploadn").click(); //������input:file��ʽ�󣬵��ͷ��Ϳ��Ա����ϴ�

//         $("#uploadn").on("change", function () {
//             var objUrl = getObjectURL(this.files[0]); //��ȡͼƬ��·������·������ͼƬ�ڱ��ص�·��
//             if (objUrl) {
//                 $("#picn").attr("src", objUrl); //��ͼƬ·������src�У���ʾ��ͼƬ
//             }
//         });
//     });
// });
// //����һ���ɴ�ȡ��ԓfile��url
// function getObjectURL(file) {
//     var url = null;
//     if (window.createObjectURL != undefined) { //basic
//         url = window.createObjectURL(file);
//     } else if (window.URL != undefined) { //mozilla(firefox)
//         url = window.URL.createObjectURL(file);
//     } else if (window.webkitURL != undefined) { //webkit or chrome
//         url = window.webkitURL.createObjectURL(file);
//     }
//     return url;
// }


/* ���� */
$("#picx").click(function () {
	 $("#uploadx").click();
	 $("#uploadx").on("change", function () {
	             var objUrl = getObjectURL(this.files[0]); //��ȡͼƬ��·������·������ͼƬ�ڱ��ص�·��
	             if (objUrl) {
	                 $("#picx").attr("src", objUrl); //��ͼƬ·������src�У���ʾ��ͼƬ
	             }
	         });
function fileCountCheck(obj){
 if (obj.files && obj.files[0]) {
                    var FR = new FileReader();
                    FR.onload = function (e) {
                        var ImageString = e.target.result;
                       //���ImageString ����ͼƬת�ɵ�base64�ַ���
                    };
                    FR.readAsDataURL(obj.files[0]);
                }
}
})



function getObjectURL(file) {
    var url = null;
    if (window.createObjectURL != undefined) { //basic
        url = window.createObjectURL(file);
    } else if (window.URL != undefined) { //mozilla(firefox)
        url = window.URL.createObjectURL(file);
    } else if (window.webkitURL != undefined) { //webkit or chrome
        url = window.webkitURL.createObjectURL(file);
    }
    return url;
}

/* ���� */


$("#picp").click(function () {
	 $("#uploadp").click();
	 $("#uploadp").on("change", function () {
	             var objUrl = getObjectURL(this.files[0]); //��ȡͼƬ��·������·������ͼƬ�ڱ��ص�·��
	             if (objUrl) {
	                 $("#picp").attr("src", objUrl); //��ͼƬ·������src�У���ʾ��ͼƬ
	             }
	         });
function fileCountCheck(obj){
 if (obj.files && obj.files[0]) {
                    var FR = new FileReader();
                    FR.onload = function (e) {
                        var ImageString = e.target.result;
                       //���ImageString ����ͼƬת�ɵ�base64�ַ���
                    };
                    FR.readAsDataURL(obj.files[0]);
                }
}
})


//����һ���ɴ�ȡ��ԓfile��url
function getObjectURL(file) {
    var url = null;
    if (window.createObjectURL != undefined) { //basic
        url = window.createObjectURL(file);
    } else if (window.URL != undefined) { //mozilla(firefox)
        url = window.URL.createObjectURL(file);
    } else if (window.webkitURL != undefined) { //webkit or chrome
        url = window.webkitURL.createObjectURL(file);
    }
    return url;
}

/* ���� */


$("#picn").click(function () {
	 $("#uploadn").click();
	 $("#uploadn").on("change", function () {
	             var objUrl = getObjectURL(this.files[0]); //��ȡͼƬ��·������·������ͼƬ�ڱ��ص�·��
	             if (objUrl) {
	                 $("#picn").attr("src", objUrl); //��ͼƬ·������src�У���ʾ��ͼƬ
	             }
	         });
function fileCountCheck(obj){
 if (obj.files && obj.files[0]) {
                    var FR = new FileReader();
                    FR.onload = function (e) {
                        var ImageString = e.target.result;
                       //���ImageString ����ͼƬת�ɵ�base64�ַ���
                    };
                    FR.readAsDataURL(obj.files[0]);
                }
}
})


//����һ���ɴ�ȡ��ԓfile��url
function getObjectURL(file) {
    var url = null;
    if (window.createObjectURL != undefined) { //basic
        url = window.createObjectURL(file);
    } else if (window.URL != undefined) { //mozilla(firefox)
        url = window.URL.createObjectURL(file);
    } else if (window.webkitURL != undefined) { //webkit or chrome
        url = window.webkitURL.createObjectURL(file);
    }
    return url;
}


$("#pixs").click(function () {
	 $("#uploadxs").click();
	 $("#uploadxs").on("change", function () {
	             var objUrl = getObjectURL(this.files[0]); //��ȡͼƬ��·������·������ͼƬ�ڱ��ص�·��
	             if (objUrl) {
	                 $("#pixs").attr("src", objUrl); //��ͼƬ·������src�У���ʾ��ͼƬ
	             }
	         });
function fileCountCheck(obj){
 if (obj.files && obj.files[0]) {
                    var FR = new FileReader();
                    FR.onload = function (e) {
                        var ImageString = e.target.result;
                       //���ImageString ����ͼƬת�ɵ�base64�ַ���
                    };
                    FR.readAsDataURL(obj.files[0]);
                }
}
})


//����һ���ɴ�ȡ��ԓfile��url
function getObjectURL(file) {
    var url = null;
    if (window.createObjectURL != undefined) { //basic
        url = window.createObjectURL(file);
    } else if (window.URL != undefined) { //mozilla(firefox)
        url = window.URL.createObjectURL(file);
    } else if (window.webkitURL != undefined) { //webkit or chrome
        url = window.webkitURL.createObjectURL(file);
    }
    return url;
}

window.onload=function(){
	/* ��ť */
var ButtonZ=document.getElementsByClassName("ButtonZ");
	
	var addressss=document.getElementsByClassName("addressss")[0];
	
		ButtonZ[0].onclick=function(){
			var address=document.getElementById("address");
			ButtonZ[0].style.backgroundColor="#1dacfa";
			ButtonZ[0].checked=true;
			ButtonZ[1].style.backgroundColor="#ffffff"
			ButtonZ[1].checked=false;
			ButtonZ[2].style.backgroundColor="#FFFFFF"
			ButtonZ[2].checked=false;
			address.removeAttribute("disabled")
			addressss.style.display="block";
			address.style.backgroundColor="white";
			address.style.color="black";
			address.value="";
			// address.setAttribute("placeholder",'��������ϸ��ַ')
	};
	ButtonZ[1].onclick=function(){
		var address=document.getElementById("address");
			ButtonZ[1].style.backgroundColor="#1dacfa";
			ButtonZ[1].checked=true;
			ButtonZ[0].style.backgroundColor="#FFFFFF"
			ButtonZ[0].checked=false;
			ButtonZ[2].style.backgroundColor="#FFFFFF"
			ButtonZ[2].checked=false;
			address.setAttribute("disabled","disabled")
			address.style.backgroundColor="slategray";
			address.style.color="white";
			address.value='';
			addressss.style.display="none";
	}
	
	ButtonZ[2].onclick=function(){
		var address=document.getElementById("address");
			ButtonZ[1].style.backgroundColor="#FFFFFF";
			ButtonZ[1].checked=false;
			ButtonZ[0].style.backgroundColor="#FFFFFF"
			ButtonZ[0].checked=false;
			ButtonZ[2].style.backgroundColor="#1dacfa"
			ButtonZ[2].checked=true;
		address.setAttribute("disabled","disabled")
		address.style.backgroundColor="slategray";
		address.style.color="white";
		address.value='';
		addressss.style.display="none";
	}
};
































































// window.onload=function(){
// 	/* ��ť */
// 	var ButtonZ=document.getElementsByClassName("ButtonZ");
// 		ButtonZ[0].onclick=function(){
// 			ButtonZ[0].style.backgroundColor="#1dacfa";
// 			ButtonZ[0].checked=true;
// 			ButtonZ[1].style.backgroundColor="#ffffff"
// 			ButtonZ[1].checked=false;
// 	};
// 	ButtonZ[1].onclick=function(){
// 			ButtonZ[1].style.backgroundColor="#1dacfa";
// 			ButtonZ[1].checked=true;
// 			ButtonZ[0].style.backgroundColor="#FFFFFF"
// 			ButtonZ[0].checked=false;
// 	}
// };





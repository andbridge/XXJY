window.onload=function(){
	
	/* banner */
	var lunbotulist=document.getElementsByClassName("lunbotu");
	var list=document.getElementsByClassName("list");
	var index=0;
	for(var i=0;i < lunbotulist.length;i++){
		lunbotulist[i].className="lunbotu";
		list[i].style.background="whitesmoke";
		/* lunbotulist[i].style.display="none"; */
	}
	lunbotulist[index].className= lunbotulist[index].className + " LboC"; /* 0 1 2 3 0 1 2 3 */
	list[index].style.background="skyblue";
	/* lunbotulist[index].style.display="block"; */
	var time=setInterval(function(){
		if(index < lunbotulist.length-1){
			index++; /*-1 0 1 2 0 1 2 */   /* index=++index和index=index++的区别*/
		}else{
			index=0; /* 0 0 */
		}
		for(var i=0;i < lunbotulist.length;i++){
			lunbotulist[i].className="lunbotu";
			list[i].style.background="whitesmoke";
			/* lunbotulist[i].style.display="none"; */
		}
		lunbotulist[index].className= lunbotulist[index].className + " LboC"; /* 0 1 2 3 0 1 2 3 */
		list[index].style.background="skyblue";
		/* lunbotulist[index].style.display= "block"; */
	},2000);
	
	for(var j=0;j<list.length;j++){
		
		
		list[j].num=j;
		
		list[j].onclick=function(){
			var x=this.num;
		for(var i=0;i < lunbotulist.length;i++){
			list[i].style.background="whitesmoke";
			lunbotulist[i].className="lunbotu";
			/* lunbotulist[i].style.display="none"; */
		}
		list[x].style.backgroundColor="skyblue";
		list[x]=lunbotulist[x].className=lunbotulist[x].className + " LboC";
		/* list[x]=lunbotulist[x].style.display="block"; */
		};
	}
	
	
	
	
	/* 底部 */
	/* var tu=["img/首页-zhong.png"];
	var img=document.getElementsByClassName("img");
	var lisa=document.getElementsByClassName("lisa");
		lisa[0].onclick=function(){
			
			for(var u=0;u<img.length;u++){
				img.src="img/首页.png";
			}
			img[0].src=tu[0];
		}
	} */
};
window.onload=function(){
	var CountDownm=document.getElementById("CountDown");
	var endtime=15*60;
	setInterval(function(){
	endtime=endtime-1;
	if(endtime>0){
		var second=parseInt(endtime%60);
		var min=parseInt(endtime/60)
	if(second==0){
		var min=min--;
	}
	}else{
		window.location.assign("http://www.w3school.com.cn")
	}
		
	CountDownm.innerHTML=min+":"+second;
	if(min<10){
		CountDownm.innerHTML="0"+min+":"+second;
	}
	if(second<10){
		CountDownm.innerHTML=min+":"+"0"+second;
	}
	if(min<10 && second<10){
		CountDownm.innerHTML="0"+min+":"+"0"+second;
	}
	},1000)
        
                
	
};
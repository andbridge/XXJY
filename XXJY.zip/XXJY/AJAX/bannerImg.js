	var bannerFirst=document.getElementById("bannerFirst");
	var bannerSecond=document.getElementById("bannerSecond");
	var bannerthird=document.getElementById("bannerthird");
	
	var bannerFirstUrl=document.getElementById("bannerFirstUrl");
	var bannerSecondUrl=document.getElementById("bannerSecondUrl");
	var bannerthirdUrl=document.getElementById("bannerthirdUrl");
	Myajax("getbanner","GET","http://manage.woyaoxuexue.com/guns/app/getbanner",
	{
		
	},10000,function(msg){
		var bannerstr=msg.responseText;
		/* console.log(bannerstr); */
		var bannerobj=JSON.parse(bannerstr)
		/* var bannerobj=eval("("+bannerstr+")"); */
		console.log(bannerobj);
		var bannerLength=bannerobj.data.length;
		/* console.log(bannerLength); */
		for(var i=0;i<bannerLength;i++){
			var bannerImgFirst=bannerobj.data[0].picurl;
			var bannerImgSecond=bannerobj.data[1].picurl;
			var bannerImgthird=bannerobj.data[2].picurl;
			
			var bannerUrlFirst=bannerobj.data[0].piclink;
			var bannerUrlSecond=bannerobj.data[1].piclink;
			var bannerUrlthird=bannerobj.data[2].piclink;
			
		}
		
		console.log(bannerImgFirst);
		bannerFirst.src=bannerImgFirst
		bannerSecond.src=bannerImgSecond
		bannerthird.src=bannerImgthird
		
		bannerFirstUrl.href=bannerUrlFirst
		bannerSecondUrl.href=bannerUrlSecond
		bannerthirdUrl.href=bannerUrlthird
	},function(code){
		
	})
	
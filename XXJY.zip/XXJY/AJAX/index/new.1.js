///需要更改点击跳转的地址
var rows = 99;//每页数据条数
var page = 1;
var newstype;
var HTMLURL1="../Index/consulting.3.html";
var newsid;
//var maxpage;
//var orgId;
//$('#more').hide();
function allNews(){
				console.log("1");
				
				//数据获取
				$.ajax({
						async:false,//同步，异步
						url:"http://manage.woyaoxuexue.com/guns/app/getnewslist", //请求的服务端地址
						data:{
						"page":page,
						"newstype":1,
						"rows":rows,
						},
						type:"get",
						dataType:"json",
						beforeSend:function(){
						    $("#more").show();
						},
						
						success:function(data){
						
						console.log(data);
						
						//maxpage = data.data.navigateLastPage;
						//console.log(maxpage);
						var newsNum=data.data.list.length;
						//console.log(newsNum);//知道个数
						var i;
						for(i = 0;i < newsNum;i++){
							var newsTitle = data.data.list[i].title;
							var newsDate = data.data.list[i].create_date;
							var newsImg = data.data.list[i].newsimage;
							var newsUrl;
							newsid=data.data.list[i].newsid;
							var newsBox = "<div class=\"new"+i+"_1\"><a href=\""+HTMLURL1+"\" onclick=\"holdId("+newsid+")\" class=\"weui-cell weui-cell_access\" href=\""+newsUrl+"\"><div class=\"weui-cell__hd\"><img src=\""+newsImg+"\"></div><div class=\"weui-cell__bd\"><div class=\"new_bt\"><p>"+newsTitle+"</p></div><div class=\"new_time\"><p>"+newsDate+"</p></div></div></a></div>";
							$(".xinwen").append(newsBox);
						}
						}
						});
				$.ajax({
						async:false,//同步，异步
						url:"http://manage.woyaoxuexue.com/guns/app/getnewslist", //请求的服务端地址
						data:{
						"page":page,
						"newstype":2,
						"rows":rows,
						},
						type:"get",
						dataType:"json",
						beforeSend:function(){
						    $("#more").show();
						},
						
						success:function(data){
						console.log(data);
						
						//maxpage = data.data.navigateLastPage;
						//console.log(maxpage);
						var newsNum=data.data.list.length;
						//console.log(newsNum);//知道个数
						var i;
						for(i = 0;i < newsNum;i++){
							var newsTitle = data.data.list[i].title;
							var newsDate = data.data.list[i].create_date;
							var newsImg = data.data.list[i].newsimage;
							var newsUrl;
							newsid=data.data.list[i].newsid;
							var newsBox = "<div class=\"ins1"+i+"_1\"><a  href=\""+HTMLURL1+"\" onclick=\"holdId("+newsid+")\" class=\"weui-cell weui-cell_access\" href=\""+newsUrl+"\"><div class=\"weui-cell__hd\"><img src=\""+newsImg+"\"></div><div class=\"weui-cell__bd\"><div class=\"new_bt\"><p>"+newsTitle+"</p></div><div class=\"new_time\"><p>"+newsDate+"</p></div></div></a></div>";
							$(".dongtai").append(newsBox);
						}
						}
						});
						}
						
// 						$(window).scroll(
// 						        function() {
// 									//console.log("2");
// 						            var scrollTop = $(this).scrollTop();
// 						            var scrollHeight = $(document).height();
// 						            var windowHeight = $(this).height();
// 						            if (scrollTop + windowHeight == scrollHeight) {
// 						                //console.log("3");
// 						                if(page<maxpage) {
// 											page++;
// 						                    goodOrg();
// 										}
// 						                if(page==maxpage){
// 						                    $("#more").html("没有更多数据了");return false;
// 						                }
// 						                
// 						            }
// 						        });
						
// function change(){
// 					var xueke1 = document.getElementById("xueke_pick").value;
// 					//var xueke2;
// 					var nianduan1 = document.getElementById("nianduan_pick").value;
// 					//var nianduan2;
// 					//清空数据
// 					$("#rank_list").empty();
// 					page = 1;
// 					goodOrg();
// 				}





function holdId(Id){
	sessionStorage.removeItem("ID");
	//if (typeof(Storage) !== "undefined") {
    // 存储
	console.log(Id);
    sessionStorage.setItem("ID", Id);
	//}
	//var jsId = window.sessionStorage;
	//jsId = Id;
}
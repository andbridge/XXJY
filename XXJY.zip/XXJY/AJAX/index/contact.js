var userid;

GETuserid();
function GETuserid(){
	
	userid=localStorage.getItem("Useridx")
	console.log(userid)
}

function TIJiao(){
	if(getCookie("userid","/")){
	var content=document.getElementById("LY").value;
	console.log(content)
	Myajax("contact","GET","http://manage.woyaoxuexue.com/guns/app/addleavemessage",
	{
		"userid":userid,
		"content":content
	},10000,function(msg){
		console.log(userid)
		var str=msg.responseText;
		console.log(str)
		var obj=eval("("+str+")");
		var code=obj.code;
		if(code==100000){
			alert("提交成功");
			window.location.assign("../Index/index.html")
		}else{
			alert("出错了");
		}
	},function(code){
		console.log(code.status)
	})}else{
	 		 window.location.assign("../Mine/login.1.html")
	}
}

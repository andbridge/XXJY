	var courseidx;
	var gradeidx;
	var teacherCourseid;
	var teacherGradeid;
	/* var PayStr=window.location.href;
	console.log(PayStr); */
	var PayUserid;
	GetPayUserid();
	function GetPayUserid(){
		PayUserid=localStorage.getItem("Userid");
	}
	console.log(PayUserid)
	function getQueryString(name){
	     var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");  
	     var r = window.location.search.substr(1).match(reg);  
	     if (r != null) return unescape(r[2]); return null;              
	}  
	       
	var code = getQueryString("code");
	console.log(code);
	
	$.ajax({
			async:false,//同步，异步
			url:"http://manage.woyaoxuexue.com/guns/getopenid", //请求的服务端地址
			data:{
			"userid":PayUserid,
			"code":code
			},
			type:"get",
			dataType:"json",
			success:function(msg){
				console.log(msg)
				
			},
			}
	
	)
	
	
	
	
	NewUser();
	function NewUser(){
		Myajax("NewUser","GET","http://manage.woyaoxuexue.com/guns/app/getteachorderlist",
		{
			"page":1,
			"rows":3,
			"ordertype":1
		},10000,function(msg){
			var HTMLURL="../Index/need_cindex.1.html";
			var strdd=msg.responseText;
			/* console.log(strdd); */
			var obja=eval("("+strdd+")");
			console.log(obja);
			var weekArry=[];
			var endtimeArry=[];
			var starttimeArry=[];
			var listLength=obja.data.list.length;
			/* console.log(listLength) */
			
			for(var j=0;j<listLength;j++){
				var addareaname=obja.data.list[j].addareaname;
				/* console.log(addareaname); */
				var addprovincename=obja.data.list[j].addprovincename;
				/* console.log(addprovincename); */
				var addcityname=obja.data.list[j].addcityname;
				/* console.log(addcityname); */
				var address=obja.data.list[j].address;
				console.log(address);
				var totaltime=obja.data.list[j].totaltime;
			/* console.log(totaltime); */
			var price=obja.data.list[j].price;
			//console.log(price);
			var amount=obja.data.list[j].amount;
			//console.log(amount);
			var headpic=obja.data.list[j].headpic;
			//console.log(headpic);
			var remark=obja.data.list[j].remark;
			//console.log(remark);
			var courseid=obja.data.list[j].courseid;
			//console.log(courseid);
			var gradeid=obja.data.list[j].gradeid;
			//console.log(gradeid);
			var teachersex=obja.data.list[j].teachersex;
			//console.log(teachersex);
			var teachplacetype=obja.data.list[j].teachplacetype;
			//console.log(teachplacetype);
			var id=obja.data.list[j].id;
			//console.log(id);
			var timeListArry=obja.data.list[j].timelist;
			/* console.log(timeListArry); */
			var timelistArryLength=timeListArry.length
			/* console.log(timelistArryLength) */
			weekArry=[];
			starttimeArry=[];
			endtimeArry=[];
			for(var t=0;t<timelistArryLength;t++){
				var week=timeListArry[t].week;
				//console.log(week)
				var endtime=timeListArry[t].endtime;
				//console.log(endtime)
				var starttime=timeListArry[t].starttime;
				//console.log(starttime)
				var endtimeValue=endtime.split(" ")
				//console.log(endtimeValue)
				var endtimeValue=String(endtimeValue[0])
				var endtimeValue=endtimeValue.slice(0,5)
				//console.log(endtimeValue)
				var starttimeValue=starttime.split(" ")
				var starttimeValue=String(starttimeValue[0])
				//console.log(starttimeValue)
				var starttimeValue=starttimeValue.slice(0,5)
				//console.log(starttimeValue)
				
				if(week=="1"){
					week="周一"
				}else if(week=="2"){
					week="周二"
				}else if(week=="2"){
					week="周三"
				}else if(week=="2"){
					week="周四"
				}else if(week=="2"){
					week="周五"
				}else if(week=="2"){
					week="周六"
				}else if(week=="2"){
					week="周七"
				}
			weekArry.push(week);
			starttimeArry.push(starttimeValue);
			endtimeArry.push(endtimeValue);
			/* console.log(weekArry)
			console.log(starttimeArry)
			console.log(endtimeArry) */
			}
			
			if(weekArry.length==0){
				weekArry[0]=""
				starttimeArry[0]=""
				endtimeArry[0]=""
				weekArry[1]=""
				starttimeArry[1]=""
				endtimeArry[1]=""
			}else if(weekArry.length<2){
				weekArry[1]=""
				starttimeArry[1]=""
				endtimeArry[1]=""
			}
			
			
			
			if(courseid=="1"){
				teacherCourseid = "语文";
				
			}
			else if(courseid=="2"){
				teacherCourseid = "数学";
				
			}
			else if(courseid=="3"){
				teacherCourseid = "英语";
				
			}
			else if(courseid=="4"){
				teacherCourseid = "物理";
				
			}
			else if(courseid=="5"){
				teacherCourseid = "化学";
				
			}
			else if(courseid=="6"){
				teacherCourseid = "生物";
				
			}
			else if(courseid=="7"){
				teacherCourseid = "历史";
				
			}
			else if(courseid=="8"){
				teacherCourseid = "地理";
				
			}
			else if(courseid=="9"){
				teacherCourseid = "政治";
				
			}
			else if(courseid=="10"){
				teacherCourseid = "科学";
				
			}
			else if(courseid=="11"){
				teacherCourseid = "音乐";
				
			}
			else if(courseid=="12"){
				teacherCourseid = "美术";
				
			}
			else if(courseid=="13"){
				teacherCourseid = "体育";
				
			}
			else if(courseid=="14"){
				teacherCourseid = "信息";
				
			}
			else if(courseid=="0"){
				teacherCourseid = "全学科";
				
			}
			
			if(gradeid == "1"){
				teacherGradeid = "小学";
				
			}
			else if(gradeid == "2"){
				teacherGradeid = "初中";
				
			}
			else if(gradeid == "3"){
				teacherGradeid = "高中";
				
			}
			else if(gradeid == "0"){
				teacherGradeid = "全学段";
				
			}
		
		
		if(!address){
			address="您没有填写详细地址，请核实您的授课方式"
			addareaname=""
			addprovincename=""
			addcityname=""
		}
		if(address=="undefined undefined undefined"){
			address="您没有填写详细地址，请核实您的授课方式"
			addareaname=""
			addprovincename=""
			addcityname=""
		}
		if(address=="undefined"){
			address="您没有填写详细地址，请核实您的授课方式"
			addareaname=""
			addprovincename=""
			addcityname=""
		}
		if(address==""){
			address="您没有填写详细地址，请核实您的授课方式"
			addareaname=""
			addprovincename=""
			addcityname=""
		}
		if(address==" "){
			address="您没有填写详细地址，请核实您的授课方式"
			addareaname=""
			addprovincename=""
			addcityname=""
		}
		
			var need_listValue="<a name=\"firstNew\" href=\""+HTMLURL+"\" onclick=\"holdId("+id+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+headpic+"\" /></div><div class=\"weui-media-box__bd\"><div class=\"subject\"><p>"+teacherCourseid+"&nbsp;|&nbsp;"+teacherGradeid+"</p></div><div class=\"address\"><p>"+addprovincename+"&nbsp;"+addcityname+"&nbsp;"+addareaname+"&nbsp;"+address+"</p></div><div class=\"time\"><p>"+weekArry[0]+"&nbsp;&nbsp;"+starttimeArry[0]+"--"+endtimeArry[0]+"&nbsp;&nbsp;"+weekArry[1]+"&nbsp;&nbsp;"+starttimeArry[1]+"--"+endtimeArry[1]+"&nbsp;&nbsp;……</p></div></div></a>"
			$("#nweNeed").append(need_listValue)
			
		
			}
		},function(code){
			console.log(code.status)
		})
	}
	
	
	
	function holdId(Id){
			sessionStorage.removeItem("ID");
			//if (typeof(Storage) !== "undefined") {
		    // 存储
			console.log(Id);
		    sessionStorage.setItem("ID", Id);
			//}
			//var jsId = window.sessionStorage;
			//jsId = Id;
		}

var courseidx="";
var gradeidx="";
var teacherCourseid;
var teacherGradeid;
NewUser();
function NewUser(){
	Myajax("NewUser","GET","http://manage.woyaoxuexue.com/guns/app/getteachorderlist",
	{
		"page":1,
		"rows":99999,
		"courseid":courseidx,
		"gradeid":gradeidx,
		"ordertype":1
	},10000,function(msg){
		var HTMLURL="need_c.html";
		var strdd=msg.responseText;
		/* console.log(strdd); */
		var obja=eval("("+strdd+")");
		console.log(obja);
		var weekArry=[];
		var endtimeArry=[];
		var starttimeArry=[];
		var listLength=obja.data.list.length;
		/* console.log(listLength) */
		$(".need_list").empty();
		for(var j=0;j<listLength;j++){
			var addareaname=obja.data.list[j].addareaname;
			/* console.log(addareaname); */
			var addprovincename=obja.data.list[j].addprovincename;
			/* console.log(addprovincename); */
			var addcityname=obja.data.list[j].addcityname;
			/* console.log(addcityname); */
			var address=obja.data.list[j].address;
			//console.log(address);
			var totaltime=obja.data.list[j].totaltime;
		/* console.log(totaltime); */
		var price=obja.data.list[j].price;
		//console.log(price);
		var amount=obja.data.list[j].amount;
		//console.log(amount);
		var headpic=obja.data.list[j].headpic;
		//console.log(headpic);
		var remark=obja.data.list[j].remark;
		//console.log(remark);
		var courseid=obja.data.list[j].courseid;
		//console.log(courseid);
		var gradeid=obja.data.list[j].gradeid;
		//console.log(gradeid);
		var teachersex=obja.data.list[j].teachersex;
		//console.log(teachersex);
		var teachplacetype=obja.data.list[j].teachplacetype;
		//console.log(teachplacetype);
		var id=obja.data.list[j].id;
		//console.log(id);
		var timeListArry=obja.data.list[j].timelist;
		/* console.log(timeListArry); */
		var timelistArryLength=timeListArry.length
		/* console.log(timelistArryLength) */
		weekArry=[];
		starttimeArry=[];
		endtimeArry=[];
		for(var t=0;t<timelistArryLength;t++){
			var week=timeListArry[t].week;
			console.log(week)
			var endtime=timeListArry[t].endtime;
			//console.log(endtime)
			var starttime=timeListArry[t].starttime;
			//console.log(starttime)
			var endtimeValue=endtime.split(" ")
			//console.log(endtimeValue)
			var endtimeValue=String(endtimeValue[0])
			var endtimeValue=endtimeValue.slice(0,5)
			console.log(endtimeValue)
			var starttimeValue=starttime.split(" ")
			var starttimeValue=String(starttimeValue[0])
			//console.log(starttimeValue)
			var starttimeValue=starttimeValue.slice(0,5)
			console.log(starttimeValue)
			
			if(week=="1"){
				week="周一"
			}else if(week=="2"){
				week="周二"
			}else if(week=="3"){
				week="周三"
			}else if(week=="4"){
				week="周四"
			}else if(week=="5"){
				week="周五"
			}else if(week=="6"){
				week="周六"
			}else if(week=="7"){
				week="周七"
			}
			
		weekArry.push(week);
		starttimeArry.push(starttimeValue);
		endtimeArry.push(endtimeValue);
		//console.log(weekArry)
		//console.log(starttimeArry)
		//console.log(endtimeArry)
		}
		
		if(weekArry.length==0){
			weekArry[0]=""
			starttimeArry[0]=""
			endtimeArry[0]=""
			weekArry[1]=""
			starttimeArry[1]=""
			endtimeArry[1]=""
		}else if(weekArry.length<2){
			weekArry[1]=""
			starttimeArry[1]=""
			endtimeArry[1]=""
		}
		
		
		
	
	if(courseid=="1"){
		teacherCourseid = "语文";
		
	}
	else if(courseid=="2"){
		teacherCourseid = "数学";
		
	}
	else if(courseid=="3"){
		teacherCourseid = "英语";
		
	}
	else if(courseid=="4"){
		teacherCourseid = "物理";
		
	}
	else if(courseid=="5"){
		teacherCourseid = "化学";
		
	}
	else if(courseid=="6"){
		teacherCourseid = "生物";
		
	}
	else if(courseid=="7"){
		teacherCourseid = "历史";
		
	}
	else if(courseid=="8"){
		teacherCourseid = "地理";
		
	}
	else if(courseid=="9"){
		teacherCourseid = "政治";
		
	}
	else if(courseid=="10"){
		teacherCourseid = "科学";
		
	}
	else if(courseid=="11"){
		teacherCourseid = "音乐";
		
	}
	else if(courseid=="12"){
		teacherCourseid = "美术";
		
	}
	else if(courseid=="13"){
		teacherCourseid = "体育";
		
	}
	else if(courseid=="14"){
		teacherCourseid = "信息";
		
	}
	else if(courseid=="0"){
		teacherCourseid = "全学段";
		
	}
		
		if(gradeid == "1"){
			teacherGradeid = "小学";
		
		}
		else if(gradeid == "2"){
			teacherGradeid = "初中";
		
		}
		else if(gradeid == "3"){
			teacherGradeid = "高中";
			
			
		}
		else if(gradeid == "0"){
			teacherGradeid = "全学段";
			
			
		}
	
		var need_listValue="<a href=\""+HTMLURL+"\" onclick=\"holdId("+id+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+headpic+"\" /></div><div class=\"weui-media-box__bd\"><div class=\"subject\"><p>"+teacherCourseid+"&nbsp;|&nbsp;"+teacherGradeid+"</p></div><div class=\"address\"><p>"+addprovincename+"&nbsp;"+addcityname+"&nbsp;"+addareaname+"&nbsp;"+address+"</p></div><div class=\"time\"><p><span id=\"listTime0\">"+weekArry[0]+"&nbsp;&nbsp;"+starttimeArry[0]+"--"+endtimeArry[0]+"</span><span id=\"listTime1\">&nbsp;&nbsp;"+weekArry[1]+"&nbsp;&nbsp;"+starttimeArry[1]+"--"+endtimeArry[1]+"&nbsp;&nbsp;……</span></p></div></div></a>"
		
		
		$(".need_list").append(need_listValue)
		
		
		
		}
	},function(code){
		console.log(code.status)
	})
}



function holdId(Id){
		sessionStorage.removeItem("ID");
		//if (typeof(Storage) !== "undefined") {
	    // 存储
		console.log(Id);
	    sessionStorage.setItem("ID", Id);
		//}
		//var jsId = window.sessionStorage;
		//jsId = Id;
	}

function change(){
					var xueke1 = document.getElementById("xueke_pick").value;
					//var xueke2;
					var nianduan1 = document.getElementById("nianduan_pick").value;
					console.log(xueke1)
					//var nianduan2;
					if(xueke1=="语文"){
						
						courseidx = "1";
					}
					else if(xueke1=="数学"){
						
						courseidx = "2";
					}
					else if(xueke1=="英语"){
						
						courseidx = "3";
					}
					else if(xueke1=="物理"){
						courseidx = "4";
						
					}
					else if(xueke1=="化学"){
						
						courseidx = "5";
					}
					else if(xueke1=="生物"){
						
						courseidx = "6";
					}
					else if(xueke1=="历史"){
						courseidx = "7";
						
					}
					else if(xueke1=="地理"){
						courseidx = "8";
					}
						
					else if(xueke1=="政治"){
						courseidx = "9";
					}
					else if(xueke1=="科学"){
						courseidx = "10";
					}
					else if(xueke1=="音乐"){
						courseidx = "11";
					}
					else if(xueke1=="美术"){
						courseidx = "12";
					}
					else if(xueke1=="体育"){
						courseidx = "13";
					}
					else if(xueke1=="信息"){
						courseidx = "14";
					}
					else if(xueke1=="全学科"){
						courseidx = "0";
					}
						
					else if(xueke1=="学科"){
						courseidx = "";
					}
						
						
					if(nianduan1=="年段"){
						
						gradeidx = "";
					}
					else if(nianduan1=="小学"){
						
						gradeidx = "1";
					}
					else if(nianduan1=="初中"){
						
						gradeidx = "2";
					}
					else if(nianduan1=="高中"){
						
						gradeidx = "3";
					}
					else if(nianduan1=="全学段"){
						
						gradeidx = "0";
					}
					//清空数据
				NewUser();
}

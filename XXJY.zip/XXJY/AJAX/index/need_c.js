	var courseidx;
	var gradeidx;
	var teacherCourseid;
	var teacherGradeid;
	var orderid;
	var teacherid;
	var id;//等同于orderid；
	var userid;
	var chatTouserid;
	getOrderId()
	function getOrderId(){
		orderid=sessionStorage.getItem("ID");
		NewUser();
		console.log(orderid)
		
	}
	GetteacherID()
	function GetteacherID(){
		teacherid=localStorage.getItem("TecherId");
		userid=localStorage.getItem("Useridx");
		console.log(teacherid);
	}
	
	
	function NewUser(){
		Myajax("NewUser","GET","http://manage.woyaoxuexue.com/guns/app/getteachorderlist",
		{
			"page":1,
			"rows":9999,
			"ordertype":1,
			"orderid":orderid
		},10000,function(msg){
			var HTMLURL="need_c.html";
			var strdd=msg.responseText;
			/* console.log(strdd); */
			var obja=eval("("+strdd+")");
			console.log(obja);
			var weekArry=[];
			var endtimeArry=[];
			var starttimeArry=[];
			
			var listLength=obja.data.list.length;
			/* console.log(listLength) */
			var eee="";
			for(var j=0;j<listLength;j++){
				var nickname=obja.data.list[j].nickname;
				/* console.log(nickname); */
				var addareaname=obja.data.list[j].addareaname;
				/* console.log(addareaname); */
				var addprovincename=obja.data.list[j].addprovincename;
				/* console.log(addprovincename); */
				var addcityname=obja.data.list[j].addcityname;
				/* console.log(addcityname); */
				var address=obja.data.list[j].address;
				//console.log(address);
				var totaltime=obja.data.list[j].totaltime;
				
			/* console.log(totaltime); */
			var price=obja.data.list[j].price;
			//console.log(price);
			var amount=obja.data.list[j].amount;
			//console.log(amount);
			var headpic=obja.data.list[j].headpic;
			var phone=obja.data.list[j].phone;
			//console.log(headpic);
			var remark=obja.data.list[j].remark;
			if(typeof(remark)=='undefined'){
				remark="<span>系统提示<\span>：他暂时没什么想说的"
			}
			//console.log(remark);
			var courseid=obja.data.list[j].courseid;
			//console.log(courseid);
			var gradeid=obja.data.list[j].gradeid;
			//console.log(gradeid);
			var teachersex=obja.data.list[j].teachersex;
			//console.log(teachersex);
			if(teachersex=="1"){
				teachersex="男"
			}else if(teachersex=="2"){
				teachersex="女"
			}else if(teachersex=="0"){
				teachersex="无要求"
			}
			var teachplacetype=obja.data.list[j].teachplacetype;
			//console.log(teachplacetype);
			if(teachplacetype=="0"){
				teachplacetype="请老师上门"
			}else if(teachplacetype=="1"){
				teachplacetype="到老师指定地点"
			}
			id=obja.data.list[j].id;
			console.log(id);
			var timeListArry=obja.data.list[j].timelist;
			/* console.log(timeListArry); */
			var timelistArryLength=timeListArry.length
			/* console.log(timelistArryLength) */
			for(var t=0;t<timelistArryLength;t++){
				var week=timeListArry[t].week;
				//console.log(week)
				var endtime=timeListArry[t].endtime;
				//console.log(endtime)
				var starttime=timeListArry[t].starttime;
				var datestr=timeListArry[t].datestr;
				console.log(datestr)
				datestr=datestr.split(" ")
				datestr=datestr[0]
				datestr=datestr.split("-")
				datestr=datestr.join("/")
				console.log(datestr)
				endtimeValue=endtime.split(" ")
				 
				// console.log(endtimeValue)
				endtimeValue=String(endtimeValue[0])
				endtimeValue=endtimeValue.slice(0,5)
				console.log(endtimeValue)
				var starttimeValue=starttime.split(" ")
				var starttimeValue=String(starttimeValue[0])
				console.log(starttimeValue)
				var starttimeValue=starttimeValue.slice(0,5)
				console.log(starttimeValue)
				
				if(week=="1"){
					week="周一"
				}else if(week=="2"){
					week="周二"
				}else if(week=="3"){
					week="周三"
				}else if(week=="4"){
					week="周四"
				}else if(week=="5"){
					week="周五"
				}else if(week=="6"){
					week="周六"
				}else if(week=="7"){
					week="周日"
				}
				week=datestr+"&nbsp;"+week
			weekArry.push(week);
			starttimeArry.push(starttimeValue);
			endtimeArry.push(endtimeValue);
			//console.log(weekArry)
			//console.log(starttimeArry)
			//console.log(endtimeArry)
			}
			
			if(courseid=="1"){
				teacherCourseid = "语文";
				
			}
			else if(courseid=="2"){
				teacherCourseid = "数学";
				
			}
			else if(courseid=="3"){
				teacherCourseid = "英语";
				
			}
			else if(courseid=="4"){
				teacherCourseid = "物理";
				
			}
			else if(courseid=="5"){
				teacherCourseid = "化学";
				
			}
			else if(courseid=="6"){
				teacherCourseid = "生物";
				
			}
			else if(courseid=="7"){
				teacherCourseid = "历史";
				
			}
			else if(courseid=="8"){
				teacherCourseid = "地理";
				
			}
			else if(courseid=="9"){
				teacherCourseid = "政治";
				
			}
			
			if(gradeid == "1"){
				teacherGradeid = "小学";
				
			}
			else if(gradeid == "2"){
				teacherGradeid = "初中";
				
			}
			else if(gradeid == "3"){
				teacherGradeid = "高中";
				
			}
			chatTouserid=obja.data.list[j].userid;
			var contentMainValue="<div class=\"normal\"><p>基本信息</p><div class=\"weui-flex\"><div class=\"weui-flex__item normal_content\"><span>昵称：</span><span>"+nickname+"</span><br/><span>需求科目：</span><span>"+teacherCourseid+"</span><br/><span>需求学段：</span><span>"+teacherGradeid+"</span><br/><span>性别：</span><span>"+teachersex+"</span><br/><span>上课方式：</span><span>"+teachplacetype+"</span><br><span>电话号码：</span><span>"+phone+"</span></div><div class=\"weui-flex__item normal_img\"><img src=\""+headpic+"\" /></div><button class=\"cWith\"><a id=\"ONUrl\" onclick=\"setTouserid("+chatTouserid+",\' "+nickname+","+headpic+"\' )\" ><img src=\"content/img/fixed_img/在线联系.jpg\"></a><button></div></div><div class=\"class_adr\"><p>上课地点</p><div class=\"class_adrs\"><span>"+addprovincename+"&nbsp;"+addcityname+"&nbsp;"+addareaname+"&nbsp;"+address+"<p></p></span></div></div><div class=\"class_time\"><p>计划课时安排</p><div class=\"time_content\"><p id=\"timelist0\">"+weekArry[0]+"&nbsp;&nbsp;"+starttimeArry[0]+"--"+endtimeArry[0]+"</p>"+eee+"<p id=\"timelist1\">"+weekArry[1]+"&nbsp;&nbsp;"+starttimeArry[1]+"--"+endtimeArry[1]+"</p>"+eee+"<p id=\"timelist2\">"+weekArry[2]+"&nbsp;&nbsp;"+starttimeArry[2]+"--"+endtimeArry[2]+"</p>"+eee+"<p id=\"timelist3\">"+weekArry[3]+"&nbsp;&nbsp;"+starttimeArry[3]+"--"+endtimeArry[3]+"</p>"+eee+"<p id=\"timelist4\">"+weekArry[4]+"&nbsp;&nbsp;"+starttimeArry[4]+"--"+endtimeArry[4]+"</p>"+eee+"<p id=\"timelist5\">"+weekArry[5]+"&nbsp;&nbsp;"+starttimeArry[5]+"--"+endtimeArry[5]+"</p>"+eee+"<p id=\"timelist6\">"+weekArry[6]+"&nbsp;&nbsp;"+starttimeArry[6]+"--"+endtimeArry[6]+"</p>"+eee+"</div></div><div class=\"one_fee\"><p>单次课程费用</p><div class=\"one_fees\"><span>"+price+"元</span></div></div><div class=\"all_time\"><p>总课时</p><div class=\"all_times\"><span>"+totaltime+"课时</span></div></div><div class=\"all_fee\"><p>总费用</p><div class=\"all_fees\"><span>"+amount+"元</span></div></div><div class=\"notice\"><p>备注</p><div class=\"notice_c\"><p>"+remark+"</p></div></div><div class=\"btn\"><a onclick=\"cofirREN()\" href=\"javascript:;\" class=\"weui-btn bg-blue\">认领</a></div>";
			
			$(".contenMain").append(contentMainValue);
			
			$("#ONUrl").click(function(){
				if(getCookie("userid","/")){
				 		 window.location.assign("../Index/xiaoxi.html");
				}else{
				 		 window.location.assign("../Mine/login.1.html")
				}
			})
			
			
			
			
			
			
			
			if(weekArry.length<2){
				$("#timelist1").remove();
				$("#timelist2").remove();
				$("#timelist3").remove();
				$("#timelist4").remove();
				$("#timelist5").remove();
				$("#timelist6").remove();
			}else if(weekArry.length<3){
				$("#timelist2").remove();
				$("#timelist3").remove();
				$("#timelist4").remove();
				$("#timelist5").remove();
				$("#timelist6").remove();
			}else if(weekArry.length<4){
				$("#timelist3").remove();
				$("#timelist4").remove();
				$("#timelist5").remove();
				$("#timelist6").remove();
			}else if(weekArry.length<5){
				
				$("#timelist4").remove();
				$("#timelist5").remove();
				$("#timelist6").remove();
			}else if(weekArry.length<6){
				
				
				$("#timelist5").remove();
				$("#timelist6").remove();
			}else if(weekArry.length<7){
				$("#timelist6").remove();
			}
			
			
			}
		},function(code){
			console.log(code.status)
		})
	}
	
	
	console.log(orderid);
	function cofirREN(){
		
		if(getCookie("userid","/")){
			
		Myajax("cofirREN","GET","http://manage.woyaoxuexue.com/guns/app/acceptteachorder",
		{
			"orderid":orderid,
			"teacherid":teacherid
		},10000,function(msg){
			console.log(orderid)
			console.log(teacherid)
			var sttr=msg.responseText;
			/* console.log(sttr); */
			var objtt=eval("("+sttr+")")
			console.log(objtt)
			var msgtt=objtt.msg;
			var coderen=objtt.code;
			if(msgtt=="接受用户需求失败"){
				alert(msgtt)
			}else if(coderen=="100000"){
				alert("认领需求成功")
				window.location.assign("../Mine/P_order2.html");
			}
		},function(code){
			console.log(code.status);
		})
	}else{
		window.location.assign("../Mine/login.1.html")
	}
	}
	
	
function setTouserid(touserid,name,photo){
	sessionStorage.removeItem("Touserid");
	sessionStorage.removeItem("Name");
	sessionStorage.removeItem("Photo");
	sessionStorage.setItem("Touserid", touserid);
	sessionStorage.setItem("Name", name);
	sessionStorage.setItem("Photo", photo);
	//}
	}

getUserid()
var	allchat;
function getUserid(){
	userid=localStorage.getItem("Useridx");
	console.log(userid)
}
var chatlengtha;
Myajax("chat","GET","http://manage.woyaoxuexue.com/guns/app/getlastmessagelist",
{
	"userid":userid
},10000,function(msg){
	var chatstr=msg.responseText;
	var chatobj=eval("("+chatstr+")")
	console.log(chatobj)
	var chatlength=chatobj.data.length;
	chatlengtha=chatlength
	for(var i=0 ;i<chatlength;i++){
		var fromuserid=chatobj.data[i].fromuserid
		var content=chatobj.data[i].content
		var newmessage=chatobj.data[i].newmessage
		var sendtime=chatobj.data[i].sendtime
		var photo=chatobj.data[i].photo
		var name=chatobj.data[i].name
		console.log(fromuserid)
		console.log(content)
		console.log(newmessage)
		console.log(sendtime)
		if(newmessage!=0){
			var redpeint="<span id=\"netss\" class=\"nets\">sss</span>"
			$(".weui-tabbar__icon").append(redpeint);
		}else{
			$("#netss").remove()
			
		}
		var netss=document.getElementById("netss");
		
		
		var chathtml=" <div class=\"chat2\"><a href=\"xiaoxi.html\" onclick=\"setTouserid("+fromuserid+",\'"+name+","+photo+"\')\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd\"><img class=\"weui-media-box__thumb\" src=\""+photo+"\"></div><div class=\"weui-media-box__bd\"><span class=\"newmsg\">"+newmessage+"</span><div class=\"chat_name\"><h4>"+name+"</h4><p class=\"weui-media-box__desc\">"+sendtime+"</p></div><div class=\"chat_content\"><p class=\"weui-media-box__desc\">"+content+"</p></div></div></a></div>"
	$(".weui-panel__bd").append(chathtml)
	}
},function(code){
	
})

	setInterval(function(){
		Myajax("chat","GET","http://manage.woyaoxuexue.com/guns/app/getlastmessagelist",
		{
			"userid":userid
		},10000,function(msg){
			var chatstr=msg.responseText;
			var chatobj=eval("("+chatstr+")")
			console.log(chatobj)
			var chatlength=chatobj.data.length;
			
			/* console.log(newmessage) */
			
			var i
			
			for(i=0 ;i<chatlength-1;i++){
				/* var fromuserid=chatobj.data[i].fromuserid
				var content=chatobj.data[i].content
				var newmessage=chatobj.data[i].newmessage
				var sendtime=chatobj.data[i].sendtime */
				/* console.log(fromuserid)
				console.log(content)
				console.log(newmessage)
				console.log(sendtime) */
				var newmessage=chatobj.data[i].newmessage
				
				if(newmessage!=0){
					var redpeint="<span id=\"netss\" class=\"nets\">sss</span>"
					$(".weui-tabbar__icon").append(redpeint);
				}else{
					$("#netss").remove()
				}
			}
			
		/* console.log(allchat) */
			var fromuserid=chatobj.data[i].fromuserid
			var content=chatobj.data[i].content
			
			var sendtime=chatobj.data[i].sendtime
			var photo=chatobj.data[i].photo
			if(!photo){
				photo='undefine';
			}
			if(photo=""){
				photo='undefine';
			}
			
			var name=chatobj.data[i].name
			
			if(chatlength!=chatlengtha){
			var chathtml=" <div class=\"chat2\"><a href=\"xiaoxi.html\" onclick=\"setTouserid("+fromuserid+",\'"+name+","+photo+"\')\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd\"><img class=\"weui-media-box__thumb\" src=\"content/img/up_img/tx1.jpg\"></div><div class=\"weui-media-box__bd\"><span class=\"newmsg\">"+newmessage+"</span><div class=\"chat_name\"><h4>"+fromuserid+"</h4><p class=\"weui-media-box__desc\">"+sendtime+"</p></div><div class=\"chat_content\"><p class=\"weui-media-box__desc\">"+content+"</p></div></div></a></div>"
			$(".weui-panel__bd").append(chathtml)
			chatlengtha=chatlength
			/* if(newmessage==0){
				$("#netss").remove()
			} */
			}
		
			
		},function(code){
			
		})
	},3000)
	function setTouserid(touserid,name,photo){
	sessionStorage.removeItem("Touserid");
	sessionStorage.removeItem("Name");
	sessionStorage.removeItem("Photo");
	sessionStorage.setItem("Touserid", touserid);
	sessionStorage.setItem("Name", name);
	sessionStorage.setItem("Photo", photo);
	//}
	}
	

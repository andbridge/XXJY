   var page=1;
   var skillNum="";
   changea();
function getSkillclass(){
			/* 	screen.onscroll=function(){
			
			if(screen.scrollHeight-screen.scrollTop==screen.clientHeight){
				
				}
				
			}; */
			$(".weui-panel__bd").empty();
			Myajax("userid","GET","http://manage.woyaoxuexue.com/guns/app/getyxjslist",
			{
				"page":page,
				"rows":9999,
				"skillid":skillNum
			},1000000,
			function(msg){
				var HTMLURL="skill.1.html";
				var str=msg.responseText;
				/* console.log(str); */
				var obja=eval("("+str+")");
				console.log(obja);
				var list=obja.data.list.length;
				/* console.log(list) */
				var lastPage=obja.data.lastPage;
				/* console.log(lastPage) */
				$(".weui-panel__bd").empty();
				for(var i=0;i<list;i++){
				var skillid;
				var skillidOBJ=obja.data.list[i].skillid;
				/* console.log(skillidOBJ); */
				if(skillidOBJ==1){
					skillid="种植";
				}else if(skillidOBJ==2){
					skillid="茶艺"
				}else if(skillidOBJ==3){
					skillid="维修"	
				}else if(skillidOBJ==4){
					skillid="健身"
				}else if(skillidOBJ==5){
					skillid="舞蹈"
				}
				
				/* console.log(skillid); */
				var firstname=obja.data.list[i].firstname+"老师";
				/* console.log(firstname); */
				var photo=obja.data.list[i].photo;
				/* console.log(photo); */
				var id=obja.data.list[i].id;
				//console.log(id);
				/* console.log(firstname); */
				var integrate=obja.data.list[i].integrate;
				/* console.log(integrate); */
				var mark=obja.data.list[i].mark;
				if(mark=="1"){
					markImg="content/img/up_img/pingfen1.jpg";
				}else if(mark=="2"){
					markImg="content/img/up_img/pingfen2.jpg";
				}else if(mark=="3"){
					markImg="content/img/up_img/pingfen3.jpg";
				}else if(mark=="4"){
					markImg="content/img/up_img/pingfen4.jpg";
				}else if(mark=="5"){
					markImg="content/img/up_img/pingfen5.jpg";
				}
				/* console.log(mark); */
				/* var skillClass="<div class=\"weui-cell1\"><div class=\"rig1\"><div class=\"weui-cell__bd1\"> " */
				var skillClass="<a class=\"qwa\" href=\""+HTMLURL+"\" onclick=\"holdId("+id+")\"><div href=\javascript:void(0);\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd\"><img class=\"weui-media-box__thumb\" src=\""+photo+"\"></div><div class=\"weui-media-box__bd weui-cell_access\"><span class=\"weui-media-box__title teacher\">"+firstname+"</span>&nbsp&nbsp&nbsp&nbsp<span class=\"weui-media-box__title skill\">"+skillid+"</span><br/><sapn class=\"weui-media-box__title score\">评分：<img src=\""+markImg+"\" alt=\"评分\"/></sapn><span class=\"weui-media-box__title experience\">已授课："+integrate+"课时</span></div></div></a>";
			$(".weui-panel__bd").append(skillClass);
			/* $(".main").append(skillClass) */
				}
			},function(code){
				console.log(code.status);
			});
			}
function holdId(Id){
	sessionStorage.removeItem("ID");
	//if (typeof(Storage) !== "undefined") {
    // 存储
	console.log(Id);
    sessionStorage.setItem("ID", Id);
	//}
	//var jsId = window.sessionStorage;
	//jsId = Id;
}

function changea(){
var skillValue=document.getElementById("picker").value;
				if(skillValue=='种植'){
					skillNum=1;
				}else if(skillValue=='茶艺'){
					skillNum=2;
				}else if(skillValue=='维修'){
					skillNum=3;
				}else if(skillValue=='健身'){
					skillNum=4;
				}else if(skillValue=='舞蹈'){
					skillNum=5;
				}else if(skillValue=='技能'){
					skillNum="";
				}
				
				getSkillclass();
};

	
var idx;
var id;
var listLength;
var j;
var price;
var userid;
var allMoney;
var classnum;
var teacherIDX;
var skillid;
var technicianid;
getSkillId()
function getSkillId(){
    id = sessionStorage.getItem("ID");
 			getSkill();
}
useridx()
function useridx(){
	userid=localStorage.getItem("Userid");
	technicianid=localStorage.getItem("TechnicianId")
}


function getSkill(){
	Myajax("getSkill","GET","http://manage.woyaoxuexue.com/guns/app/getyxjsdetail",
	{
		"id":id
	},100000,
	function(msg){
		var str=msg.responseText;
		var obja=eval("("+str+")");
		console.log(obja);
		var firstname=obja.data.firstname+"老师";
		//console.log(firstname);
		idx=obja.data.id;
		teacherIDX=obja.data.userid;
		/* console.log(id); */
		/* userid=obja.data.userid; */
		/* console.log(userid); */
		var photo=obja.data.photo;
		//console.log(photo);
		var sex=obja.data.sex;
		//console.log(sex);
		skillid=obja.data.skillid;
		//console.log(skillid);
		var introduction=obja.data.introduction;
		//console.log(introduction);
		var integrate=obja.data.integrate;
		//console.log(integrate);
		price=obja.data.price;
		/* console.log(price); */
		var teachplacetype=obja.data.teachplacetype;
		/* console.log(teachplacetype); */
		var ssq=obja.data.ssq;
		/*技能 转化 */
		
		if(skillid==1){
			skillid="种植";
		}else if(skillid==2){
			skillid="茶艺"
		}else if(skillid==3){
			skillid="维修"
		}else if(skillid==4){
			skillid="健身"
		}else if(skillid==5){
			skillid="舞蹈"
		}
		//console.log(skillid)
		/* 性别转换 */
		
		
		//console.log(sex)
		/* 上课方式转换 */		
			
		if(teachplacetype==0){
			teachplacetype="请老师上门";
		}else if(teachplacetype==1){
			teachplacetype="到老师指定地点";
		}
		/* var allmenoy;
		
		var ClassTime=document.getElementsByClassName("ClassTime");
			ClassTime.onmouseleave=function(){
			allmenoy=ClassTime.value*price;
			} */
			var mainChilder="<h4>教师简介</h4><p>"+introduction+"</p><ul><li>综合评价</li><button type=\"button\" onclick=\"addCollect()\"><a><img src=\"content/img/fixed_img/点击收藏.png\" >点击收藏</a></button><li>授课经验:"+integrate+"</li><li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:</li><input type=\"number\" class=\"ClassTime\" value=\"\" id=\"demo\" onchange=\"money()\"/><li id=\"change\">总价:0</li></ul><a><button onclick=\"ConfirmPay()\" type=\"button\">确认支付</button></a>";
			var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>技能：</li><span>"+skillid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form   class=\"form1\"><img  src=\""+photo+"\"></form></div><a ><button type=\"button\"><img src=\"content/img/fixed_img/在线联系.png\" >在线联系</button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+ssq+"</span></a></p>";
			$(".banner").append(bannerChildren)
			$(".main").append(mainChilder);
	},function(code){
		console.log(code.status);
	}
	);
};
function money(){
	//console.log("333");
	
	//console.log(ClassTime.demo.value);
	classnum=demo.value;
	allMoney=demo.value*price;
	if(allMoney<0){
		allMoney=0;
	}
	$("#change").text("总价:"+allMoney);
}
function addCollect(){
	Myajax("collectionuserid","GET","http://manage.woyaoxuexue.com/guns/app/addcollection",
	{
		"collectionuserid":teacherIDX,
		"userid":userid,
		"usertype":2
	},100000,function(msg){
		var str=msg.responseText;
		var objb=eval("("+str+")");
		console.log(objb);
		console.log(userid)
	var msgor=objb.msg;
	var codeor=objb.code;
	if(codeor=="100000"){
	alert("收藏成功");
	window.location.assign("../Mine/P_collect.html")
	}else if(msgor=="已添加当前数据，请勿重复添加"){
		alert(msgor);
	}
	},function(code){
		console.log(code.status);
	})
}


function ConfirmPay(){
	if(skillid=="种植"){
		skillid="1";
	}else if(skillid=="茶艺"){
		skillid="2"
	}else if(skillid=="维修"){
		skillid="3"
	}else if(skillid=="健身"){
		skillid="4"
	}else if(skillid=="舞蹈"){
		skillid="5"
	}
	Myajax("ConfirmPay","GET","http://manage.woyaoxuexue.com/guns/app/addjishiorder",
	{
		"userid":userid,
		"technicianid":idx,
		"skillid":skillid,
		"price":price,
		"classnum":classnum,
		"amount":allMoney
	},10000,function(msg){
		var strr=msg.responseText;
		/* console.log(strr) */
		var objr=eval("("+strr+")")
		 console.log(objr) 
		var msgpay=objr.msg;
		var codepay=objr.code;
		if(msgpay=="添加用户技师需求失败"){
					 alert(msgpay)
		}else if(codepay=="100000"){
			 alert("支付成功");
			window.location.assign("../Index/index.html");
		}
	},function(code){
		console.log(code.status)
	})
}
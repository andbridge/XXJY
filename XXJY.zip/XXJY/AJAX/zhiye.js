var userid;
var teacherinfo;
var technicianinfo;
getUserid();
function getUserid(){
	userid=localStorage.getItem("Useridx");
	console.log(userid)
}
Myajax("zhiye","GET","http://manage.woyaoxuexue.com/guns/app/getuserinfo",
		{
			"userid":userid
		},100000,function(msg){
		var str=msg.responseText;
		// console.log(str)
		var obj=eval("("+str+")")
		console.log(obj)
		teacherinfo=obj.data.teacherinfo;
		technicianinfo=obj.data.technicianinfo;
		
		if(teacherinfo){
			console.log(teacherinfo)
			var firstname=obj.data.teacherinfo.firstname+"老师";
			console.log(firstname)
			var gradeid=obj.data.teacherinfo.gradeid
			console.log(gradeid)
			var courseid=obj.data.teacherinfo.courseid
			console.log(courseid)
			var ssq=obj.data.teacherinfo.ssq
			console.log(firstname)
			var photo=obj.data.teacherinfo.photo
			var teacherid=obj.data.teacherinfo.teacherid
			if(courseid=="1"){
				courseid="语文";
			}else if(courseid=="2"){
				courseid="数学"
			}else if(courseid=="3"){
				courseid="英语"
			}else if(courseid=="4"){
				courseid="物理"
			}else if(courseid=="5"){
				courseid="化学"
			}else if(courseid=="6"){
				courseid="生物"
			}else if(courseid=="7"){
				courseid="历史"
			}else if(courseid=="8"){
				courseid="地理"
			}else if(courseid=="9"){
				courseid="政治"
			}else if(courseid=="10"){
				courseid="科学"
			}else if(courseid=="11"){
				courseid="音乐"
			}else if(courseid=="12"){
				courseid="美术"
			}else if(courseid=="13"){
				courseid="体育"
			}else if(courseid=="14"){
				courseid="信息"
			}else if(courseid=="0"){
				courseid="全学科"
			}
			// if(ssq==""){
			// 	ssq="您没有填写地址"
			// }
			// if(!ssq){
			// 	ssq="您没有填写地址"
			// }
			// if(ssq="undefined undefined undefined"){
			// 	ssq="您没有填写地址"
			// }
			if(gradeid=="1"){
				gradeid="小学";
			}else if(gradeid=="2"){
				gradeid="初中";
			}else if(gradeid=="3"){
				gradeid="高中";
			}else if(gradeid=='0'){
				gradeid="全学段";
			}
		var price=obj.data.teacherinfo.price
		var integrate=obj.data.teacherinfo.integrate
	
		var STRCOnt="<a onclick=\"ToContent()\"><div class=\"listA\"><div class=\"headerA\"><img src=\""+photo+"\" ></div><div class=\"contA\"><ul><li><div style=\"color: black; font-weight: bold;\" class=\"lileft\">"+firstname+"</div><div class=\"liright\">"+courseid+"|"+gradeid+"</div></li><li  >价格:"+price+"元&nbsp;&nbsp;&nbsp;&nbsp;课时数:"+integrate+"小时</li></ul></div><hr ></div><a>"
		$(".main").append(STRCOnt)
		}else if(technicianinfo){
			var firstname=obj.data.technicianinfo.firstname+"老师"
			var ssq=obj.data.technicianinfo.ssq
			if(ssq==""){
				ssq="您没有填写地址，请核实您的授课方式"
			}
			if(!ssq){
				ssq="您没有填写地址，请核实您的授课方式"
			}
			if(ssq="undefined undefined undefined"){
				ssq="您没有填写地址，请核实您的授课方式"
			}
			var photo=obj.data.technicianinfo.photo
			var skillid=obj.data.technicianinfo.skillid
			var technicianid=obj.data.technicianinfo.technicianid
			// var technicianid=obj.data.technicianinfo.technicianid
			console.log(technicianid)
			setTJS(technicianid)
			 function setTJS(Technicianid){
				 localStorage.setItem("TechnicianIdSS", Technicianid);
				 
			 }
			if(skillid==1){
				skillid="种植";
			}else if(skillid==2){
				skillid="茶艺"
			}else if(skillid==3){
				skillid="维修"	
			}else if(skillid==4){
				skillid="健身"
			}else if(skillid==5){
				skillid="舞蹈"
			}
			var price=obj.data.technicianinfo.price
			var integrate=obj.data.technicianinfo.integrate
			var STRCOnt="<a onclick=\"ToContent()\" ><div class=\"listA\"><div class=\"headerA\"><img src=\""+photo+"\" ></div><div class=\"contA\"><ul><li><div style=\"color: black; font-weight: bold;\" class=\"lileft\">"+firstname+"</div><div class=\"liright\">"+skillid+"</div></li><li  >价格:"+price+"元&nbsp;&nbsp;&nbsp;&nbsp;课时数:"+integrate+"小时</li></ul></div><hr ></div><a>"
			$(".main").append(STRCOnt)
		}
		
		},function(code){
			console.log(code.status);
		})
		
		
		
	function ToContent(){
		if(teacherinfo){
			location.href="../Join/uptea.html"
			}else if(technicianinfo){
				location.href="../Join/upjs.html"
			}
	}
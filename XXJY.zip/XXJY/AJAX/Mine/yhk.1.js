var userid;
var payaccount;
var username;
var bankname;
getUserid()
function getUserid(){
	userid=localStorage.getItem("Useridx");
	console.log(userid)
}

$("#addCard").click(function(){
	var addCardMsgStr="<div id=\"guanbi\" class=\"addCardMsg\"><label>请输入账号：</label><input type=\"number\" name=\"payaccount\" /><p>银行名称：</p><input type=\"text\" name=\"bankname\" /><p>真实姓名：</p><input type=\"text\" name=\"username\" /><span style='margin-top: 10px;' id=\"removecard\">关闭</span><a class=\"confircard\">确定</a></div>";
	$("#guanbi").remove()
	$("body").append(addCardMsgStr)
	/* var main=document.getElementsByClassName("main")[0]
	main.lastChild.scrollIntoView(); */
	$("#removecard").click(function(){
		$("#guanbi").remove()
	})
	$(".confircard").click(function(){
		var bankname=document.getElementsByName("bankname")[0].value
		var payaccount=document.getElementsByName("payaccount")[0].value
		var username=document.getElementsByName("username")[0].value
		console.log(bankname)
		console.log(payaccount)
		console.log(username)
		Myajax("addcard","GET","http://manage.woyaoxuexue.com/guns/app/addaccount",
		{
			"userid":userid,
			"accounttype":"3",
			"payaccount":payaccount,
			"username":username,
			"bankname":bankname
			
		},1000,function(msg){
			var addStr=msg.responseText;
			console.log(addStr)
			location.reload([true]);
		},function(code){
			
		})
		
	})
	
})

Myajax("addcard","GET","http://manage.woyaoxuexue.com/guns/app/getaccountlist",
		{
			"userid":userid,
			"accounttype":"3"
		},1000,function(msg){
			var addStr=msg.responseText;
			
			var cardObj=eval("("+addStr+")")
			console.log(cardObj)
			var dataLeng=cardObj.data.length;
			/* console.log(dataLeng) */
			for(var i=0;i<dataLeng;i++){
				
				var bankname=cardObj.data[i].bankname;
				var username=cardObj.data[i].username;
				var payaccount=cardObj.data[i].payaccount;
				var accountid=cardObj.data[i].accountid;
				if("undefined"==payaccount){
					payaccount="未知名账号"
				}
				if("undefined"==username){
					username="未知名姓名"
				}
				if("undefined"==bankname){
					bankname="未知名银行"
				}
				cardMStr="<div onclick=\"setAccountid("+accountid+")\" class=\"yhk\"><div class=\"cardImg\"><img src=\"content/img/fixed_img/银行卡.png\" ></div><div class=\"cardMsg\"><li>"+bankname+"</li><li style=\"font-size: 12px; color: skyblue\">储蓄卡</li><li>卡号："+payaccount+"</li></div></div>"
				
				$(".main").append(cardMStr)
			}
			
			
		},function(code){
			
		})
		
		
		function setAccountid(accountid){
			sessionStorage.removeItem("Accountid");
			//if (typeof(Storage) !== "undefined") {
		    // 存储
			console.log(accountid);
		    sessionStorage.setItem("Accountid", accountid);
			//}
			//var jsId = window.sessionStorage;
			//jsId = Id;
			window.location.assign("TiXian.1.html")
		}
		
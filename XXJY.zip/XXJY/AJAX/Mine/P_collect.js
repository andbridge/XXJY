var userid;
/* var usertype; */
GETALL();
function GETALL(){
	  userid = localStorage.getItem("Useridx");
	  /* usertype = localStorage.getItem("userType"); */
	  getP_collectA()
	  getP_collectB()
	  getP_collectC()
	  /* console.log(userid) */
}
function getP_collectA(){
	Myajax("P_Scoll","GET","http://manage.woyaoxuexue.com/guns/app/getcollectionlist",
	{
		"page":1,
		"rows":9999,
		"userid":userid,
		"usertype":1
	},
	100000,
	function(msg){
		var HTMLURL="../Good_tea/tea_content.2.html"
		/* console.log(userid) */
		var str=msg.responseText;
		//console.log(str);
		var obja=eval("("+str+")");
		console.log(obja);
		var listLength=obja.data.list.length;
		console.log(listLength);
		
		var courseid;
		var gradeid;
		for(var k=0;k<listLength;k++){
			var gradeid=obja.data.list[k].gradeid;
			var courseid=obja.data.list[k].courseid;
			/* console.log(skillidOBJ); */
		if(courseid=="1"){
			courseid="语文";
		}else if(courseid=="2"){
			courseid="数学"
		}else if(courseid=="3"){
			courseid="英语"
		}else if(courseid=="4"){
			courseid="物理"
		}else if(courseid=="5"){
			courseid="化学"
		}else if(courseid=="6"){
			courseid="生物"
		}else if(courseid=="7"){
			courseid="历史"
		}else if(courseid=="8"){
			courseid="地理"
		}else if(courseid=="9"){
			courseid="政治"
		}else if(courseid=="10"){
			courseid="科学"
		}else if(courseid=="11"){
			courseid="音乐"
		}else if(courseid=="12"){
			courseid="美术"
		}else if(courseid=="13"){
			courseid="体育"
		}else if(courseid=="14"){
			courseid="信息"
		}
		
			if(gradeid=="1"){
				gradeid="小学";
			}else if(gradeid=="2"){
				gradeid="初中";
			}else if(gradeid=="3"){
				gradeid="高中";
			}else{
				gradeid="出错了";
			}
			/* console.log(skillid); */
			var firstname=obja.data.list[k].firstname+"老师";
			/* console.log(firstname); */
			var photo=obja.data.list[k].photo;
			/* console.log(photo); */
			var id=obja.data.list[k].id;
			/* console.log(id); */
			/* console.log(firstname); */
			var integrate=obja.data.list[k].integrate;
			/* console.log(integrate); */
			var mark=obja.data.list[k].mark;
			
			var markImg;
			if(mark=="1"){
				markImg="content/img/up_img/pingfen1.jpg";
			}else if(mark=="2"){
				markImg="content/img/up_img/pingfen2.jpg";
			}else if(mark=="3"){
				markImg="content/img/up_img/pingfen3.jpg";
			}else if(mark=="4"){
				markImg="content/img/up_img/pingfen4.jpg";
			}else if(mark=="5"){
				markImg="content/img/up_img/pingfen5.jpg";
			}
			
			var collectionid=obja.data.list[k].collectionid
			var p_collectValue="<a ontouchstart=\"gtouchstart("+collectionid+")\" ontouchmove=\"gtouchmove()\" ontouchend=\"gtouchend("+id+")\"     class=\"weui-cell weui-cell_access\" onclick=\"holdId("+id+")\" href=\""+HTMLURL+"\"><div class=\"weui-cell__hd tea_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-cell__bd tea_content\"><div class=\"tea_name\"><p>"+firstname+"</p></div><div class=\"subject\"><p>"+courseid+"&nbsp;|&nbsp;"+gradeid+"</p></div><div class=\"tea_grade\"><p class=\"imgp\">评分：<img src=\""+markImg+"\" /></p></div><br><br><div class=\"exercise\">已授课："+integrate+"课时</div></div><a type=\"button\" onclick=\"clickdrop("+collectionid+")\" class=\"dropclick\">删除</a></a><hr color=\"whitesmoke\" size=\"0.5px\" >"
			$("#PulishValue").append(p_collectValue)
			
			
		}
	},function(code){
		console.log(code.status);
	})
}

function getP_collectB(){
	Myajax("P_Scoll","GET","http://manage.woyaoxuexue.com/guns/app/getcollectionlist",
	{
		"page":1,
		"rows":9999,
		"userid":userid,
		"usertype":2
	},
	100000,
	function(msg){
		var HTMLURL="../Skill/skill1.html"
		/* console.log(userid) */
		var str=msg.responseText;
		//console.log(str);
		var obja=eval("("+str+")");
		console.log(obja);
		var listLength=obja.data.list.length;
		console.log(listLength);
		for(var k=0;k<listLength;k++){
			var skillid;
			var skillidOBJ=obja.data.list[k].skillid;
			/* console.log(skillidOBJ); */
			if(skillidOBJ==1){
				skillid="种植";
			}else if(skillidOBJ==2){
				skillid="茶艺"
			}else if(skillidOBJ==3){
				skillid="维修"	
			}else if(skillidOBJ==4){
				skillid="健身"
			}else if(skillidOBJ==5){
				skillid="舞蹈"
			}
			
			/* console.log(skillid); */
			var firstname=obja.data.list[k].firstname+"老师";
			/* console.log(firstname); */
			var photo=obja.data.list[k].photo;
			/* console.log(photo); */
			var id=obja.data.list[k].id;
			/* console.log(id); */
			/* console.log(firstname); */
			var integrate=obja.data.list[k].integrate;
			/* console.log(integrate); */
			var mark=obja.data.list[k].mark;
			var collectionid=obja.data.list[k].collectionid
			var markImg;
			if(mark=="1"){
				markImg="content/img/up_img/pingfen1.jpg";
			}else if(mark=="2"){
				markImg="content/img/up_img/pingfen2.jpg";
			}else if(mark=="3"){
				markImg="content/img/up_img/pingfen3.jpg";
			}else if(mark=="4"){
				markImg="content/img/up_img/pingfen4.jpg";
			}else if(mark=="5"){
				markImg="content/img/up_img/pingfen5.jpg";
			}
			
			
			var p_collectValue="<a ontouchstart=\"gtouchstart("+collectionid+")\" ontouchmove=\"gtouchmove()\"   class=\"weui-cell weui-cell_access\" onclick=\"holdId("+id+")\" href=\""+HTMLURL+"\"><div class=\"weui-cell__hd tea_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-cell__bd tea_content\"><div class=\"tea_name\"><p>"+firstname+"</p></div><div class=\"subject\"><p>"+skillid+"</p></div><div class=\"tea_grade\"><p class=\"imgp\">评分：<img src=\""+markImg+"\" /></p></div><br><br><div class=\"exercise\">已授课："+integrate+"课时</div></div><a type=\"button\" onclick=\"clickdrop("+collectionid+")\" class=\"dropclick\">删除</a></a><hr color=\"whitesmoke\" size=\"0.5px\">  "
			$("#PulishValue").append(p_collectValue)
			
			
		}
	},function(code){
		console.log(code.status);
	})
}
function getP_collectC(){
	Myajax("P_Scoll","GET","http://manage.woyaoxuexue.com/guns/app/getcollectionlist",
	{
		"page":1,
		"rows":9999,
		"userid":userid,
		"usertype":3
	},
	100000,
	function(msg){
		
		var str=msg.responseText;
		//console.log(str);
		var obja=eval("("+str+")");
		console.log(obja);
		var listLength=obja.data.list.length;
		console.log(listLength);
	},function(code){
		console.log(code.status);
	})
}



function holdId(Id){
	sessionStorage.removeItem("ID");
	//if (typeof(Storage) !== "undefined") {
    // 存储
	console.log(Id);
    sessionStorage.setItem("ID", Id);
	//}
	//var jsId = window.sessionStorage;
	//jsId = Id;
}


		var timeOutEvent=0;//定时器
		//开始按   
		function gtouchstart(dropid){   
			
		    timeOutEvent = setTimeout("longPress("+dropid+")",500);//这里设置定时器，定义长按500毫秒触发长按事件，时间可以自己改，个人感觉500毫秒非常合适   
		    return false;   
		};   
		//手释放，如果在500毫秒内就释放，则取消长按事件，此时可以执行onclick应该执行的事件   
		function gtouchend(dropid){   
		    clearTimeout(timeOutEvent);//清除定时器   
		    if(timeOutEvent!=0){   
		        //这里写要执行的内容（尤如onclick事件）   
		        
		    }   
		    return false;   
		};   
		//如果手指有移动，则取消所有事件，此时说明用户只是要移动而不是长按   
		function gtouchmove(){   
		    clearTimeout(timeOutEvent);//清除定时器   
		    timeOutEvent = 0;   
		      
		};   
		   
		//真正长按后应该执行的内容   
		function longPress(dropid){   
		    timeOutEvent = 0;   
		    //执行长按要执行的内容，如弹出菜单   
		    var flag=confirm("确认删除吗");
		    if(flag){
		    	Myajax("P_Scoll","GET","http://manage.woyaoxuexue.com/guns/app/deletecollection",
		    	{
		    		"collectionid":dropid
		    	},1000,function(msg){
					location.reload([true]);
				},function(code){
					
				})
		    }
		}   
		
		
		function clickdrop(dropid){
			var flag=confirm("确认删除吗");
			if(flag){
				Myajax("P_Scoll","GET","http://manage.woyaoxuexue.com/guns/app/deletecollection",
				{
					"collectionid":dropid
				},1000,function(msg){
					location.reload([true]);
				},function(code){
					
				})
			}
			return false
			dropid.cancelBubble=true;//取消冒泡
		}
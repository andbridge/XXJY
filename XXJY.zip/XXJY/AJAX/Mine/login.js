function GETuserID(userid){
	localStorage .removeItem("Userid");
	/* console.log(userid) */
    localStorage .setItem("Userid", userid);
}
function getAll(userid,usertype,techerId,technicianid){
	localStorage .removeItem("Useridx");
	localStorage .removeItem("userType");
	localStorage .removeItem("TecherId");
	localStorage .removeItem("TechnicianId");
	/* console.log(userid) */
    localStorage .setItem("Useridx", userid);
	localStorage .setItem("userType", usertype);
	localStorage .setItem("TecherId", techerId);
	localStorage .setItem("TechnicianId", technicianid);
}



/* alert(document.cookie); */
var loginBtn=document.getElementById("loginBtn");
loginBtn.onclick=function(){
	var account=document.getElementById("phone_number").value;
	var password=document.getElementById("password").value;
		Myajax("userid","GET","http://manage.woyaoxuexue.com/guns/app/login",
		{
			"account":account,
			"password":password
		},100000,function(msg){
			var str=msg.responseText;
			var obja=eval("("+str+")");
			var code=obja.code;
			var msg=obja.msg;
			console.log(obja)
			var data=obja.data; 
			var userid=data.id;
			var usertype=data.usertype;
			var techerId=data.teacherid;
			var technicianid=data.technicianid;
			
			if(code==100000){
			GETuserID(userid)
			getAll(userid,usertype,techerId,technicianid);
			delCookie("userid","/");
			setCookie("userid",userid,1,"/");
			 window.location.assign("https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx2f951d1170d29021&redirect_uri=http://www.woyaoxuexue.com&response_type=code&scope=snsapi_base");
				function getQueryString(name){  
				     var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");  
				     var r = window.location.search.substr(1).match(reg);  
				     if (r != null) return unescape(r[2]); return null;              
				}  
				       
				var code = getQueryString("code");
				console.log(code)
				var PayStr=window.location.href;
				console.log(PayStr);		
			}else if(msg=="用户登录失败！")
			
			alert(msg)
			
			},
			function(code){
				console.log(code.status);
			});
}
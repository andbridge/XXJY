		var userid;
		var addprovincenameValue;
		var addprovinceList;
		var addprovincecode;
		var addcitynameValue;
		var addcityList;
		var addcitycode;
		var parentidv;
		var parentid;
		var parentide;
		var parentidvh;
		var parentidh;
		var parentideh;
		var addareanameValue;
		var addareaList;
		var addareacode;
		var addprovincenameINNHTML;
		var addprovincename = document.getElementById("addprovincename");
		var ProvinceIDName=document.getElementsByClassName("ProvinceIDName")
		var addareaname = document.getElementById("addareaname")
		/* 省份地址 */
		getaddressProvince()
		function getaddressProvince() {
		Myajax("getaddressProvince","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
		{
			"parentid":100000,
			"leveltype":1,
		},100000,function(msg){
			var strq=msg.responseText;
			/* console.log(str); */
			var objc=eval("("+strq+")");
			/* console.log(objc); */
			addprovinceList=objc.data.length;
			for(var j=0;j<addprovinceList;j++){
			addprovincenameValue=objc.data[j].name;
			addprovincecode=objc.data[j].id
		/* console.log(addprovincecode); */
			/* console.log(addprovincenameValue); */
           addprovincenameINNHTML= "<option value=\""+addprovincecode+"\" class=\"ProvinceIDName\" >"+addprovincenameValue+"</option>";
			$("#addprovincename").append(addprovincenameINNHTML);
			/* console.log(ProvinceIDName[j].value) */
			}
			$("#addprovincename").change(function(){
		$("#addcityname").empty()
		parentid=$("#addprovincename").find("option:selected").val()
		parentidh=$("#addprovincename").find("option:selected").text()
		/* console.log(parentidh) */
			/* console.log(parentid) */
		GETaddcityname();
		
			})
		},function(code){
			console.log(code.status);
		})
		};
	
		/* 城市 */	
		
		function GETaddcityname(){
			Myajax("getaddCITYress","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
			{
				"parentid":parentid,
				"leveltype":2,
			},100000,function(msg){
				var strq=msg.responseText;
				// console.log(str);
				var objd=eval("("+strq+")");
				/* console.log(objd); */                                                    
				addcityList=objd.data.length;
				for(var j=0;j<addcityList;j++){
				addcitynameValue=objd.data[j].name;
				addcitycode=objd.data[j].id
		addcitynameINNHTML= "<option value=\""+addcitycode+"\">"+addcitynameValue+"</option>";
					$("#addcityname").append(addcitynameINNHTML);
				}
				parentidv=$("#addcityname").find("option:selected").val()
				parentidvh=$("#addcityname").find("option:selected").text()
				$("#addareaname").empty();
				GETaddarea();
				/* console.log(parentidvh) */
				$("#addcityname").change(function(){
				$("#addareaname").empty()
				parentidv=$("#addcityname").find("option:selected").val()
				parentidvh=$("#addcityname").find("option:selected").text()
				/* console.log(parentidvh) */
				GETaddarea();
				
					})
				
			},function(code){
				console.log(code.status);
			})
		}
		/* 地区 */
		function GETaddarea(){
			Myajax("getaddAREAress","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
			{
				"parentid":parentidv,
				"leveltype":3,
			},100000,function(msg){
				var stre=msg.responseText;
				// console.log(str);
				var obje=eval("("+stre+")");
				/* console.log(obje); */
				 /* console.log(str); */
				addareaList=obje.data.length;
				for(var j=0;j<addareaList;j++){
				addareanameValue=obje.data[j].name;
				addareacode=obje.data[j].id
		addareanameINNHTML= "<option value=\""+addareacode+"\">"+addareanameValue+"</option>";
					$("#addareaname").append(addareanameINNHTML);
				}
				parentide=$("#addareaname").find("option:selected").val()
				parentideh=$("#addareaname").find("option:selected").text()
				/* console.log(parentideh) */
				
				$("#addareaname").change(function(){
				parentide=$("#addareaname").find("option:selected").val()
				parentideh=$("#addareaname").find("option:selected").text()
				/* console.log(parentideh) */
				})
			},function(code){
				console.log(code.status);
			})
		}
/* uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu */		
			 
		  
		 




	var AlltimeValue1=0;
	var AlltimeValue2=0;
	var AlltimeValue3=0;
	var AlltimeValue4=0;
	var AlltimeValue5=0;
	var AlltimeValue6=0;
	var AlltimeValue7=0;
	var timeValueA;
	var timeValueB;
	var OKTimeValue;
	var moneyA;
	var AllmeonyX=document.getElementById("AllmeonyX");
			/* 删除 */
			var DELX=document.getElementsByClassName("DEL");
			for(var p=0;p<DELX.length;p++){
				DELX[p].num=p;
				DELX[p].onclick=function(){
					var x=this.num;
					var flag=confirm("确认删除吗？");
					if(flag){
						var x=this.num;
						if(x==0){
							AlltimeValue1=0
							weeka=""
							starttimea=""
							endtimea=""
						}else if(x==1){
							AlltimeValue2=0
							weekb=""
							starttimeb=""
							endtimeb=""
						}else if(x==2){
							AlltimeValue3=0
							weekc=""
							starttimec=""
							endtimec=""
						}else if(x==3){
							AlltimeValue4=0
							weekd=""
							starttimed=""
							endtimed=""
						}else if(x==4){
							AlltimeValue5=0
							weeke=""
							starttimee=""
							endtimee=""
						}else if(x==5){
							AlltimeValue6=0
							weekf=""
							starttimef=""
							endtimef=""
						}else if(x==6){
							AlltimeValue7=0
							weekg=""
							starttimeg=""
							endtimeg=""
						}
						console.log(AlltimeValue1);
						console.log(AlltimeValue2);
						console.log(AlltimeValue3);
						console.log(AlltimeValue4);
						console.log(AlltimeValue5);
						console.log(AlltimeValue6);
						console.log(AlltimeValue7);
						
						OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
						ClassTimeX.value="总课时："+OKTimeValue;
						moneyA=$("#AllmeonyB").val();
						AllmeonyX.value="总费用："+OKTimeValue*moneyA
					/* 	console.log(OKTimeValue)
						console.log(AllmeonyB) */
			var	ul=this.parentNode.parentNode;
				ul.parentNode.removeChild(ul);
		        ul=null;
		}
		}
	}
	/* console.log(timeArry) */
	var p;
	var h;
	var j;
	var k;
	var weeka;
	var weekb;
	var weekc;
	var weekd;
	var weeke;
	var weekf;
	var weekg;
	var starttimea;
	var starttimeb;
	var starttimec;
	var starttimed;
	var starttimee;
	var starttimef;
	var starttimeg;
	var endtimea;
	var endtimeb;
	var endtimec;
	var endtimed;
	var endtimee;
	var endtimef;
	var endtimeg;
	var L;
	
	var ClassTimeX=document.getElementById("ClassTimeX")
	/* 添加 */
	AndX.onclick=function(){
		
			var AndX=document.getElementById("AndX");
			var boxX=document.getElementById("boxX");
			var ul=document.createElement("ul");
			var li1=document.createElement("li");
			var li2=document.createElement("li");
			var li3=document.createElement("li");
			var li4=document.createElement("li");
			var li5=document.createElement("li");
			var li6=document.createElement("li");
			var select=document.createElement("select");
			var optionA=document.createElement("option");
			var optionB=document.createElement("option");
			var optionC=document.createElement("option");
			var optionD=document.createElement("option");
			var optionE=document.createElement("option");
			var optionF=document.createElement("option");
			var optionG=document.createElement("option");
			var optionGS=document.createElement("option");
			var select1=document.createElement("select");
				select1.setAttribute("class","timeclass");
			var option1=document.createElement("option");
			var option2=document.createElement("option");
			var option3=document.createElement("option");
			var option4=document.createElement("option");
			var option5=document.createElement("option");
			var option6=document.createElement("option");
			var option7=document.createElement("option");
			var option8=document.createElement("option");
			var option9=document.createElement("option");
			var option10=document.createElement("option");
			var option11=document.createElement("option");
			var option12=document.createElement("option");
			var option13=document.createElement("option");
			var option14=document.createElement("option");
			var option15=document.createElement("option");
			var option16=document.createElement("option");
			var option17=document.createElement("option");
			var option18=document.createElement("option");
			var option19=document.createElement("option");
			var option20=document.createElement("option");
			var option21=document.createElement("option");
			var option22=document.createElement("option");
			var option23=document.createElement("option");
			var option24=document.createElement("option");
			var option25=document.createElement("option");
			var select2=document.createElement("select");
				select2.setAttribute("class","timeclass");
			var option11a=document.createElement("option");
			var option22a=document.createElement("option");
			var option33a=document.createElement("option");
			var option44a=document.createElement("option");
			var option55a=document.createElement("option");
			var option66a=document.createElement("option");
			var option77a=document.createElement("option");
			var option88a=document.createElement("option");
			var option99a=document.createElement("option");
			var option1010a=document.createElement("option");
			var option1111a=document.createElement("option");
			var option1212a=document.createElement("option");
			var option1313a=document.createElement("option");
			var option1414a=document.createElement("option");
			var option1515a=document.createElement("option");
			var option1616a=document.createElement("option");
			var option1717a=document.createElement("option");
			var option1818a=document.createElement("option");
			var option1919a=document.createElement("option");
			var option2020a=document.createElement("option");
			var option2121a=document.createElement("option");
			var option2222a=document.createElement("option");
			var option2323a=document.createElement("option");
			var option2424a=document.createElement("option");	
			var option2525a=document.createElement("option");	
			var img=document.createElement("img");
			    img.src="content/img/fixed_img/删%20除.png";
			var button=document.createElement("button");
			    button.setAttribute("class","DEL");
			// var text1=document.createTextNode("起始时间：");
			var text2=document.createTextNode("—");
		/* 	var textA=document.createTextNode("周一");
			var textB=document.createTextNode("周二");
			var textC=document.createTextNode("周三");
			var textD=document.createTextNode("周四");
			var textE=document.createTextNode("周五");
			var textF=document.createTextNode("周六");
			var textG=document.createTextNode("周日");
			var textGS=document.createTextNode("日期"); */
			var inputDATA=document.createElement("input");
			inputDATA.setAttribute("type","date");
			/* ddddddd */
			/* var texta=document.createTextNode("凌晨1点");
			var textb=document.createTextNode("凌晨2点");
			var textc=document.createTextNode("凌晨3点");
			var textd=document.createTextNode("凌晨4点");
			var texte=document.createTextNode("凌晨5点"); */
			var textf=document.createTextNode("凌晨6点");
			var textg=document.createTextNode("凌晨7点");
			var texth=document.createTextNode("上午8点");
			var texti=document.createTextNode("上午9点");
			var textj=document.createTextNode("上午10点");
			var textk=document.createTextNode("上午11点");
			var textm=document.createTextNode("中午12点");
			var textl=document.createTextNode("下午13点");
			var textn=document.createTextNode("下午14点");
			var texto=document.createTextNode("下午15点");
			var textp=document.createTextNode("下午16点");
			var textq=document.createTextNode("下午17点");
			var textr=document.createTextNode("下午18点");
			var texts=document.createTextNode("下午19点");
			var textt=document.createTextNode("夜晚20点");
			var textu=document.createTextNode("夜晚21点");
			var textv=document.createTextNode("夜晚22点");
			var textw=document.createTextNode("夜晚23点");
			var textx=document.createTextNode("午夜24点");
			var texty=document.createTextNode("开始时间");
			
			/* var texta1=document.createTextNode("凌晨1点");
			var textb2=document.createTextNode("凌晨2点");
			var textc3=document.createTextNode("凌晨3点");
			var textd4=document.createTextNode("凌晨4点");
			var texte5=document.createTextNode("凌晨5点"); */
			var textf6=document.createTextNode("凌晨6点");
			var textg7=document.createTextNode("凌晨7点");
			var texth8=document.createTextNode("上午8点");
			var texti9=document.createTextNode("上午9点");
			var textj10=document.createTextNode("上午10点");
			var textk11=document.createTextNode("上午11点");
			var textm12=document.createTextNode("中午12点");
			var textl13=document.createTextNode("下午13点");
			var textn14=document.createTextNode("下午14点");
			var texto15=document.createTextNode("下午15点");
			var textp16=document.createTextNode("下午16点");
			var textq17=document.createTextNode("下午17点");
			var textr18=document.createTextNode("下午18点");
			var texts19=document.createTextNode("下午19点");
			var textt20=document.createTextNode("夜晚20点");
			var textu21=document.createTextNode("夜晚21点");
			var textv22=document.createTextNode("夜晚22点");
			var textw23=document.createTextNode("夜晚23点");
			var textx24=document.createTextNode("午夜24点");
			var textx25=document.createTextNode("结束时间");
		/* 	option11a.appendChild(texta1)
			option22a.appendChild(textb2)
			option33a.appendChild(textc3)
			option44a.appendChild(textd4)
			option55a.appendChild(texte5) */
			option66a.appendChild(textf6)
			option77a.appendChild(textg7)
			option88a.appendChild(texth8)
			option99a.appendChild(texti9)
			option1010a.appendChild(textj10)
			option1111a.appendChild(textk11)
			option1212a.appendChild(textm12)
			option1313a.appendChild(textl13)
			option1414a.appendChild(textn14)
			option1515a.appendChild(texto15)
			option1616a.appendChild(textp16)
			option1717a.appendChild(textq17)
			option1818a.appendChild(textr18)
			option1919a.appendChild(texts19)
			option2020a.appendChild(textt20)
			option2121a.appendChild(textu21)
			option2222a.appendChild(textv22)
			option2323a.appendChild(textw23)
			option2424a.appendChild(textx24)
			option2525a.appendChild(textx25)
			
			/* optionA.appendChild(textA);
			optionB.appendChild(textB);
			optionC.appendChild(textC);
			optionD.appendChild(textD);
			optionE.appendChild(textE);
			optionF.appendChild(textF);
			optionG.appendChild(textG);
			optionGS.appendChild(textGS) */
			/* option1.appendChild(texta);
			option2.appendChild(textb);
			option3.appendChild(textc);
			option4.appendChild(textd);
			option5.appendChild(texte); */
			option6.appendChild(textf);
			option7.appendChild(textg);
			option8.appendChild(texth);
			option9.appendChild(texti);
			option10.appendChild(textj);
			option11.appendChild(textk);
			option12.appendChild(textm);
			option13.appendChild(textl);
			option14.appendChild(textn);
			option15.appendChild(texto);
			option16.appendChild(textp);
			option17.appendChild(textq);
			option18.appendChild(textr);
			option19.appendChild(texts);
			option20.appendChild(textt);
			option21.appendChild(textu);
			option22.appendChild(textv);
			option23.appendChild(textw);
			option24.appendChild(textx);
			option25.appendChild(texty);
			/* select.appendChild(optionGS); */
		/* 	 select.appendChild(optionA);
			 select.appendChild(optionB);
			 select.appendChild(optionC);
			 select.appendChild(optionD);
			 select.appendChild(optionE);
			 select.appendChild(optionF);
			 select.appendChild(optionG); */
			 
			 inputDATA.setAttribute("class","day");
			 select1.appendChild(option25)
			/* select1.appendChild(option1)
			 select1.appendChild(option2)
			 select1.appendChild(option3)
			 select1.appendChild(option4)
			 select1.appendChild(option5) */
			 select1.appendChild(option6)
			 select1.appendChild(option7)
			 select1.appendChild(option8)
			 select1.appendChild(option9)
			 select1.appendChild(option10)
			 select1.appendChild(option11)
			 select1.appendChild(option12)
			 select1.appendChild(option13)
			 select1.appendChild(option14)
			 select1.appendChild(option15)
			 select1.appendChild(option16)
			 select1.appendChild(option17)
			 select1.appendChild(option18)
			 select1.appendChild(option19)
			 select1.appendChild(option20)
			 select1.appendChild(option21)
			 select1.appendChild(option22)
			 select1.appendChild(option23)
			 select1.appendChild(option24)
			 
			 select2.appendChild(option2525a)
			 /* select2.appendChild(option11a)
			 select2.appendChild(option22a)
			 select2.appendChild(option33a)
			 select2.appendChild(option44a)
			 select2.appendChild(option55a) */
			 select2.appendChild(option66a)
			 select2.appendChild(option77a)
			 select2.appendChild(option88a)
			 select2.appendChild(option99a)
			 select2.appendChild(option1010a)
			 select2.appendChild(option1111a)
			 select2.appendChild(option1212a)
			 select2.appendChild(option1313a)
			 select2.appendChild(option1414a)
			 select2.appendChild(option1515a)
			 select2.appendChild(option1616a)
			 select2.appendChild(option1717a)
			 select2.appendChild(option1818a)
			 select2.appendChild(option1919a)
			 select2.appendChild(option2020a)
			 select2.appendChild(option2121a)
			 select2.appendChild(option2222a)
			 select2.appendChild(option2323a)
			 select2.appendChild(option2424a)
			 
			 
			 li1.appendChild(inputDATA);
			 /* li2.appendChild(text1); */
			 li3.appendChild(select1)
			 li4.appendChild(text2);
			 li5.appendChild(select2);
			 button.appendChild(img);
			 li6.appendChild(button);
			 ul.appendChild(li1)
			 /* ul.appendChild(li2) */
			 ul.appendChild(li3)
			 ul.appendChild(li4)
			 ul.appendChild(li5)
			 ul.appendChild(li6)
			 ul.setAttribute("class","timeUL");
			boxX.appendChild(ul);
			var DEL=document.getElementsByClassName("DEL");
			for(var t=0;t<DEL.length;t++){
				DEL[t].num=t;
				DEL[t].onclick=function(){
					var r=this.num;
					
							var flag=confirm("确认删除吗？");
							if(flag){
								if(r==0){
									AlltimeValue1=0
									weeka=""
									starttimea=""
									endtimea=""
								}else if(r==1){
									AlltimeValue2=0
									weekb=""
									starttimeb=""
									endtimeb=""
								}else if(r==2){
									AlltimeValue3=0
									weekc=""
									starttimec=""
									endtimec=""
								}else if(r==3){
									AlltimeValue4=0
									weekd=""
									starttimed=""
									endtimed=""
								}else if(r==4){
									AlltimeValue5=0
									weeke=""
									starttimee=""
									endtimee=""
								}else if(r==5){
									AlltimeValue6=0
									weekf=""
									starttimef=""
									endtimef=""
								}else if(r==6){
									AlltimeValue7=0
									weekg=""
									starttimeg=""
									endtimeg=""
								}
						var	ul=this.parentNode.parentNode;
							ul.parentNode.removeChild(ul);
						    ul=null;
				OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
				ClassTimeX.value="总课时："+OKTimeValue;
				moneyA=$("#AllmeonyB").val();
				AllmeonyX.value="总费用："+OKTimeValue*moneyA
				/* console.log(OKTimeValue)
				console.log(AllmeonyB) */
				}
				}
			}
			
		var allTimeSelect=document.getElementsByClassName("timeclass");
		var timeUL=document.getElementsByClassName("timeUL");
			for(p=2;p<allTimeSelect.length-1;p++){
				select1.setAttribute("id","timeclass"+p+"");
				select2.setAttribute("id","timeclass"+(p+1)+"");
			}
			if(timeUL.length>7){
				alert("数量超载")
			}
			var AllDay=document.getElementsByClassName("day");
			
			if(AllDay.length-1<1){
				inputDATA.setAttribute("id","dayID1");
				var Datim=new Date()
				   console.log(Datim)
				   var year=Datim.getFullYear()
				   var month=Datim.getMonth()+1;
				   var day=Datim.getDate();
				   console.log(year)
				   console.log(month)
				   console.log(day)
				  var ALLYMD= year+"-"+month+"-"+day
				  console.log(ALLYMD)
				 var o=document.getElementById("dayID1");
				o.value=ALLYMD;
				
			}
			
			
			for(var q=2;q<=AllDay.length;q++){
				
				inputDATA.setAttribute("id","dayID"+q+"");
				if(q>AllDay.length-1){
					var Datim=new Date()
					   console.log(Datim)
					   var year=Datim.getFullYear()
					   var month=Datim.getMonth()+1;
					   var day=Datim.getDate();
					   console.log(year)
					   console.log(month)
					   console.log(day)
					  var ALLYMD= year+"-"+month+"-"+day
					  console.log(ALLYMD)
					 var o=document.getElementById("dayID"+q+"");
					o.value=ALLYMD;
				}
			
			}
			
				
		/* 2 */
			$("#timeclass2").change(function(){
				timeValueX=$("#timeclass"+(p-1)+"").find("option:selected").text();
				timeValueH=$("#timeclass"+p+"").find("option:selected").text();
				AlltimeValue2=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
		
		
		
		/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
		
		
		starttimeb=timeValueX;
		endtimeb=timeValueH;
		// if(starttimeb=="开始时间"){
		// 	starttimeb=0;
		// }else if(starttimeb=="凌晨1点"){
		// 	starttimeb="01:00";
		// }else if(starttimeb=="凌晨2点"){
		// 	starttimeb="02:00";
		// }else if(starttimeb=="凌晨3点"){
		// 	starttimeb="03:00";
		// }else if(starttimeb=="凌晨4点"){
		// 	starttimeb="04:00";
		// }else if(starttimeb=="凌晨5点"){
		// 	starttimeb="05:00";
		// }else if(starttimeb=="凌晨6点"){
		// 	starttimeb="06:00";
		// }else if(starttimeb=="凌晨7点"){
		// 	starttimeb="07:00";
		// }else if(starttimeb=="上午8点"){
		// 	starttimeb="08:00";
		// }else if(starttimeb=="上午9点"){
		// 	starttimeb="09:00";
		// }else if(starttimeb=="上午10点"){
		// 	starttimeb="10:00";
		// }else if(starttimeb=="上午11点"){
		// 	starttimeb="11:00";
		// }else if(starttimeb=="中午12点"){
		// 	starttimeb="12:00";
		// }else if(starttimeb=="下午13点"){
		// 	starttimeb="13:00";
		// }else if(starttimeb=="下午14点"){
		// 	starttimeb="14:00";
		// }else if(starttimeb=="下午15点"){
		// 	starttimeb="15:00";
		// }else if(starttimeb=="下午16点"){
		// 	starttimeb="16:00";
		// }else if(starttimeb=="下午17点"){
		// 	starttimeb="17:00";
		// }else if(starttimeb=="下午18点"){
		// 	starttimeb="18:00";
		// }else if(starttimeb=="下午19点"){
		// 	starttimeb="19:00";
		// }else if(starttimeb=="夜晚20点"){
		// 	starttimeb="20:00";
		// }else if(starttimeb=="夜晚21点"){
		// 	starttimeb="21:00";
		// }else if(starttimeb=="夜晚22点"){
		// 	starttimeb="22:00";
		// }else if(starttimeb=="夜晚23点"){
		// 	starttimeb="23:00";
		// }else if(starttimeb=="午夜24点"){
		// 	starttimeb="24:00";
		// }
		
		// if(endtimeb=="结束时间"){
		// 	endtimeb=0;
		// }else if(endtimeb=="凌晨1点"){
		// 	endtimeb="01:00";
		// }else if(endtimeb=="凌晨2点"){
		// 	endtimeb="02:00";
		// }else if(endtimeb=="凌晨3点"){
		// 	endtimeb="03:00";
		// }else if(endtimeb=="凌晨4点"){
		// 	endtimeb="04:00";
		// }else if(endtimeb=="凌晨5点"){
		// 	endtimeb="05:00";
		// }else if(endtimeb=="凌晨6点"){
		// 	endtimeb="06:00";
		// }else if(endtimeb=="凌晨7点"){
		// 	endtimeb="07:00";
		// }else if(endtimeb=="上午8点"){
		// 	endtimeb="08:00";
		// }else if(endtimeb=="上午9点"){
		// 	endtimeb="09:00";
		// }else if(endtimeb=="上午10点"){
		// 	endtimeb="10:00";
		// }else if(endtimeb=="上午11点"){
		// 	endtimeb="11:00";
		// }else if(endtimeb=="中午12点"){
		// 	endtimeb="12:00";
		// }else if(endtimeb=="下午13点"){
		// 	endtimeb="13:00";
		// }else if(endtimeb=="下午14点"){
		// 	endtimeb="14:00";
		// }else if(endtimeb=="下午15点"){
		// 	endtimeb="15:00";
		// }else if(endtimeb=="下午16点"){
		// 	endtimeb="16:00";
		// }else if(endtimeb=="下午17点"){
		// 	endtimeb="17:00";
		// }else if(endtimeb=="下午18点"){
		// 	endtimeb="18:00";
		// }else if(endtimeb=="下午19点"){
		// 	endtimeb="19:00";
		// }else if(endtimeb=="夜晚20点"){
		// 	endtimeb="20:00";
		// }else if(endtimeb=="夜晚21点"){
		// 	endtimeb="21:00";
		// }else if(endtimeb=="夜晚22点"){
		// 	endtimeb="22:00";
		// }else if(endtimeb=="夜晚23点"){
		// 	endtimeb="23:00";
		// }else if(endtimeb=="午夜24点"){
		// 	endtimeb="24:00";
		// }
		
		/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
		
		
		
		
		if(isNaN(AlltimeValue2)){
			AlltimeValue2=0
		}
		/* console.log(AlltimeValue2) */
		OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
		ClassTimeX.value="总课时："+OKTimeValue;
		moneyA=$("#AllmeonyB").val();
		AllmeonyX.value="总费用："+OKTimeValue*moneyA;
				$("#timeclass3").change(function(){
				timeValueX=$("#timeclass"+(p-1)+"").find("option:selected").text();
				timeValueH=$("#timeclass"+p+"").find("option:selected").text();
				AlltimeValue2=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
			
			/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
			
			
			starttimeb=timeValueX;
			endtimeb=timeValueH;
			// if(starttimeb=="开始时间"){
			// 	starttimeb=0;
			// }else if(starttimeb=="凌晨1点"){
			// 	starttimeb="01:00";
			// }else if(starttimeb=="凌晨2点"){
			// 	starttimeb="02:00";
			// }else if(starttimeb=="凌晨3点"){
			// 	starttimeb="03:00";
			// }else if(starttimeb=="凌晨4点"){
			// 	starttimeb="04:00";
			// }else if(starttimeb=="凌晨5点"){
			// 	starttimeb="05:00";
			// }else if(starttimeb=="凌晨6点"){
			// 	starttimeb="06:00";
			// }else if(starttimeb=="凌晨7点"){
			// 	starttimeb="07:00";
			// }else if(starttimeb=="上午8点"){
			// 	starttimeb="08:00";
			// }else if(starttimeb=="上午9点"){
			// 	starttimeb="09:00";
			// }else if(starttimeb=="上午10点"){
			// 	starttimeb="10:00";
			// }else if(starttimeb=="上午11点"){
			// 	starttimeb="11:00";
			// }else if(starttimeb=="中午12点"){
			// 	starttimeb="12:00";
			// }else if(starttimeb=="下午13点"){
			// 	starttimeb="13:00";
			// }else if(starttimeb=="下午14点"){
			// 	starttimeb="14:00";
			// }else if(starttimeb=="下午15点"){
			// 	starttimeb="15:00";
			// }else if(starttimeb=="下午16点"){
			// 	starttimeb="16:00";
			// }else if(starttimeb=="下午17点"){
			// 	starttimeb="17:00";
			// }else if(starttimeb=="下午18点"){
			// 	starttimeb="18:00";
			// }else if(starttimeb=="下午19点"){
			// 	starttimeb="19:00";
			// }else if(starttimeb=="夜晚20点"){
			// 	starttimeb="20:00";
			// }else if(starttimeb=="夜晚21点"){
			// 	starttimeb="21:00";
			// }else if(starttimeb=="夜晚22点"){
			// 	starttimeb="22:00";
			// }else if(starttimeb=="夜晚23点"){
			// 	starttimeb="23:00";
			// }else if(starttimeb=="午夜24点"){
			// 	starttimeb="24:00";
			// }
			
			// if(endtimeb=="结束时间"){
			// 	endtimeb=0;
			// }else if(endtimeb=="凌晨1点"){
			// 	endtimeb="01:00";
			// }else if(endtimeb=="凌晨2点"){
			// 	endtimeb="02:00";
			// }else if(endtimeb=="凌晨3点"){
			// 	endtimeb="03:00";
			// }else if(endtimeb=="凌晨4点"){
			// 	endtimeb="04:00";
			// }else if(endtimeb=="凌晨5点"){
			// 	endtimeb="05:00";
			// }else if(endtimeb=="凌晨6点"){
			// 	endtimeb="06:00";
			// }else if(endtimeb=="凌晨7点"){
			// 	endtimeb="07:00";
			// }else if(endtimeb=="上午8点"){
			// 	endtimeb="08:00";
			// }else if(endtimeb=="上午9点"){
			// 	endtimeb="09:00";
			// }else if(endtimeb=="上午10点"){
			// 	endtimeb="10:00";
			// }else if(endtimeb=="上午11点"){
			// 	endtimeb="11:00";
			// }else if(endtimeb=="中午12点"){
			// 	endtimeb="12:00";
			// }else if(endtimeb=="下午13点"){
			// 	endtimeb="13:00";
			// }else if(endtimeb=="下午14点"){
			// 	endtimeb="14:00";
			// }else if(endtimeb=="下午15点"){
			// 	endtimeb="15:00";
			// }else if(endtimeb=="下午16点"){
			// 	endtimeb="16:00";
			// }else if(endtimeb=="下午17点"){
			// 	endtimeb="17:00";
			// }else if(endtimeb=="下午18点"){
			// 	endtimeb="18:00";
			// }else if(endtimeb=="下午19点"){
			// 	endtimeb="19:00";
			// }else if(endtimeb=="夜晚20点"){
			// 	endtimeb="20:00";
			// }else if(endtimeb=="夜晚21点"){
			// 	endtimeb="21:00";
			// }else if(endtimeb=="夜晚22点"){
			// 	endtimeb="22:00";
			// }else if(endtimeb=="夜晚23点"){
			// 	endtimeb="23:00";
			// }else if(endtimeb=="午夜24点"){
			// 	endtimeb="24:00";
			// }
			
			/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
			
			
			 if(isNaN(AlltimeValue2)){
				AlltimeValue2=0
			}
			/* console.log(AlltimeValue2) */
			OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
			ClassTimeX.value="总课时："+OKTimeValue;
			moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA;
			});
			});
			
		/* 3 */	
			$("#timeclass4").change(function(){
					timeValueX=$("#timeclass"+(p-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+p+"").find("option:selected").text();
					AlltimeValue3=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
			
			/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
			
			
			starttimec=timeValueX;
			endtimec=timeValueH;
			// if(starttimec=="开始时间"){
			// 	starttimec=0;
			// }else if(starttimec=="凌晨1点"){
			// 	starttimec="01:00";
			// }else if(starttimec=="凌晨2点"){
			// 	starttimec="02:00";
			// }else if(starttimec=="凌晨3点"){
			// 	starttimec="03:00";
			// }else if(starttimec=="凌晨4点"){
			// 	starttimec="04:00";
			// }else if(starttimec=="凌晨5点"){
			// 	starttimec="05:00";
			// }else if(starttimec=="凌晨6点"){
			// 	starttimec="06:00";
			// }else if(starttimec=="凌晨7点"){
			// 	starttimec="07:00";
			// }else if(starttimec=="上午8点"){
			// 	starttimec="08:00";
			// }else if(starttimec=="上午9点"){
			// 	starttimec="09:00";
			// }else if(starttimec=="上午10点"){
			// 	starttimec="10:00";
			// }else if(starttimec=="上午11点"){
			// 	starttimec="11:00";
			// }else if(starttimec=="中午12点"){
			// 	starttimec="12:00";
			// }else if(starttimec=="下午13点"){
			// 	starttimec="13:00";
			// }else if(starttimec=="下午14点"){
			// 	starttimec="14:00";
			// }else if(starttimec=="下午15点"){
			// 	starttimec="15:00";
			// }else if(starttimec=="下午16点"){
			// 	starttimec="16:00";
			// }else if(starttimec=="下午17点"){
			// 	starttimec="17:00";
			// }else if(starttimec=="下午18点"){
			// 	starttimec="18:00";
			// }else if(starttimec=="下午19点"){
			// 	starttimec="19:00";
			// }else if(starttimec=="夜晚20点"){
			// 	starttimec="20:00";
			// }else if(starttimec=="夜晚21点"){
			// 	starttimec="21:00";
			// }else if(starttimec=="夜晚22点"){
			// 	starttimec="22:00";
			// }else if(starttimec=="夜晚23点"){
			// 	starttimec="23:00";
			// }else if(starttimec=="午夜24点"){
			// 	starttimec="24:00";
			// }
			
			// if(endtimec=="结束时间"){
			// 	endtimec=0;
			// }else if(endtimec=="凌晨1点"){
			// 	endtimec="01:00";
			// }else if(endtimec=="凌晨2点"){
			// 	endtimec="02:00";
			// }else if(endtimec=="凌晨3点"){
			// 	endtimec="03:00";
			// }else if(endtimec=="凌晨4点"){
			// 	endtimec="04:00";
			// }else if(endtimec=="凌晨5点"){
			// 	endtimec="05:00";
			// }else if(endtimec=="凌晨6点"){
			// 	endtimec="06:00";
			// }else if(endtimec=="凌晨7点"){
			// 	endtimec="07:00";
			// }else if(endtimec=="上午8点"){
			// 	endtimec="08:00";
			// }else if(endtimec=="上午9点"){
			// 	endtimec="09:00";
			// }else if(endtimec=="上午10点"){
			// 	endtimec="10:00";
			// }else if(endtimec=="上午11点"){
			// 	endtimec="11:00";
			// }else if(endtimec=="中午12点"){
			// 	endtimec="12:00";
			// }else if(endtimec=="下午13点"){
			// 	endtimec="13:00";
			// }else if(endtimec=="下午14点"){
			// 	endtimec="14:00";
			// }else if(endtimec=="下午15点"){
			// 	endtimec="15:00";
			// }else if(endtimec=="下午16点"){
			// 	endtimec="16:00";
			// }else if(endtimec=="下午17点"){
			// 	endtimec="17:00";
			// }else if(endtimec=="下午18点"){
			// 	endtimec="18:00";
			// }else if(endtimec=="下午19点"){
			// 	endtimec="19:00";
			// }else if(endtimec=="夜晚20点"){
			// 	endtimec="20:00";
			// }else if(endtimec=="夜晚21点"){
			// 	endtimec="21:00";
			// }else if(endtimec=="夜晚22点"){
			// 	endtimec="22:00";
			// }else if(endtimec=="夜晚23点"){
			// 	endtimec="23:00";
			// }else if(endtimec=="午夜24点"){
			// 	endtimec="24:00";
			// }
			
			/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
			
			
			
			
			
			if(isNaN(AlltimeValue3)){
				AlltimeValue3=0
			}
			/* console.log(AlltimeValue3) */
			OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
			ClassTimeX.value="总课时："+OKTimeValue;
			moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA;
					$("#timeclass5").change(function(){
					timeValueX=$("#timeclass"+(p-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+p+"").find("option:selected").text();
					AlltimeValue3=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
			
			
			
			/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
			
			
			starttimec=timeValueX;
			endtimec=timeValueH;
			// if(starttimec=="开始时间"){
			// 	starttimec=0;
			// }else if(starttimec=="凌晨1点"){
			// 	starttimec="01:00";
			// }else if(starttimec=="凌晨2点"){
			// 	starttimec="02:00";
			// }else if(starttimec=="凌晨3点"){
			// 	starttimec="03:00";
			// }else if(starttimec=="凌晨4点"){
			// 	starttimec="04:00";
			// }else if(starttimec=="凌晨5点"){
			// 	starttimec="05:00";
			// }else if(starttimec=="凌晨6点"){
			// 	starttimec="06:00";
			// }else if(starttimec=="凌晨7点"){
			// 	starttimec="07:00";
			// }else if(starttimec=="上午8点"){
			// 	starttimec="08:00";
			// }else if(starttimec=="上午9点"){
			// 	starttimec="09:00";
			// }else if(starttimec=="上午10点"){
			// 	starttimec="10:00";
			// }else if(starttimec=="上午11点"){
			// 	starttimec="11:00";
			// }else if(starttimec=="中午12点"){
			// 	starttimec="12:00";
			// }else if(starttimec=="下午13点"){
			// 	starttimec="13:00";
			// }else if(starttimec=="下午14点"){
			// 	starttimec="14:00";
			// }else if(starttimec=="下午15点"){
			// 	starttimec="15:00";
			// }else if(starttimec=="下午16点"){
			// 	starttimec="16:00";
			// }else if(starttimec=="下午17点"){
			// 	starttimec="17:00";
			// }else if(starttimec=="下午18点"){
			// 	starttimec="18:00";
			// }else if(starttimec=="下午19点"){
			// 	starttimec="19:00";
			// }else if(starttimec=="夜晚20点"){
			// 	starttimec="20:00";
			// }else if(starttimec=="夜晚21点"){
			// 	starttimec="21:00";
			// }else if(starttimec=="夜晚22点"){
			// 	starttimec="22:00";
			// }else if(starttimec=="夜晚23点"){
			// 	starttimec="23:00";
			// }else if(starttimec=="午夜24点"){
			// 	starttimec="24:00";
			// }
			
			// if(endtimec=="结束时间"){
			// 	endtimec=0;
			// }else if(endtimec=="凌晨1点"){
			// 	endtimec="01:00";
			// }else if(endtimec=="凌晨2点"){
			// 	endtimec="02:00";
			// }else if(endtimec=="凌晨3点"){
			// 	endtimec="03:00";
			// }else if(endtimec=="凌晨4点"){
			// 	endtimec="04:00";
			// }else if(endtimec=="凌晨5点"){
			// 	endtimec="05:00";
			// }else if(endtimec=="凌晨6点"){
			// 	endtimec="06:00";
			// }else if(endtimec=="凌晨7点"){
			// 	endtimec="07:00";
			// }else if(endtimec=="上午8点"){
			// 	endtimec="08:00";
			// }else if(endtimec=="上午9点"){
			// 	endtimec="09:00";
			// }else if(endtimec=="上午10点"){
			// 	endtimec="10:00";
			// }else if(endtimec=="上午11点"){
			// 	endtimec="11:00";
			// }else if(endtimec=="中午12点"){
			// 	endtimec="12:00";
			// }else if(endtimec=="下午13点"){
			// 	endtimec="13:00";
			// }else if(endtimec=="下午14点"){
			// 	endtimec="14:00";
			// }else if(endtimec=="下午15点"){
			// 	endtimec="15:00";
			// }else if(endtimec=="下午16点"){
			// 	endtimec="16:00";
			// }else if(endtimec=="下午17点"){
			// 	endtimec="17:00";
			// }else if(endtimec=="下午18点"){
			// 	endtimec="18:00";
			// }else if(endtimec=="下午19点"){
			// 	endtimec="19:00";
			// }else if(endtimec=="夜晚20点"){
			// 	endtimec="20:00";
			// }else if(endtimec=="夜晚21点"){
			// 	endtimec="21:00";
			// }else if(endtimec=="夜晚22点"){
			// 	endtimec="22:00";
			// }else if(endtimec=="夜晚23点"){
			// 	endtimec="23:00";
			// }else if(endtimec=="午夜24点"){
			// 	endtimec="24:00";
			// }
			
			/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
			
			
			
				 if(isNaN(AlltimeValue3)){
					AlltimeValue3=0
				}
				/* console.log(AlltimeValue2) */
				OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
				ClassTimeX.value="总课时："+OKTimeValue;
				moneyA=$("#AllmeonyB").val();
				AllmeonyX.value="总费用："+OKTimeValue*moneyA;
				});
				});
			/* 4 */
			
			$("#timeclass6").change(function(){
					timeValueX=$("#timeclass"+(p-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+p+"").find("option:selected").text();
					AlltimeValue4=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
			
			
			/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
			
			
			starttimed=timeValueX;
			endtimed=timeValueH;
			// if(starttimed=="开始时间"){
			// 	starttimed=0;
			// }else if(starttimed=="凌晨1点"){
			// 	starttimed="01:00";
			// }else if(starttimed=="凌晨2点"){
			// 	starttimed="02:00";
			// }else if(starttimed=="凌晨3点"){
			// 	starttimed="03:00";
			// }else if(starttimed=="凌晨4点"){
			// 	starttimed="04:00";
			// }else if(starttimed=="凌晨5点"){
			// 	starttimed="05:00";
			// }else if(starttimed=="凌晨6点"){
			// 	starttimed="06:00";
			// }else if(starttimed=="凌晨7点"){
			// 	starttimed="07:00";
			// }else if(starttimed=="上午8点"){
			// 	starttimed="08:00";
			// }else if(starttimed=="上午9点"){
			// 	starttimed="09:00";
			// }else if(starttimed=="上午10点"){
			// 	starttimed="10:00";
			// }else if(starttimed=="上午11点"){
			// 	starttimed="11:00";
			// }else if(starttimed=="中午12点"){
			// 	starttimed="12:00";
			// }else if(starttimed=="下午13点"){
			// 	starttimed="13:00";
			// }else if(starttimed=="下午14点"){
			// 	starttimed="14:00";
			// }else if(starttimed=="下午15点"){
			// 	starttimed="15:00";
			// }else if(starttimed=="下午16点"){
			// 	starttimed="16:00";
			// }else if(starttimed=="下午17点"){
			// 	starttimed="17:00";
			// }else if(starttimed=="下午18点"){
			// 	starttimed="18:00";
			// }else if(starttimed=="下午19点"){
			// 	starttimed="19:00";
			// }else if(starttimed=="夜晚20点"){
			// 	starttimed="20:00";
			// }else if(starttimed=="夜晚21点"){
			// 	starttimed="21:00";
			// }else if(starttimed=="夜晚22点"){
			// 	starttimed="22:00";
			// }else if(starttimed=="夜晚23点"){
			// 	starttimed="23:00";
			// }else if(starttimed=="午夜24点"){
			// 	starttimed="24:00";
			// }
			
			// if(endtimed=="结束时间"){
			// 	endtimed=0;
			// }else if(endtimed=="凌晨1点"){
			// 	endtimed="01:00";
			// }else if(endtimed=="凌晨2点"){
			// 	endtimed="02:00";
			// }else if(endtimed=="凌晨3点"){
			// 	endtimed="03:00";
			// }else if(endtimed=="凌晨4点"){
			// 	endtimed="04:00";
			// }else if(endtimed=="凌晨5点"){
			// 	endtimed="05:00";
			// }else if(endtimed=="凌晨6点"){
			// 	endtimed="06:00";
			// }else if(endtimed=="凌晨7点"){
			// 	endtimed="07:00";
			// }else if(endtimed=="上午8点"){
			// 	endtimed="08:00";
			// }else if(endtimed=="上午9点"){
			// 	endtimed="09:00";
			// }else if(endtimed=="上午10点"){
			// 	endtimed="10:00";
			// }else if(endtimed=="上午11点"){
			// 	endtimed="11:00";
			// }else if(endtimed=="中午12点"){
			// 	endtimed="12:00";
			// }else if(endtimed=="下午13点"){
			// 	endtimed="13:00";
			// }else if(endtimed=="下午14点"){
			// 	endtimed="14:00";
			// }else if(endtimed=="下午15点"){
			// 	endtimed="15:00";
			// }else if(endtimed=="下午16点"){
			// 	endtimed="16:00";
			// }else if(endtimed=="下午17点"){
			// 	endtimed="17:00";
			// }else if(endtimed=="下午18点"){
			// 	endtimed="18:00";
			// }else if(endtimed=="下午19点"){
			// 	endtimed="19:00";
			// }else if(endtimed=="夜晚20点"){
			// 	endtimed="20:00";
			// }else if(endtimed=="夜晚21点"){
			// 	endtimed="21:00";
			// }else if(endtimed=="夜晚22点"){
			// 	endtimed="22:00";
			// }else if(endtimed=="夜晚23点"){
			// 	endtimed="23:00";
			// }else if(endtimed=="午夜24点"){
			// 	endtimed="24:00";
			// }
			
			/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
			
			
			
			
			
			
			
			if(isNaN(AlltimeValue4)){
				AlltimeValue4=0
			}
			/* console.log(AlltimeValue4) */
			OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
			ClassTimeX.value="总课时："+OKTimeValue;
			moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA;
					$("#timeclass7").change(function(){
					timeValueX=$("#timeclass"+(p-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+p+"").find("option:selected").text();
					AlltimeValue4=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
			
			
			/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
			
			
			starttimed=timeValueX;
			endtimed=timeValueH;
			// if(starttimed=="开始时间"){
			// 	starttimed=0;
			// }else if(starttimed=="凌晨1点"){
			// 	starttimed="01:00";
			// }else if(starttimed=="凌晨2点"){
			// 	starttimed="02:00";
			// }else if(starttimed=="凌晨3点"){
			// 	starttimed="03:00";
			// }else if(starttimed=="凌晨4点"){
			// 	starttimed="04:00";
			// }else if(starttimed=="凌晨5点"){
			// 	starttimed="05:00";
			// }else if(starttimed=="凌晨6点"){
			// 	starttimed="06:00";
			// }else if(starttimed=="凌晨7点"){
			// 	starttimed="07:00";
			// }else if(starttimed=="上午8点"){
			// 	starttimed="08:00";
			// }else if(starttimed=="上午9点"){
			// 	starttimed="09:00";
			// }else if(starttimed=="上午10点"){
			// 	starttimed="10:00";
			// }else if(starttimed=="上午11点"){
			// 	starttimed="11:00";
			// }else if(starttimed=="中午12点"){
			// 	starttimed="12:00";
			// }else if(starttimed=="下午13点"){
			// 	starttimed="13:00";
			// }else if(starttimed=="下午14点"){
			// 	starttimed="14:00";
			// }else if(starttimed=="下午15点"){
			// 	starttimed="15:00";
			// }else if(starttimed=="下午16点"){
			// 	starttimed="16:00";
			// }else if(starttimed=="下午17点"){
			// 	starttimed="17:00";
			// }else if(starttimed=="下午18点"){
			// 	starttimed="18:00";
			// }else if(starttimed=="下午19点"){
			// 	starttimed="19:00";
			// }else if(starttimed=="夜晚20点"){
			// 	starttimed="20:00";
			// }else if(starttimed=="夜晚21点"){
			// 	starttimed="21:00";
			// }else if(starttimed=="夜晚22点"){
			// 	starttimed="22:00";
			// }else if(starttimed=="夜晚23点"){
			// 	starttimed="23:00";
			// }else if(starttimed=="午夜24点"){
			// 	starttimed="24:00";
			// }
			
			// if(endtimed=="结束时间"){
			// 	endtimed=0;
			// }else if(endtimed=="凌晨1点"){
			// 	endtimed="01:00";
			// }else if(endtimed=="凌晨2点"){
			// 	endtimed="02:00";
			// }else if(endtimed=="凌晨3点"){
			// 	endtimed="03:00";
			// }else if(endtimed=="凌晨4点"){
			// 	endtimed="04:00";
			// }else if(endtimed=="凌晨5点"){
			// 	endtimed="05:00";
			// }else if(endtimed=="凌晨6点"){
			// 	endtimed="06:00";
			// }else if(endtimed=="凌晨7点"){
			// 	endtimed="07:00";
			// }else if(endtimed=="上午8点"){
			// 	endtimed="08:00";
			// }else if(endtimed=="上午9点"){
			// 	endtimed="09:00";
			// }else if(endtimed=="上午10点"){
			// 	endtimed="10:00";
			// }else if(endtimed=="上午11点"){
			// 	endtimed="11:00";
			// }else if(endtimed=="中午12点"){
			// 	endtimed="12:00";
			// }else if(endtimed=="下午13点"){
			// 	endtimed="13:00";
			// }else if(endtimed=="下午14点"){
			// 	endtimed="14:00";
			// }else if(endtimed=="下午15点"){
			// 	endtimed="15:00";
			// }else if(endtimed=="下午16点"){
			// 	endtimed="16:00";
			// }else if(endtimed=="下午17点"){
			// 	endtimed="17:00";
			// }else if(endtimed=="下午18点"){
			// 	endtimed="18:00";
			// }else if(endtimed=="下午19点"){
			// 	endtimed="19:00";
			// }else if(endtimed=="夜晚20点"){
			// 	endtimed="20:00";
			// }else if(endtimed=="夜晚21点"){
			// 	endtimed="21:00";
			// }else if(endtimed=="夜晚22点"){
			// 	endtimed="22:00";
			// }else if(endtimed=="夜晚23点"){
			// 	endtimed="23:00";
			// }else if(endtimed=="午夜24点"){
			// 	endtimed="24:00";
			// }
			
			/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
			
			
			
				 if(isNaN(AlltimeValue4)){
					AlltimeValue4=0
				}
				/* console.log(AlltimeValue4) */
				OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
				ClassTimeX.value="总课时："+OKTimeValue;
				moneyA=$("#AllmeonyB").val();
				AllmeonyX.value="总费用："+OKTimeValue*moneyA;
				});
				});
			
			/* 5 */
			$("#timeclass8").change(function(){
					timeValueX=$("#timeclass"+(p-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+p+"").find("option:selected").text();
					AlltimeValue5=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
		
		
		/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
		
		
		starttimee=timeValueX;
		endtimee=timeValueH;
		// if(starttimee=="开始时间"){
		// 	starttimee=0;
		// }else if(starttimee=="凌晨1点"){
		// 	starttimee="01:00";
		// }else if(starttimee=="凌晨2点"){
		// 	starttimee="02:00";
		// }else if(starttimee=="凌晨3点"){
		// 	starttimee="03:00";
		// }else if(starttimee=="凌晨4点"){
		// 	starttimee="04:00";
		// }else if(starttimee=="凌晨5点"){
		// 	starttimee="05:00";
		// }else if(starttimee=="凌晨6点"){
		// 	starttimee="06:00";
		// }else if(starttimee=="凌晨7点"){
		// 	starttimee="07:00";
		// }else if(starttimee=="上午8点"){
		// 	starttimee="08:00";
		// }else if(starttimee=="上午9点"){
		// 	starttimee="09:00";
		// }else if(starttimee=="上午10点"){
		// 	starttimee="10:00";
		// }else if(starttimee=="上午11点"){
		// 	starttimee="11:00";
		// }else if(starttimee=="中午12点"){
		// 	starttimee="12:00";
		// }else if(starttimee=="下午13点"){
		// 	starttimee="13:00";
		// }else if(starttimee=="下午14点"){
		// 	starttimee="14:00";
		// }else if(starttimee=="下午15点"){
		// 	starttimee="15:00";
		// }else if(starttimee=="下午16点"){
		// 	starttimee="16:00";
		// }else if(starttimee=="下午17点"){
		// 	starttimee="17:00";
		// }else if(starttimee=="下午18点"){
		// 	starttimee="18:00";
		// }else if(starttimee=="下午19点"){
		// 	starttimee="19:00";
		// }else if(starttimee=="夜晚20点"){
		// 	starttimee="20:00";
		// }else if(starttimee=="夜晚21点"){
		// 	starttimee="21:00";
		// }else if(starttimee=="夜晚22点"){
		// 	starttimee="22:00";
		// }else if(starttimee=="夜晚23点"){
		// 	starttimee="23:00";
		// }else if(starttimee=="午夜24点"){
		// 	starttimee="24:00";
		// }
		
		// if(endtimee=="结束时间"){
		// 	endtimee=0;
		// }else if(endtimee=="凌晨1点"){
		// 	endtimee="01:00";
		// }else if(endtimee=="凌晨2点"){
		// 	endtimee="02:00";
		// }else if(endtimee=="凌晨3点"){
		// 	endtimee="03:00";
		// }else if(endtimee=="凌晨4点"){
		// 	endtimee="04:00";
		// }else if(endtimee=="凌晨5点"){
		// 	endtimee="05:00";
		// }else if(endtimee=="凌晨6点"){
		// 	endtimee="06:00";
		// }else if(endtimee=="凌晨7点"){
		// 	endtimee="07:00";
		// }else if(endtimee=="上午8点"){
		// 	endtimee="08:00";
		// }else if(endtimee=="上午9点"){
		// 	endtimee="09:00";
		// }else if(endtimee=="上午10点"){
		// 	endtimee="10:00";
		// }else if(endtimee=="上午11点"){
		// 	endtimee="11:00";
		// }else if(endtimee=="中午12点"){
		// 	endtimee="12:00";
		// }else if(endtimee=="下午13点"){
		// 	endtimee="13:00";
		// }else if(endtimee=="下午14点"){
		// 	endtimee="14:00";
		// }else if(endtimee=="下午15点"){
		// 	endtimee="15:00";
		// }else if(endtimee=="下午16点"){
		// 	endtimee="16:00";
		// }else if(endtimee=="下午17点"){
		// 	endtimee="17:00";
		// }else if(endtimee=="下午18点"){
		// 	endtimee="18:00";
		// }else if(endtimee=="下午19点"){
		// 	endtimee="19:00";
		// }else if(endtimee=="夜晚20点"){
		// 	endtimee="20:00";
		// }else if(endtimee=="夜晚21点"){
		// 	endtimee="21:00";
		// }else if(endtimee=="夜晚22点"){
		// 	endtimee="22:00";
		// }else if(endtimee=="夜晚23点"){
		// 	endtimee="23:00";
		// }else if(endtimee=="午夜24点"){
		// 	endtimee="24:00";
		// }
		
		/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
		
		
		
		
		
			if(isNaN(AlltimeValue5)){
				AlltimeValue5=0
			}
			/* console.log(AlltimeValue5) */
			OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
			ClassTimeX.value="总课时："+OKTimeValue;
			moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA;
					$("#timeclass9").change(function(){
					timeValueX=$("#timeclass"+(p-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+p+"").find("option:selected").text();
					AlltimeValue5=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
				
				
				/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
				
				
				starttimee=timeValueX;
				endtimee=timeValueH;
				// if(starttimee=="开始时间"){
				// 	starttimee=0;
				// }else if(starttimee=="凌晨1点"){
				// 	starttimee="01:00";
				// }else if(starttimee=="凌晨2点"){
				// 	starttimee="02:00";
				// }else if(starttimee=="凌晨3点"){
				// 	starttimee="03:00";
				// }else if(starttimee=="凌晨4点"){
				// 	starttimee="04:00";
				// }else if(starttimee=="凌晨5点"){
				// 	starttimee="05:00";
				// }else if(starttimee=="凌晨6点"){
				// 	starttimee="06:00";
				// }else if(starttimee=="凌晨7点"){
				// 	starttimee="07:00";
				// }else if(starttimee=="上午8点"){
				// 	starttimee="08:00";
				// }else if(starttimee=="上午9点"){
				// 	starttimee="09:00";
				// }else if(starttimee=="上午10点"){
				// 	starttimee="10:00";
				// }else if(starttimee=="上午11点"){
				// 	starttimee="11:00";
				// }else if(starttimee=="中午12点"){
				// 	starttimee="12:00";
				// }else if(starttimee=="下午13点"){
				// 	starttimee="13:00";
				// }else if(starttimee=="下午14点"){
				// 	starttimee="14:00";
				// }else if(starttimee=="下午15点"){
				// 	starttimee="15:00";
				// }else if(starttimee=="下午16点"){
				// 	starttimee="16:00";
				// }else if(starttimee=="下午17点"){
				// 	starttimee="17:00";
				// }else if(starttimee=="下午18点"){
				// 	starttimee="18:00";
				// }else if(starttimee=="下午19点"){
				// 	starttimee="19:00";
				// }else if(starttimee=="夜晚20点"){
				// 	starttimee="20:00";
				// }else if(starttimee=="夜晚21点"){
				// 	starttimee="21:00";
				// }else if(starttimee=="夜晚22点"){
				// 	starttimee="22:00";
				// }else if(starttimee=="夜晚23点"){
				// 	starttimee="23:00";
				// }else if(starttimee=="午夜24点"){
				// 	starttimee="24:00";
				// }
				
				// if(endtimee=="结束时间"){
				// 	endtimee=0;
				// }else if(endtimee=="凌晨1点"){
				// 	endtimee="01:00";
				// }else if(endtimee=="凌晨2点"){
				// 	endtimee="02:00";
				// }else if(endtimee=="凌晨3点"){
				// 	endtimee="03:00";
				// }else if(endtimee=="凌晨4点"){
				// 	endtimee="04:00";
				// }else if(endtimee=="凌晨5点"){
				// 	endtimee="05:00";
				// }else if(endtimee=="凌晨6点"){
				// 	endtimee="06:00";
				// }else if(endtimee=="凌晨7点"){
				// 	endtimee="07:00";
				// }else if(endtimee=="上午8点"){
				// 	endtimee="08:00";
				// }else if(endtimee=="上午9点"){
				// 	endtimee="09:00";
				// }else if(endtimee=="上午10点"){
				// 	endtimee="10:00";
				// }else if(endtimee=="上午11点"){
				// 	endtimee="11:00";
				// }else if(endtimee=="中午12点"){
				// 	endtimee="12:00";
				// }else if(endtimee=="下午13点"){
				// 	endtimee="13:00";
				// }else if(endtimee=="下午14点"){
				// 	endtimee="14:00";
				// }else if(endtimee=="下午15点"){
				// 	endtimee="15:00";
				// }else if(endtimee=="下午16点"){
				// 	endtimee="16:00";
				// }else if(endtimee=="下午17点"){
				// 	endtimee="17:00";
				// }else if(endtimee=="下午18点"){
				// 	endtimee="18:00";
				// }else if(endtimee=="下午19点"){
				// 	endtimee="19:00";
				// }else if(endtimee=="夜晚20点"){
				// 	endtimee="20:00";
				// }else if(endtimee=="夜晚21点"){
				// 	endtimee="21:00";
				// }else if(endtimee=="夜晚22点"){
				// 	endtimee="22:00";
				// }else if(endtimee=="夜晚23点"){
				// 	endtimee="23:00";
				// }else if(endtimee=="午夜24点"){
				// 	endtimee="24:00";
				// }
				
				/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */ 
				 
				 
				 
				 
				 if(isNaN(AlltimeValue5)){
					AlltimeValue5=0
				}
				/* console.log(AlltimeValue5) */
				OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
				ClassTimeX.value="总课时："+OKTimeValue;
				moneyA=$("#AllmeonyB").val();
				AllmeonyX.value="总费用："+OKTimeValue*moneyA;
				});
				});
			
			
			
			/* 6 */
			
			$("#timeclass10").change(function(){
					timeValueX=$("#timeclass"+(p-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+p+"").find("option:selected").text();
					AlltimeValue6=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
			
			
			
			/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
			
			
			starttimef=timeValueX;
			endtimef=timeValueH;
			// if(starttimef=="开始时间"){
			// 	starttimef=0;
			// }else if(starttimef=="凌晨1点"){
			// 	starttimef="01:00";
			// }else if(starttimef=="凌晨2点"){
			// 	starttimef="02:00";
			// }else if(starttimef=="凌晨3点"){
			// 	starttimef="03:00";
			// }else if(starttimef=="凌晨4点"){
			// 	starttimef="04:00";
			// }else if(starttimef=="凌晨5点"){
			// 	starttimef="05:00";
			// }else if(starttimef=="凌晨6点"){
			// 	starttimef="06:00";
			// }else if(starttimef=="凌晨7点"){
			// 	starttimef="07:00";
			// }else if(starttimef=="上午8点"){
			// 	starttimef="08:00";
			// }else if(starttimef=="上午9点"){
			// 	starttimef="09:00";
			// }else if(starttimef=="上午10点"){
			// 	starttimef="10:00";
			// }else if(starttimef=="上午11点"){
			// 	starttimef="11:00";
			// }else if(starttimef=="中午12点"){
			// 	starttimef="12:00";
			// }else if(starttimef=="下午13点"){
			// 	starttimef="13:00";
			// }else if(starttimef=="下午14点"){
			// 	starttimef="14:00";
			// }else if(starttimef=="下午15点"){
			// 	starttimef="15:00";
			// }else if(starttimef=="下午16点"){
			// 	starttimef="16:00";
			// }else if(starttimef=="下午17点"){
			// 	starttimef="17:00";
			// }else if(starttimef=="下午18点"){
			// 	starttimef="18:00";
			// }else if(starttimef=="下午19点"){
			// 	starttimef="19:00";
			// }else if(starttimef=="夜晚20点"){
			// 	starttimef="20:00";
			// }else if(starttimef=="夜晚21点"){
			// 	starttimef="21:00";
			// }else if(starttimef=="夜晚22点"){
			// 	starttimef="22:00";
			// }else if(starttimef=="夜晚23点"){
			// 	starttimef="23:00";
			// }else if(starttimef=="午夜24点"){
			// 	starttimef="24:00";
			// }
			
			// if(endtimef=="结束时间"){
			// 	endtimef=0;
			// }else if(endtimef=="凌晨1点"){
			// 	endtimef="01:00";
			// }else if(endtimef=="凌晨2点"){
			// 	endtimef="02:00";
			// }else if(endtimef=="凌晨3点"){
			// 	endtimef="03:00";
			// }else if(endtimef=="凌晨4点"){
			// 	endtimef="04:00";
			// }else if(endtimef=="凌晨5点"){
			// 	endtimef="05:00";
			// }else if(endtimef=="凌晨6点"){
			// 	endtimef="06:00";
			// }else if(endtimef=="凌晨7点"){
			// 	endtimef="07:00";
			// }else if(endtimef=="上午8点"){
			// 	endtimef="08:00";
			// }else if(endtimef=="上午9点"){
			// 	endtimef="09:00";
			// }else if(endtimef=="上午10点"){
			// 	endtimef="10:00";
			// }else if(endtimef=="上午11点"){
			// 	endtimef="11:00";
			// }else if(endtimef=="中午12点"){
			// 	endtimef="12:00";
			// }else if(endtimef=="下午13点"){
			// 	endtimef="13:00";
			// }else if(endtimef=="下午14点"){
			// 	endtimef="14:00";
			// }else if(endtimef=="下午15点"){
			// 	endtimef="15:00";
			// }else if(endtimef=="下午16点"){
			// 	endtimef="16:00";
			// }else if(endtimef=="下午17点"){
			// 	endtimef="17:00";
			// }else if(endtimef=="下午18点"){
			// 	endtimef="18:00";
			// }else if(endtimef=="下午19点"){
			// 	endtimef="19:00";
			// }else if(endtimef=="夜晚20点"){
			// 	endtimef="20:00";
			// }else if(endtimef=="夜晚21点"){
			// 	endtimef="21:00";
			// }else if(endtimef=="夜晚22点"){
			// 	endtimef="22:00";
			// }else if(endtimef=="夜晚23点"){
			// 	endtimef="23:00";
			// }else if(endtimef=="午夜24点"){
			// 	endtimef="24:00";
			// }
			
			/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
			
			
			
			
			
			
			
			
			
			if(isNaN(AlltimeValue6)){
				AlltimeValue6=0
			}
			console.log(AlltimeValue6)
			OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
			ClassTimeX.value="总课时："+OKTimeValue;
			moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA;
					$("#timeclass11").change(function(){
					timeValueX=$("#timeclass"+(p-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+p+"").find("option:selected").text();
					AlltimeValue6=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
				
				
				
				/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
				
				
				starttimef=timeValueX;
				endtimef=timeValueH;
				// if(starttimef=="开始时间"){
				// 	starttimef=0;
				// }else if(starttimef=="凌晨1点"){
				// 	starttimef="01:00";
				// }else if(starttimef=="凌晨2点"){
				// 	starttimef="02:00";
				// }else if(starttimef=="凌晨3点"){
				// 	starttimef="03:00";
				// }else if(starttimef=="凌晨4点"){
				// 	starttimef="04:00";
				// }else if(starttimef=="凌晨5点"){
				// 	starttimef="05:00";
				// }else if(starttimef=="凌晨6点"){
				// 	starttimef="06:00";
				// }else if(starttimef=="凌晨7点"){
				// 	starttimef="07:00";
				// }else if(starttimef=="上午8点"){
				// 	starttimef="08:00";
				// }else if(starttimef=="上午9点"){
				// 	starttimef="09:00";
				// }else if(starttimef=="上午10点"){
				// 	starttimef="10:00";
				// }else if(starttimef=="上午11点"){
				// 	starttimef="11:00";
				// }else if(starttimef=="中午12点"){
				// 	starttimef="12:00";
				// }else if(starttimef=="下午13点"){
				// 	starttimef="13:00";
				// }else if(starttimef=="下午14点"){
				// 	starttimef="14:00";
				// }else if(starttimef=="下午15点"){
				// 	starttimef="15:00";
				// }else if(starttimef=="下午16点"){
				// 	starttimef="16:00";
				// }else if(starttimef=="下午17点"){
				// 	starttimef="17:00";
				// }else if(starttimef=="下午18点"){
				// 	starttimef="18:00";
				// }else if(starttimef=="下午19点"){
				// 	starttimef="19:00";
				// }else if(starttimef=="夜晚20点"){
				// 	starttimef="20:00";
				// }else if(starttimef=="夜晚21点"){
				// 	starttimef="21:00";
				// }else if(starttimef=="夜晚22点"){
				// 	starttimef="22:00";
				// }else if(starttimef=="夜晚23点"){
				// 	starttimef="23:00";
				// }else if(starttimef=="午夜24点"){
				// 	starttimef="24:00";
				// }
				
				// if(endtimef=="结束时间"){
				// 	endtimef=0;
				// }else if(endtimef=="凌晨1点"){
				// 	endtimef="01:00";
				// }else if(endtimef=="凌晨2点"){
				// 	endtimef="02:00";
				// }else if(endtimef=="凌晨3点"){
				// 	endtimef="03:00";
				// }else if(endtimef=="凌晨4点"){
				// 	endtimef="04:00";
				// }else if(endtimef=="凌晨5点"){
				// 	endtimef="05:00";
				// }else if(endtimef=="凌晨6点"){
				// 	endtimef="06:00";
				// }else if(endtimef=="凌晨7点"){
				// 	endtimef="07:00";
				// }else if(endtimef=="上午8点"){
				// 	endtimef="08:00";
				// }else if(endtimef=="上午9点"){
				// 	endtimef="09:00";
				// }else if(endtimef=="上午10点"){
				// 	endtimef="10:00";
				// }else if(endtimef=="上午11点"){
				// 	endtimef="11:00";
				// }else if(endtimef=="中午12点"){
				// 	endtimef="12:00";
				// }else if(endtimef=="下午13点"){
				// 	endtimef="13:00";
				// }else if(endtimef=="下午14点"){
				// 	endtimef="14:00";
				// }else if(endtimef=="下午15点"){
				// 	endtimef="15:00";
				// }else if(endtimef=="下午16点"){
				// 	endtimef="16:00";
				// }else if(endtimef=="下午17点"){
				// 	endtimef="17:00";
				// }else if(endtimef=="下午18点"){
				// 	endtimef="18:00";
				// }else if(endtimef=="下午19点"){
				// 	endtimef="19:00";
				// }else if(endtimef=="夜晚20点"){
				// 	endtimef="20:00";
				// }else if(endtimef=="夜晚21点"){
				// 	endtimef="21:00";
				// }else if(endtimef=="夜晚22点"){
				// 	endtimef="22:00";
				// }else if(endtimef=="夜晚23点"){
				// 	endtimef="23:00";
				// }else if(endtimef=="午夜24点"){
				// 	endtimef="24:00";
				// }
				
				/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
				
				
				
				
				
				
				
				 if(isNaN(AlltimeValue6)){
					AlltimeValue6=0
				}
				/* console.log(AlltimeValue6) */
				OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
				ClassTimeX.value="总课时："+OKTimeValue;
				moneyA=$("#AllmeonyB").val();
				AllmeonyX.value="总费用："+OKTimeValue*moneyA;
				});
				});
			
			
			
			
			
			/* 7 */
			
			$("#timeclass12").change(function(){
					timeValueX=$("#timeclass"+(p-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+p+"").find("option:selected").text();
					AlltimeValue7=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
			
			
			
			
			/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
			
			
			starttimeg=timeValueX;
			endtimeg=timeValueH;
			// if(starttimeg=="开始时间"){
			// 	starttimeg=0;
			// }else if(starttimeg=="凌晨1点"){
			// 	starttimeg="01:00";
			// }else if(starttimeg=="凌晨2点"){
			// 	starttimeg="02:00";
			// }else if(starttimeg=="凌晨3点"){
			// 	starttimeg="03:00";
			// }else if(starttimeg=="凌晨4点"){
			// 	starttimeg="04:00";
			// }else if(starttimeg=="凌晨5点"){
			// 	starttimeg="05:00";
			// }else if(starttimeg=="凌晨6点"){
			// 	starttimeg="06:00";
			// }else if(starttimeg=="凌晨7点"){
			// 	starttimeg="07:00";
			// }else if(starttimeg=="上午8点"){
			// 	starttimeg="08:00";
			// }else if(starttimeg=="上午9点"){
			// 	starttimeg="09:00";
			// }else if(starttimeg=="上午10点"){
			// 	starttimeg="10:00";
			// }else if(starttimeg=="上午11点"){
			// 	starttimeg="11:00";
			// }else if(starttimeg=="中午12点"){
			// 	starttimeg="12:00";
			// }else if(starttimeg=="下午13点"){
			// 	starttimeg="13:00";
			// }else if(starttimeg=="下午14点"){
			// 	starttimeg="14:00";
			// }else if(starttimeg=="下午15点"){
			// 	starttimeg="15:00";
			// }else if(starttimeg=="下午16点"){
			// 	starttimeg="16:00";
			// }else if(starttimeg=="下午17点"){
			// 	starttimeg="17:00";
			// }else if(starttimeg=="下午18点"){
			// 	starttimeg="18:00";
			// }else if(starttimeg=="下午19点"){
			// 	starttimeg="19:00";
			// }else if(starttimeg=="夜晚20点"){
			// 	starttimeg="20:00";
			// }else if(starttimeg=="夜晚21点"){
			// 	starttimeg="21:00";
			// }else if(starttimeg=="夜晚22点"){
			// 	starttimeg="22:00";
			// }else if(starttimeg=="夜晚23点"){
			// 	starttimeg="23:00";
			// }else if(starttimeg=="午夜24点"){
			// 	starttimeg="24:00";
			// }
			
			// if(endtimeg=="结束时间"){
			// 	endtimeg=0;
			// }else if(endtimeg=="凌晨1点"){
			// 	endtimeg="01:00";
			// }else if(endtimeg=="凌晨2点"){
			// 	endtimeg="02:00";
			// }else if(endtimeg=="凌晨3点"){
			// 	endtimeg="03:00";
			// }else if(endtimeg=="凌晨4点"){
			// 	endtimeg="04:00";
			// }else if(endtimeg=="凌晨5点"){
			// 	endtimeg="05:00";
			// }else if(endtimeg=="凌晨6点"){
			// 	endtimeg="06:00";
			// }else if(endtimeg=="凌晨7点"){
			// 	endtimeg="07:00";
			// }else if(endtimeg=="上午8点"){
			// 	endtimeg="08:00";
			// }else if(endtimeg=="上午9点"){
			// 	endtimeg="09:00";
			// }else if(endtimeg=="上午10点"){
			// 	endtimeg="10:00";
			// }else if(endtimeg=="上午11点"){
			// 	endtimeg="11:00";
			// }else if(endtimeg=="中午12点"){
			// 	endtimeg="12:00";
			// }else if(endtimeg=="下午13点"){
			// 	endtimeg="13:00";
			// }else if(endtimeg=="下午14点"){
			// 	endtimeg="14:00";
			// }else if(endtimeg=="下午15点"){
			// 	endtimeg="15:00";
			// }else if(endtimeg=="下午16点"){
			// 	endtimeg="16:00";
			// }else if(endtimeg=="下午17点"){
			// 	endtimeg="17:00";
			// }else if(endtimeg=="下午18点"){
			// 	endtimeg="18:00";
			// }else if(endtimeg=="下午19点"){
			// 	endtimeg="19:00";
			// }else if(endtimeg=="夜晚20点"){
			// 	endtimeg="20:00";
			// }else if(endtimeg=="夜晚21点"){
			// 	endtimeg="21:00";
			// }else if(endtimeg=="夜晚22点"){
			// 	endtimeg="22:00";
			// }else if(endtimeg=="夜晚23点"){
			// 	endtimeg="23:00";
			// }else if(endtimeg=="午夜24点"){
			// 	endtimeg="24:00";
			// }
			
			/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
			
			
			
			
			
			
			if(isNaN(AlltimeValue7)){
				AlltimeValue7=0
			}
			/* console.log(AlltimeValue7) */
			OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
			ClassTimeX.value="总课时："+OKTimeValue;
			moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA;
					$("#timeclass13").change(function(){
					timeValueX=$("#timeclass"+(p-1)+"").find("option:selected").text();
					timeValueH=$("#timeclass"+p+"").find("option:selected").text();
					AlltimeValue7=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
				
				
				
				
				/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
				
				
				starttimeg=timeValueX;
				endtimeg=timeValueH;
				// if(starttimeg=="开始时间"){
				// 	starttimeg=0;
				// }else if(starttimeg=="凌晨1点"){
				// 	starttimeg="01:00";
				// }else if(starttimeg=="凌晨2点"){
				// 	starttimeg="02:00";
				// }else if(starttimeg=="凌晨3点"){
				// 	starttimeg="03:00";
				// }else if(starttimeg=="凌晨4点"){
				// 	starttimeg="04:00";
				// }else if(starttimeg=="凌晨5点"){
				// 	starttimeg="05:00";
				// }else if(starttimeg=="凌晨6点"){
				// 	starttimeg="06:00";
				// }else if(starttimeg=="凌晨7点"){
				// 	starttimeg="07:00";
				// }else if(starttimeg=="上午8点"){
				// 	starttimeg="08:00";
				// }else if(starttimeg=="上午9点"){
				// 	starttimeg="09:00";
				// }else if(starttimeg=="上午10点"){
				// 	starttimeg="10:00";
				// }else if(starttimeg=="上午11点"){
				// 	starttimeg="11:00";
				// }else if(starttimeg=="中午12点"){
				// 	starttimeg="12:00";
				// }else if(starttimeg=="下午13点"){
				// 	starttimeg="13:00";
				// }else if(starttimeg=="下午14点"){
				// 	starttimeg="14:00";
				// }else if(starttimeg=="下午15点"){
				// 	starttimeg="15:00";
				// }else if(starttimeg=="下午16点"){
				// 	starttimeg="16:00";
				// }else if(starttimeg=="下午17点"){
				// 	starttimeg="17:00";
				// }else if(starttimeg=="下午18点"){
				// 	starttimeg="18:00";
				// }else if(starttimeg=="下午19点"){
				// 	starttimeg="19:00";
				// }else if(starttimeg=="夜晚20点"){
				// 	starttimeg="20:00";
				// }else if(starttimeg=="夜晚21点"){
				// 	starttimeg="21:00";
				// }else if(starttimeg=="夜晚22点"){
				// 	starttimeg="22:00";
				// }else if(starttimeg=="夜晚23点"){
				// 	starttimeg="23:00";
				// }else if(starttimeg=="午夜24点"){
				// 	starttimeg="24:00";
				// }
				
				// if(endtimeg=="结束时间"){
				// 	endtimeg=0;
				// }else if(endtimeg=="凌晨1点"){
				// 	endtimeg="01:00";
				// }else if(endtimeg=="凌晨2点"){
				// 	endtimeg="02:00";
				// }else if(endtimeg=="凌晨3点"){
				// 	endtimeg="03:00";
				// }else if(endtimeg=="凌晨4点"){
				// 	endtimeg="04:00";
				// }else if(endtimeg=="凌晨5点"){
				// 	endtimeg="05:00";
				// }else if(endtimeg=="凌晨6点"){
				// 	endtimeg="06:00";
				// }else if(endtimeg=="凌晨7点"){
				// 	endtimeg="07:00";
				// }else if(endtimeg=="上午8点"){
				// 	endtimeg="08:00";
				// }else if(endtimeg=="上午9点"){
				// 	endtimeg="09:00";
				// }else if(endtimeg=="上午10点"){
				// 	endtimeg="10:00";
				// }else if(endtimeg=="上午11点"){
				// 	endtimeg="11:00";
				// }else if(endtimeg=="中午12点"){
				// 	endtimeg="12:00";
				// }else if(endtimeg=="下午13点"){
				// 	endtimeg="13:00";
				// }else if(endtimeg=="下午14点"){
				// 	endtimeg="14:00";
				// }else if(endtimeg=="下午15点"){
				// 	endtimeg="15:00";
				// }else if(endtimeg=="下午16点"){
				// 	endtimeg="16:00";
				// }else if(endtimeg=="下午17点"){
				// 	endtimeg="17:00";
				// }else if(endtimeg=="下午18点"){
				// 	endtimeg="18:00";
				// }else if(endtimeg=="下午19点"){
				// 	endtimeg="19:00";
				// }else if(endtimeg=="夜晚20点"){
				// 	endtimeg="20:00";
				// }else if(endtimeg=="夜晚21点"){
				// 	endtimeg="21:00";
				// }else if(endtimeg=="夜晚22点"){
				// 	endtimeg="22:00";
				// }else if(endtimeg=="夜晚23点"){
				// 	endtimeg="23:00";
				// }else if(endtimeg=="午夜24点"){
				// 	endtimeg="24:00";
				// }
				
				/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
				
				
				
				
				
				
				
				 if(isNaN(AlltimeValue2)){
					AlltimeValue7=0
				}
				/* console.log(AlltimeValue7) */
				OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
				ClassTimeX.value="总课时："+OKTimeValue;
				moneyA=$("#AllmeonyB").val();
				AllmeonyX.value="总费用："+OKTimeValue*moneyA;
				});
				});
			
			
			weekb=$("#dayID2").val();
				$("#dayID2").change(function(){
					
					weekb=$("#dayID2").val();
					
					/* if(weekb=="周一"){
						weekb=1;
					}else if(weekb=="周二"){
						weekb=2;
					}else if(weekb=="周三"){
						weekb=3;
					}else if(weekb=="周四"){
						weekb=4;
					}else if(weekb=="周五"){
						weekb=5;
					}else if(weekb=="周六"){
						weekb=6;
					}else if(weekb=="周七"){
						weekb=7;
					} */
					console.log(weekb)
				})
				
				
				weekc=$("#dayID3").val();
				
				$("#dayID3").change(function(){
					
					weekc=$("#dayID3").val();
					
					if(weekc=="周一"){
						weekc=1;
					}else if(weekc=="周二"){
						weekc=2;
					}else if(weekc=="周三"){
						weekc=3;
					}else if(weekc=="周四"){
						weekc=4;
					}else if(weekc=="周五"){
						weekc=5;
					}else if(weekc=="周六"){
						weekc=6;
					}else if(weekc=="周七"){
						weekc=7;
					}
					console.log(weekc)
				})
				
				
				
				weekd=$("#dayID4").val();
				$("#dayID4").change(function(){
					
					weekd=$("#dayID4").val();
					
					if(weekd=="周一"){
						weekd=1;
					}else if(weekd=="周二"){
						weekd=2;
					}else if(weekd=="周三"){
						weekd=3;
					}else if(weekd=="周四"){
						weekd=4;
					}else if(weekd=="周五"){
						weekd=5;
					}else if(weekd=="周六"){
						weekd=6;
					}else if(weekd=="周七"){
						weekd=7;
					}
					console.log(weekd)
				})
				
				
				
				weeke=$("#dayID5").val();
				
				$("#dayID5").change(function(){
					
					weeke=$("#dayID5").val();
					
					if(weeke=="周一"){
						weeke=1;
					}else if(weeke=="周二"){
						weeke=2;
					}else if(weeke=="周三"){
						weeke=3;
					}else if(weeke=="周四"){
						weeke=4;
					}else if(weeke=="周五"){
						weeke=5;
					}else if(weeke=="周六"){
						weeke=6;
					}else if(weeke=="周七"){
						weeke=7;
					}
					console.log(weeke)
				})
				
				
				
				
				
				weekf=$("#dayID6").val();
				
				$("#dayID6").change(function(){
					
					weekf=$("#dayID6").val();
					
					if(weekf=="周一"){
						weekf=1;
					}else if(weekf=="周二"){
						weekf=2;
					}else if(weekf=="周三"){
						weekf=3;
					}else if(weekf=="周四"){
						weekf=4;
					}else if(weekf=="周五"){
						weekf=5;
					}else if(weekf=="周六"){
						weekf=6;
					}else if(weekf=="周七"){
						weekf=7;
					}
					console.log(weekf)
				})
				
				
				
				
				
				weekg=$("#dayID7").val();
				$("#dayID7").change(function(){
					
					weekg=$("#dayID7").val();
					
					if(weekg=="周一"){
						weekg=1;
					}else if(weekg=="周二"){
						weekg=2;
					}else if(weekg=="周三"){
						weekg=3;
					}else if(weekg=="周四"){
						weekg=4;
					}else if(weekg=="周五"){
						weekg=5;
					}else if(weekg=="周六"){
						weekg=6;
					}else if(weekg=="周七"){
						weekg=7;
					}
					console.log(weekg)
				})
				
				
			
			
			
			};

	
	
	/* 1 */
	timeValueA=$("#timeclass0").find("option:selected").text();
		timeValueB=$("#timeclass1").find("option:selected").text();
	AlltimeValue1=parseInt(timeValueB.substring(2))-parseInt(timeValueA.substring(2));
	starttimea=timeValueA;
	endtimea=timeValueB;
	// if(starttimea=="开始时间"){
	// 	starttimea=0;
	// }else if(starttimea=="凌晨1点"){
	// 	starttimea="01:00";
	// }else if(starttimea=="凌晨2点"){
	// 	starttimea="02:00";
	// }else if(starttimea=="凌晨3点"){
	// 	starttimea="03:00";
	// }else if(starttimea=="凌晨4点"){
	// 	starttimea="04:00";
	// }else if(starttimea=="凌晨5点"){
	// 	starttimea="05:00";
	// }else if(starttimea=="凌晨6点"){
	// 	starttimea="06:00";
	// }else if(starttimea=="凌晨7点"){
	// 	starttimea="07:00";
	// }else if(starttimea=="上午8点"){
	// 	starttimea="08:00";
	// }else if(starttimea=="上午9点"){
	// 	starttimea="09:00";
	// }else if(starttimea=="上午10点"){
	// 	starttimea="10:00";
	// }else if(starttimea=="上午11点"){
	// 	starttimea="11:00";
	// }else if(starttimea=="中午12点"){
	// 	starttimea="12:00";
	// }else if(starttimea=="下午13点"){
	// 	starttimea="13:00";
	// }else if(starttimea=="下午14点"){
	// 	starttimea="14:00";
	// }else if(starttimea=="下午15点"){
	// 	starttimea="15:00";
	// }else if(starttimea=="下午16点"){
	// 	starttimea="16:00";
	// }else if(starttimea=="下午17点"){
	// 	starttimea="17:00";
	// }else if(starttimea=="下午18点"){
	// 	starttimea="18:00";
	// }else if(starttimea=="下午19点"){
	// 	starttimea="19:00";
	// }else if(starttimea=="夜晚20点"){
	// 	starttimea="20:00";
	// }else if(starttimea=="夜晚21点"){
	// 	starttimea="21:00";
	// }else if(starttimea=="夜晚22点"){
	// 	starttimea="22:00";
	// }else if(starttimea=="夜晚23点"){
	// 	starttimea="23:00";
	// }else if(starttimea=="午夜24点"){
	// 	starttimea="24:00";
	// }
	
	// if(endtimea=="结束时间"){
	// 	endtimea=0;
	// }else if(endtimea=="凌晨1点"){
	// 	endtimea="01:00";
	// }else if(endtimea=="凌晨2点"){
	// 	endtimea="02:00";
	// }else if(endtimea=="凌晨3点"){
	// 	endtimea="03:00";
	// }else if(endtimea=="凌晨4点"){
	// 	endtimea="04:00";
	// }else if(endtimea=="凌晨5点"){
	// 	endtimea="05:00";
	// }else if(endtimea=="凌晨6点"){
	// 	endtimea="06:00";
	// }else if(endtimea=="凌晨7点"){
	// 	endtimea="07:00";
	// }else if(endtimea=="上午8点"){
	// 	endtimea="08:00";
	// }else if(endtimea=="上午9点"){
	// 	endtimea="09:00";
	// }else if(endtimea=="上午10点"){
	// 	endtimea="10:00";
	// }else if(endtimea=="上午11点"){
	// 	endtimea="11:00";
	// }else if(endtimea=="中午12点"){
	// 	endtimea="12:00";
	// }else if(endtimea=="下午13点"){
	// 	endtimea="13:00";
	// }else if(endtimea=="下午14点"){
	// 	endtimea="14:00";
	// }else if(endtimea=="下午15点"){
	// 	endtimea="15:00";
	// }else if(endtimea=="下午16点"){
	// 	endtimea="16:00";
	// }else if(endtimea=="下午17点"){
	// 	endtimea="17:00";
	// }else if(endtimea=="下午18点"){
	// 	endtimea="18:00";
	// }else if(endtimea=="下午19点"){
	// 	endtimea="19:00";
	// }else if(endtimea=="夜晚20点"){
	// 	endtimea="20:00";
	// }else if(endtimea=="夜晚21点"){
	// 	endtimea="21:00";
	// }else if(endtimea=="夜晚22点"){
	// 	endtimea="22:00";
	// }else if(endtimea=="夜晚23点"){
	// 	endtimea="23:00";
	// }else if(endtimea=="午夜24点"){
	// 	endtimea="24:00";
	// }
	console.log(endtimea)
	console.log(starttimea)
	
	
	if(isNaN(AlltimeValue1)){
		AlltimeValue1=0
	}
	OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
	ClassTimeX.value="总课时："+OKTimeValue;
	moneyA=$("#AllmeonyB").val();
	AllmeonyX.value="总费用："+OKTimeValue*moneyA
	console.log(OKTimeValue)
	console.log(AllmeonyB)
	
	
	
	
	$("#timeclass0").change(function(){
		timeValueA=$("#timeclass0").find("option:selected").text();
		timeValueB=$("#timeclass1").find("option:selected").text();
	AlltimeValue1=parseInt(timeValueB.substring(2))-parseInt(timeValueA.substring(2));
	starttimea=timeValueA;
	endtimea=timeValueB;
	// if(starttimea=="开始时间"){
	// 	starttimea=0;
	// }else if(starttimea=="凌晨1点"){
	// 	starttimea="01:00";
	// }else if(starttimea=="凌晨2点"){
	// 	starttimea="02:00";
	// }else if(starttimea=="凌晨3点"){
	// 	starttimea="03:00";
	// }else if(starttimea=="凌晨4点"){
	// 	starttimea="04:00";
	// }else if(starttimea=="凌晨5点"){
	// 	starttimea="05:00";
	// }else if(starttimea=="凌晨6点"){
	// 	starttimea="06:00";
	// }else if(starttimea=="凌晨7点"){
	// 	starttimea="07:00";
	// }else if(starttimea=="上午8点"){
	// 	starttimea="08:00";
	// }else if(starttimea=="上午9点"){
	// 	starttimea="09:00";
	// }else if(starttimea=="上午10点"){
	// 	starttimea="10:00";
	// }else if(starttimea=="上午11点"){
	// 	starttimea="11:00";
	// }else if(starttimea=="中午12点"){
	// 	starttimea="12:00";
	// }else if(starttimea=="下午13点"){
	// 	starttimea="13:00";
	// }else if(starttimea=="下午14点"){
	// 	starttimea="14:00";
	// }else if(starttimea=="下午15点"){
	// 	starttimea="15:00";
	// }else if(starttimea=="下午16点"){
	// 	starttimea="16:00";
	// }else if(starttimea=="下午17点"){
	// 	starttimea="17:00";
	// }else if(starttimea=="下午18点"){
	// 	starttimea="18:00";
	// }else if(starttimea=="下午19点"){
	// 	starttimea="19:00";
	// }else if(starttimea=="夜晚20点"){
	// 	starttimea="20:00";
	// }else if(starttimea=="夜晚21点"){
	// 	starttimea="21:00";
	// }else if(starttimea=="夜晚22点"){
	// 	starttimea="22:00";
	// }else if(starttimea=="夜晚23点"){
	// 	starttimea="23:00";
	// }else if(starttimea=="午夜24点"){
	// 	starttimea="24:00";
	// }
	
	// if(endtimea=="开始时间"){
	// 	endtimea=0;
	// }else if(endtimea=="凌晨1点"){
	// 	endtimea="01:00";
	// }else if(endtimea=="凌晨2点"){
	// 	endtimea="02:00";
	// }else if(endtimea=="凌晨3点"){
	// 	endtimea="03:00";
	// }else if(endtimea=="凌晨4点"){
	// 	endtimea="04:00";
	// }else if(endtimea=="凌晨5点"){
	// 	endtimea="05:00";
	// }else if(endtimea=="凌晨6点"){
	// 	endtimea="06:00";
	// }else if(endtimea=="凌晨7点"){
	// 	endtimea="07:00";
	// }else if(endtimea=="上午8点"){
	// 	endtimea="08:00";
	// }else if(endtimea=="上午9点"){
	// 	endtimea="09:00";
	// }else if(endtimea=="上午10点"){
	// 	endtimea="10:00";
	// }else if(endtimea=="上午11点"){
	// 	endtimea="11:00";
	// }else if(endtimea=="中午12点"){
	// 	endtimea="12:00";
	// }else if(endtimea=="下午13点"){
	// 	endtimea="13:00";
	// }else if(endtimea=="下午14点"){
	// 	endtimea="14:00";
	// }else if(endtimea=="下午15点"){
	// 	endtimea="15:00";
	// }else if(endtimea=="下午16点"){
	// 	endtimea="16:00";
	// }else if(endtimea=="下午17点"){
	// 	endtimea="17:00";
	// }else if(endtimea=="下午18点"){
	// 	endtimea="18:00";
	// }else if(endtimea=="下午19点"){
	// 	endtimea="19:00";
	// }else if(endtimea=="夜晚20点"){
	// 	endtimea="20:00";
	// }else if(endtimea=="夜晚21点"){
	// 	endtimea="21:00";
	// }else if(endtimea=="夜晚22点"){
	// 	endtimea="22:00";
	// }else if(endtimea=="夜晚23点"){
	// 	endtimea="23:00";
	// }else if(endtimea=="午夜24点"){
	// 	endtimea="24:00";
	// }
	if(isNaN(AlltimeValue1)){
		AlltimeValue1=0
	}
	OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
	ClassTimeX.value="总课时："+OKTimeValue;
	moneyA=$("#AllmeonyB").val();
	AllmeonyX.value="总费用："+OKTimeValue*moneyA
	console.log(OKTimeValue)
	console.log(AllmeonyB)
	
		$("#timeclass1").change(function(){
			timeValueA=$("#timeclass0").find("option:selected").text();
		timeValueB=$("#timeclass1").find("option:selected").text();
	AlltimeValue1=parseInt(timeValueB.substring(2))-parseInt(timeValueA.substring(2));
	
	starttimea=timeValueA;
	endtimea=timeValueB;
	// if(starttimea=="开始时间"){
	// 	starttimea=0;
	// }else if(starttimea=="凌晨1点"){
	// 	starttimea="01:00";
	// }else if(starttimea=="凌晨2点"){
	// 	starttimea="02:00";
	// }else if(starttimea=="凌晨3点"){
	// 	starttimea="03:00";
	// }else if(starttimea=="凌晨4点"){
	// 	starttimea="04:00";
	// }else if(starttimea=="凌晨5点"){
	// 	starttimea="05:00";
	// }else if(starttimea=="凌晨6点"){
	// 	starttimea="06:00";
	// }else if(starttimea=="凌晨7点"){
	// 	starttimea="07:00";
	// }else if(starttimea=="上午8点"){
	// 	starttimea="08:00";
	// }else if(starttimea=="上午9点"){
	// 	starttimea="09:00";
	// }else if(starttimea=="上午10点"){
	// 	starttimea="10:00";
	// }else if(starttimea=="上午11点"){
	// 	starttimea="11:00";
	// }else if(starttimea=="中午12点"){
	// 	starttimea="12:00";
	// }else if(starttimea=="下午13点"){
	// 	starttimea="13:00";
	// }else if(starttimea=="下午14点"){
	// 	starttimea="14:00";
	// }else if(starttimea=="下午15点"){
	// 	starttimea="15:00";
	// }else if(starttimea=="下午16点"){
	// 	starttimea="16:00";
	// }else if(starttimea=="下午17点"){
	// 	starttimea="17:00";
	// }else if(starttimea=="下午18点"){
	// 	starttimea="18:00";
	// }else if(starttimea=="下午19点"){
	// 	starttimea="19:00";
	// }else if(starttimea=="夜晚20点"){
	// 	starttimea="20:00";
	// }else if(starttimea=="夜晚21点"){
	// 	starttimea="21:00";
	// }else if(starttimea=="夜晚22点"){
	// 	starttimea="22:00";
	// }else if(starttimea=="夜晚23点"){
	// 	starttimea="23:00";
	// }else if(starttimea=="午夜24点"){
	// 	starttimea="24:00";
	// }
	
	// if(endtimea=="开始时间"){
	// 	endtimea=0;
	// }else if(endtimea=="凌晨1点"){
	// 	endtimea="01:00";
	// }else if(endtimea=="凌晨2点"){
	// 	endtimea="02:00";
	// }else if(endtimea=="凌晨3点"){
	// 	endtimea="03:00";
	// }else if(endtimea=="凌晨4点"){
	// 	endtimea="04:00";
	// }else if(endtimea=="凌晨5点"){
	// 	endtimea="05:00";
	// }else if(endtimea=="凌晨6点"){
	// 	endtimea="06:00";
	// }else if(endtimea=="凌晨7点"){
	// 	endtimea="07:00";
	// }else if(endtimea=="上午8点"){
	// 	endtimea="08:00";
	// }else if(endtimea=="上午9点"){
	// 	endtimea="09:00";
	// }else if(endtimea=="上午10点"){
	// 	endtimea="10:00";
	// }else if(endtimea=="上午11点"){
	// 	endtimea="11:00";
	// }else if(endtimea=="中午12点"){
	// 	endtimea="12:00";
	// }else if(endtimea=="下午13点"){
	// 	endtimea="13:00";
	// }else if(endtimea=="下午14点"){
	// 	endtimea="14:00";
	// }else if(endtimea=="下午15点"){
	// 	endtimea="15:00";
	// }else if(endtimea=="下午16点"){
	// 	endtimea="16:00";
	// }else if(endtimea=="下午17点"){
	// 	endtimea="17:00";
	// }else if(endtimea=="下午18点"){
	// 	endtimea="18:00";
	// }else if(endtimea=="下午19点"){
	// 	endtimea="19:00";
	// }else if(endtimea=="夜晚20点"){
	// 	endtimea="20:00";
	// }else if(endtimea=="夜晚21点"){
	// 	endtimea="21:00";
	// }else if(endtimea=="夜晚22点"){
	// 	endtimea="22:00";
	// }else if(endtimea=="夜晚23点"){
	// 	endtimea="23:00";
	// }else if(endtimea=="午夜24点"){
	// 	endtimea="24:00";
	// }
	
	
	
	if(isNaN(AlltimeValue1)){
		AlltimeValue1=0
	}
	OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
	ClassTimeX.value="总课时："+OKTimeValue;
	moneyA=$("#AllmeonyB").val();
	AllmeonyX.value="总费用："+OKTimeValue*moneyA
	console.log(OKTimeValue)
	console.log(AllmeonyB)
	})
	})
	/* 钱钱钱 */
	$("#AllmeonyB").change(function(){
	    moneyA=$("#AllmeonyB").val();
		AllmeonyX.value="总费用："+OKTimeValue*moneyA
		/* console.log(OKTimeValue)
		console.log(AllmeonyB) */
	})


/* ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss */
		
		
		
		
		
		weeka=$("#dayID1").val();
		GETUERID()
		function GETUERID(){
		    userid = localStorage.getItem("Userid");
		}
		
			$("#dayID1").change(function(){
		weeka=$("#dayID1").val();
		console.log(weeka)
	
		})
		
		
		
		
var confirmx=document.getElementById("confirm");
var orderidTT;
GETorderTT()
function GETorderTT(){
	 
	 orderidTT=localStorage.getItem("ID");
	 console.log(orderidTT)
}




var orderid;
 orderid = localStorage.getItem("ID");
 GETMSG()
function GETMSG(){
Myajax("OrderCondition","GET","http://manage.woyaoxuexue.com/guns/app/getteachorderlist",
	{
		"page":1,
		"rows":9999,
		"orderid":orderid
	},10000,function(msg){
		var str=msg.responseText;
		var obja=eval("("+str+")");
		console.log(obja);
		var weekArry=[];
		var endtimeArry=[];
		var starttimeArry=[];
		var listLength=obja.data.list.length;
		/* console.log(listLength) */
		// var eee="";
		for(var j=0;j<listLength;j++){
			teacheridaaa=obja.data.list[j].teacherid;
			console.log(teacheridaaa)
			userid=obja.data.list[j].userid;
			var nickname=obja.data.list[j].nickname;
			/* console.log(nickname); */
			var addareaname=obja.data.list[j].addareaname;
			var addareacode=obja.data.list[j].addareacode;
			/* console.log(addareaname); */
			//console.log(addareacode);
			var addprovincename=obja.data.list[j].addprovincename;
			var addprovincecode=obja.data.list[j].addprovincecode;
			/* console.log(addprovincename); */
			//console.log(addprovincecode);
			var addcityname=obja.data.list[j].addcityname;
			var addcitycode=obja.data.list[j].addcitycode;
			//console.log(addcitycode);
			var phone=obja.data.list[j].phone;
			/* console.log(addcityname); */
			var addressa=obja.data.list[j].address;
			//console.log(address);
			var totaltime=obja.data.list[j].totaltime;
		/* console.log(totaltime); */
		$("#ClassTimeX").val("总课时:"+totaltime)
		var price=obja.data.list[j].price;
		//console.log(price);
		
		$("#AllmeonyB").val(price)
		var amount=obja.data.list[j].amount;
		console.log(amount);
		$("#AllmeonyX").val("总费用:"+amount)
		var headpic=obja.data.list[j].headpic;
		//console.log(headpic);
		var remark=obja.data.list[j].remark;
		
		//console.log(remark);
		var courseid=obja.data.list[j].courseid;
		//console.log(courseid);
		var gradeid=obja.data.list[j].gradeid;
		//console.log(gradeid);
		var teachersex=obja.data.list[j].teachersex;
		//console.log(teachersex);
		var teachplacetype=obja.data.list[j].teachplacetype;
		console.log(teachplacetype);
		
		id=obja.data.list[j].id;
		console.log(id);
		var timeListArry=obja.data.list[j].timelist;
		/* console.log(timeListArry); */
		var timelistArryLength=timeListArry.length
		/* console.log(timelistArryLength) */
		for(var t=0;t<timelistArryLength;t++){
			var week=timeListArry[t].week;
			//console.log(week)
			var endtime=timeListArry[t].endtime;
			//console.log(endtime)
			var starttime=timeListArry[t].starttime;
			//console.log(starttime)
			var endtimeValue=endtime.split(" ")
			//console.log(endtimeValue)
			var endtimeValue=String(endtimeValue[0])
			var endtimeValue=endtimeValue.slice(0,5)
			//console.log(endtimeValue)
			var starttimeValue=starttime.split(" ")
			var starttimeValue=String(starttimeValue[0])
			//console.log(starttimeValue)
			var starttimeValue=starttimeValue.slice(0,5)
			console.log(starttimeValue)
			var datestr=timeListArry[t].datestr;
			console.log(datestr)
			datestr=datestr.split(" ")
			datestr=datestr[0]
			console.log(datestr)
			
		weekArry.push(datestr);
		console.log(datestr);
		starttimeArry.push(starttimeValue);
		endtimeArry.push(endtimeValue);
		//console.log(weekArry)
		// console.log(starttimeArry[0])
		//console.log(endtimeArry)
		
		}
		
		
		
		
		for(var t=0;t<timelistArryLength;t++){
			
			// timeValueA=$("#timeclass"+t+"").find("option:selected").text(starttimeArry[t]);
			// timeValueB=$("#timeclass1").find("option:selected").text(endtimeArry[0]);
				// AlltimeValue2=parseInt(timeValueH.substring(2))-parseInt(timeValueX.substring(2));
		let xs=t+1
		var TIMLStr="<ul class=\"timeUL\"><li><input type=\"date\" name=\"day\" class=\"day\" id=\"dayID"+xs+"\"  value=\""+weekArry[t]+"\"/></li><li><select name=\"\" class=\"timeclass\" id=\"timeclass"+2*t+"\"><option value=\"\">"+starttimeArry[t]+"</option><option value=\"\">凌晨6点</option><option value=\"\">凌晨7点</option><option value=\"\">上午8点</option><option value=\"\">上午9点</option><option value=\"\">上午10点</option><option value=\"\">上午11点</option><option value=\"\">中午12点</option><option value=\"\">下午13点</option><option value=\"\">下午14点</option><option value=\"\">下午15点</option><option value=\"\">下午16点</option><option value=\"\">下午17点</option><option value=\"\">下午18点</option><option value=\"\">下午19点</option><option value=\"\">夜晚20点</option><option value=\"\">夜晚21点</option><option value=\"\">夜晚22点</option><option value=\"\">夜晚23点</option><option value=\"\">午夜24点</option></select></li><li>—</li><li><select name=\"\" class=\"timeclass\" id=\"timeclass"+(2*t+1)+"\"><option value=\"\">"+endtimeArry[t]+"</option><option value=\"\">凌晨6点</option><option value=\"\">凌晨7点</option><option value=\"\">上午8点</option><option value=\"\">上午9点</option><option value=\"\">上午10点</option><option value=\"\">上午11点</option><option value=\"\">中午12点</option><option value=\"\">下午13点</option><option value=\"\">下午14点</option><option value=\"\">下午15点</option><option value=\"\">下午16点</option><option value=\"\">下午17点</option><option value=\"\">下午18点</option><option value=\"\">下午19点</option><option value=\"\">夜晚20点</option><option value=\"\">夜晚21点</option><option value=\"\">夜晚22点</option><option value=\"\">夜晚23点</option><option value=\"\">午夜24点</option></select></li><li><button type=\"button\" class=\"DEL\"  name=\"DEL\"><img src=\"content/img/fixed_img/删%20除.png\"></button></li></ul>";
		$("#boxX").append(TIMLStr);
		
		
	
		
		switch(t){
			case 0:
			var timeValueA=0;
			var timeValueB=0;
			timeValueA=$("#timeclass"+2*t+"").find("option:selected").text();
			timeValueB=$("#timeclass"+(2*t+1)+"").find("option:selected").text();
			timeValueA=timeValueA.slice(2)
			timeValueB=timeValueB.slice(2)
			console.log(parseInt(timeValueB))
			console.log(parseInt(timeValueA))
			AlltimeValue1=parseInt(timeValueB)-parseInt(timeValueA);
			console.log(AlltimeValue1)
			
			continue;
			case 1:
			var timeValueA=0;
			var timeValueB=0;
			timeValueA=$("#timeclass"+2*t+"").find("option:selected").text();
			timeValueB=$("#timeclass"+(2*t+1)+"").find("option:selected").text();
			timeValueA=timeValueA.slice(2)
			timeValueB=timeValueB.slice(2)
			console.log(parseInt(timeValueB))
			console.log(parseInt(timeValueA))
			AlltimeValue2=parseInt(timeValueB)-parseInt(timeValueA);
			console.log(AlltimeValue2)
		continue;
			case 2:
			var timeValueA=0;
			var timeValueB=0;
			timeValueA=$("#timeclass"+2*t+"").find("option:selected").text();
			timeValueB=$("#timeclass"+(2*t+1)+"").find("option:selected").text();
			timeValueA=timeValueA.slice(2)
			timeValueB=timeValueB.slice(2)
			AlltimeValue3=parseInt(timeValueB)-parseInt(timeValueA);
			console.log(AlltimeValue3)
			continue;
		case 3:
		var timeValueA=0;
		var timeValueB=0;
		timeValueA=$("#timeclass"+2*t+"").find("option:selected").text();
		timeValueB=$("#timeclass"+(2*t+1)+"").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		AlltimeValue4=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue4)
		continue;
		case 4:
		var timeValueA=0;
		var timeValueB=0;
		timeValueA=$("#timeclass"+2*t+"").find("option:selected").text();
		timeValueB=$("#timeclass"+(2*t+1)+"").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		AlltimeValue5=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue5)
		continue;
		case 5:
		var timeValueA=0;
		var timeValueB=0;
		timeValueA=$("#timeclass"+2*t+"").find("option:selected").text();
		timeValueB=$("#timeclass"+(2*t+1)+"").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		AlltimeValue6=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue6)
		continue;
		case 6:
		var timeValueA=0;
		var timeValueB=0;
		timeValueA=$("#timeclass"+2*t+"").find("option:selected").text();
		timeValueB=$("#timeclass"+(2*t+1)+"").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		AlltimeValue7=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue7)
		continue;
		}
		
		
		OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
		
		$("#ClassTimeX").val("总课时："+OKTimeValue)
		moneyA=$("#AllmeonyB").val();
		console.log(moneyA)
		$("#AllmeonyX").val("总费用："+OKTimeValue*moneyA)
		console.log(OKTimeValue)
		console.log(AllmeonyB)
		$("#AllmeonyB").change(function(){
		    moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA
			/* console.log(OKTimeValue)
			console.log(AllmeonyB) */
		})
		}
		
		//0，1
	$("#timeclass0").change(function(){
		console.log(111111111111)
		timeValueA=$("#timeclass0").find("option:selected").text();
		timeValueB=$("#timeclass1").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		console.log(parseInt(timeValueB))
		console.log(parseInt(timeValueA))
		AlltimeValue1=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue1)
		OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
		
		$("#ClassTimeX").val("总课时："+OKTimeValue)
		moneyA=$("#AllmeonyB").val();
		console.log(moneyA)
		$("#AllmeonyX").val("总费用："+OKTimeValue*moneyA)
		console.log(OKTimeValue)
		console.log(AllmeonyB)
		$("#AllmeonyB").change(function(){
		    moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA
			/* console.log(OKTimeValue)
			console.log(AllmeonyB) */
		})
	$("#timeclass1").change(function(){
		timeValueA=$("#timeclass0").find("option:selected").text();
		timeValueB=$("#timeclass1").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		console.log(parseInt(timeValueB))
		console.log(parseInt(timeValueA))
		AlltimeValue1=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue1)
		OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
		
		$("#ClassTimeX").val("总课时："+OKTimeValue)
		moneyA=$("#AllmeonyB").val();
		console.log(moneyA)
		$("#AllmeonyX").val("总费用："+OKTimeValue*moneyA)
		console.log(OKTimeValue)
		console.log(AllmeonyB)
		$("#AllmeonyB").change(function(){
		    moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA
			/* console.log(OKTimeValue)
			console.log(AllmeonyB) */
		})
	})
	})
	
	//2，3
	
	$("#timeclass2").change(function(){
		console.log(111111111111)
		timeValueA=$("#timeclass2").find("option:selected").text();
		timeValueB=$("#timeclass3").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		console.log(parseInt(timeValueB))
		console.log(parseInt(timeValueA))
		AlltimeValue2=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue2)
		OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
		
		$("#ClassTimeX").val("总课时："+OKTimeValue)
		moneyA=$("#AllmeonyB").val();
		console.log(moneyA)
		$("#AllmeonyX").val("总费用："+OKTimeValue*moneyA)
		console.log(OKTimeValue)
		console.log(AllmeonyB)
		$("#AllmeonyB").change(function(){
		    moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA
			/* console.log(OKTimeValue)
			console.log(AllmeonyB) */
		})
	$("#timeclass3").change(function(){
		timeValueA=$("#timeclass2").find("option:selected").text();
		timeValueB=$("#timeclass3").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		console.log(parseInt(timeValueB))
		console.log(parseInt(timeValueA))
		AlltimeValue2=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue1)
		OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
		
		$("#ClassTimeX").val("总课时："+OKTimeValue)
		moneyA=$("#AllmeonyB").val();
		console.log(moneyA)
		$("#AllmeonyX").val("总费用："+OKTimeValue*moneyA)
		console.log(OKTimeValue)
		console.log(AllmeonyB)
		$("#AllmeonyB").change(function(){
		    moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA
			/* console.log(OKTimeValue)
			console.log(AllmeonyB) */
		})
	})
	})
	//4，5
	$("#timeclass4").change(function(){
		console.log(111111111111)
		timeValueA=$("#timeclass4").find("option:selected").text();
		timeValueB=$("#timeclass5").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		console.log(parseInt(timeValueB))
		console.log(parseInt(timeValueA))
		AlltimeValue3=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue2)
		OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
		
		$("#ClassTimeX").val("总课时："+OKTimeValue)
		moneyA=$("#AllmeonyB").val();
		console.log(moneyA)
		$("#AllmeonyX").val("总费用："+OKTimeValue*moneyA)
		console.log(OKTimeValue)
		console.log(AllmeonyB)
		$("#AllmeonyB").change(function(){
		    moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA
			/* console.log(OKTimeValue)
			console.log(AllmeonyB) */
		})
	$("#timeclass5").change(function(){
		timeValueA=$("#timeclass4").find("option:selected").text();
		timeValueB=$("#timeclass5").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		console.log(parseInt(timeValueB))
		console.log(parseInt(timeValueA))
		AlltimeValue3=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue1)
		OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
		
		$("#ClassTimeX").val("总课时："+OKTimeValue)
		moneyA=$("#AllmeonyB").val();
		console.log(moneyA)
		$("#AllmeonyX").val("总费用："+OKTimeValue*moneyA)
		console.log(OKTimeValue)
		console.log(AllmeonyB)
		$("#AllmeonyB").change(function(){
		    moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA
			/* console.log(OKTimeValue)
			console.log(AllmeonyB) */
		})
	})
	})
	//6，7
	$("#timeclass6").change(function(){
		console.log(111111111111)
		timeValueA=$("#timeclass6").find("option:selected").text();
		timeValueB=$("#timeclass7").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		console.log(parseInt(timeValueB))
		console.log(parseInt(timeValueA))
		AlltimeValue4=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue2)
		OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
		
		$("#ClassTimeX").val("总课时："+OKTimeValue)
		moneyA=$("#AllmeonyB").val();
		console.log(moneyA)
		$("#AllmeonyX").val("总费用："+OKTimeValue*moneyA)
		console.log(OKTimeValue)
		console.log(AllmeonyB)
		$("#AllmeonyB").change(function(){
		    moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA
			/* console.log(OKTimeValue)
			console.log(AllmeonyB) */
		})
	$("#timeclass7").change(function(){
		timeValueA=$("#timeclass6").find("option:selected").text();
		timeValueB=$("#timeclass7").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		console.log(parseInt(timeValueB))
		console.log(parseInt(timeValueA))
		AlltimeValue4=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue1)
		OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
		
		$("#ClassTimeX").val("总课时："+OKTimeValue)
		moneyA=$("#AllmeonyB").val();
		console.log(moneyA)
		$("#AllmeonyX").val("总费用："+OKTimeValue*moneyA)
		console.log(OKTimeValue)
		console.log(AllmeonyB)
		$("#AllmeonyB").change(function(){
		    moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA
			/* console.log(OKTimeValue)
			console.log(AllmeonyB) */
		})
	})
	})
	
	//8，9
	$("#timeclass8").change(function(){
		console.log(111111111111)
		timeValueA=$("#timeclass8").find("option:selected").text();
		timeValueB=$("#timeclass9").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		console.log(parseInt(timeValueB))
		console.log(parseInt(timeValueA))
		AlltimeValue5=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue2)
		OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
		
		$("#ClassTimeX").val("总课时："+OKTimeValue)
		moneyA=$("#AllmeonyB").val();
		console.log(moneyA)
		$("#AllmeonyX").val("总费用："+OKTimeValue*moneyA)
		console.log(OKTimeValue)
		console.log(AllmeonyB)
		$("#AllmeonyB").change(function(){
		    moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA
			/* console.log(OKTimeValue)
			console.log(AllmeonyB) */
		})
	$("#timeclass9").change(function(){
		timeValueA=$("#timeclass8").find("option:selected").text();
		timeValueB=$("#timeclass9").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		console.log(parseInt(timeValueB))
		console.log(parseInt(timeValueA))
		AlltimeValue5=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue1)
		OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
		
		$("#ClassTimeX").val("总课时："+OKTimeValue)
		moneyA=$("#AllmeonyB").val();
		console.log(moneyA)
		$("#AllmeonyX").val("总费用："+OKTimeValue*moneyA)
		console.log(OKTimeValue)
		console.log(AllmeonyB)
		$("#AllmeonyB").change(function(){
		    moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA
			/* console.log(OKTimeValue)
			console.log(AllmeonyB) */
		})
	})
	})
	//10，11
	$("#timeclass10").change(function(){
		console.log(111111111111)
		timeValueA=$("#timeclass10").find("option:selected").text();
		timeValueB=$("#timeclass11").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		console.log(parseInt(timeValueB))
		console.log(parseInt(timeValueA))
		AlltimeValue6=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue2)
		OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
		
		$("#ClassTimeX").val("总课时："+OKTimeValue)
		moneyA=$("#AllmeonyB").val();
		console.log(moneyA)
		$("#AllmeonyX").val("总费用："+OKTimeValue*moneyA)
		console.log(OKTimeValue)
		console.log(AllmeonyB)
		$("#AllmeonyB").change(function(){
		    moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA
			/* console.log(OKTimeValue)
			console.log(AllmeonyB) */
		})
	$("#timeclass11").change(function(){
		timeValueA=$("#timeclass10").find("option:selected").text();
		timeValueB=$("#timeclass11").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		console.log(parseInt(timeValueB))
		console.log(parseInt(timeValueA))
		AlltimeValue6=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue1)
		OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
		
		$("#ClassTimeX").val("总课时："+OKTimeValue)
		moneyA=$("#AllmeonyB").val();
		console.log(moneyA)
		$("#AllmeonyX").val("总费用："+OKTimeValue*moneyA)
		console.log(OKTimeValue)
		console.log(AllmeonyB)
		$("#AllmeonyB").change(function(){
		    moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA
			/* console.log(OKTimeValue)
			console.log(AllmeonyB) */
		})
	})
	})
	//12，13
	$("#timeclass12").change(function(){
		console.log(111111111111)
		timeValueA=$("#timeclass12").find("option:selected").text();
		timeValueB=$("#timeclass13").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		console.log(parseInt(timeValueB))
		console.log(parseInt(timeValueA))
		AlltimeValue7=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue2)
		OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
		
		$("#ClassTimeX").val("总课时："+OKTimeValue)
		moneyA=$("#AllmeonyB").val();
		console.log(moneyA)
		$("#AllmeonyX").val("总费用："+OKTimeValue*moneyA)
		console.log(OKTimeValue)
		console.log(AllmeonyB)
		$("#AllmeonyB").change(function(){
		    moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA
			/* console.log(OKTimeValue)
			console.log(AllmeonyB) */
		})
	$("#timeclass13").change(function(){
		timeValueA=$("#timeclass12").find("option:selected").text();
		timeValueB=$("#timeclass13").find("option:selected").text();
		timeValueA=timeValueA.slice(2)
		timeValueB=timeValueB.slice(2)
		console.log(parseInt(timeValueB))
		console.log(parseInt(timeValueA))
		AlltimeValue7=parseInt(timeValueB)-parseInt(timeValueA);
		console.log(AlltimeValue1)
		OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
		
		$("#ClassTimeX").val("总课时："+OKTimeValue)
		moneyA=$("#AllmeonyB").val();
		console.log(moneyA)
		$("#AllmeonyX").val("总费用："+OKTimeValue*moneyA)
		console.log(OKTimeValue)
		console.log(AllmeonyB)
		$("#AllmeonyB").change(function(){
		    moneyA=$("#AllmeonyB").val();
			AllmeonyX.value="总费用："+OKTimeValue*moneyA
			/* console.log(OKTimeValue)
			console.log(AllmeonyB) */
		})
	})
	})
	
	
		
			/* 删除 */
			var DELX=document.getElementsByClassName("DEL");
			for(var p=0;p<DELX.length;p++){
				DELX[p].num=p;
				DELX[p].onclick=function(){
					var x=this.num;
					var flag=confirm("确认删除吗？");
					if(flag){
						var x=this.num;
						if(x==0){
							AlltimeValue1=0
							weeka=""
							starttimea=""
							endtimea=""
						}else if(x==1){
							AlltimeValue2=0
							weekb=""
							starttimeb=""
							endtimeb=""
						}else if(x==2){
							AlltimeValue3=0
							weekc=""
							starttimec=""
							endtimec=""
						}else if(x==3){
							AlltimeValue4=0
							weekd=""
							starttimed=""
							endtimed=""
						}else if(x==4){
							AlltimeValue5=0
							weeke=""
							starttimee=""
							endtimee=""
						}else if(x==5){
							AlltimeValue6=0
							weekf=""
							starttimef=""
							endtimef=""
						}else if(x==6){
							AlltimeValue7=0
							weekg=""
							starttimeg=""
							endtimeg=""
						}
						console.log(AlltimeValue1);
						console.log(AlltimeValue2);
						console.log(AlltimeValue3);
						console.log(AlltimeValue4);
						console.log(AlltimeValue5);
						console.log(AlltimeValue6);
						console.log(AlltimeValue7);
						
						OKTimeValue=AlltimeValue1+AlltimeValue2+AlltimeValue3+AlltimeValue4+AlltimeValue5+AlltimeValue6+AlltimeValue7;
						ClassTimeX.value="总课时："+OKTimeValue;
						moneyA=$("#AllmeonyB").val();
						AllmeonyX.value="总费用："+OKTimeValue*moneyA
					/* 	console.log(OKTimeValue)
						console.log(AllmeonyB) */
			var	ul=this.parentNode.parentNode;
				ul.parentNode.removeChild(ul);
		        ul=null;
		}
		}
	}
	
	
	
		
		/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk */
		
		
		// starttimeb=timeValueX;
		// endtimeb=timeValueH;
		
		/* 按钮 */
		var ButtonZ=document.getElementsByClassName("ButtonZ");
		
		var addressss=document.getElementsByClassName("addressss")[0];
		
			ButtonZ[0].onclick=function(){
				var address=document.getElementById("address");
				ButtonZ[0].style.backgroundColor="#1dacfa";
				ButtonZ[0].checked=true;
				ButtonZ[1].style.backgroundColor="#ffffff"
				ButtonZ[1].checked=false;
				ButtonZ[2].style.backgroundColor="#FFFFFF"
				ButtonZ[2].checked=false;
				address.removeAttribute("disabled")
				addressss.style.display="block";
				address.style.backgroundColor="white";
				address.style.color="black";
				address.value=addressa;
				address.setAttribute("placeholder","请输入详细地址")
		
		};
		ButtonZ[1].onclick=function(){
			var address=document.getElementById("address");
				ButtonZ[1].style.backgroundColor="#1dacfa";
				ButtonZ[1].checked=true;
				ButtonZ[0].style.backgroundColor="#FFFFFF"
				ButtonZ[0].checked=false;
				ButtonZ[2].style.backgroundColor="#FFFFFF"
				ButtonZ[2].checked=false;
				address.setAttribute("disabled","disabled")
				address.style.backgroundColor="slategray";
				address.style.color="white";
				address.value="到老师指定地点";
				addressss.style.display="none";
		}
		
		ButtonZ[2].onclick=function(){
			var address=document.getElementById("address");
				ButtonZ[1].style.backgroundColor="#FFFFFF";
				ButtonZ[1].checked=false;
				ButtonZ[0].style.backgroundColor="#FFFFFF"
				ButtonZ[0].checked=false;
				ButtonZ[2].style.backgroundColor="#1dacfa"
				ButtonZ[2].checked=true;
				address.setAttribute("disabled","disabled")
				address.style.backgroundColor="slategray";
				address.style.color="white";
				address.value="该用户对此无要求";
				addressss.style.display="none";
		}
		var teacherCourseid;
		
		if(courseid[0]=="1"){
			teacherCourseid = "语文";
			
		}
		else if(courseid[0]=="2"){
			teacherCourseid = "数学";
			
		}
		else if(courseid[0]=="3"){
			teacherCourseid = "英语";
			
		}
		else if(courseid[0]=="4"){
			teacherCourseid = "物理";
			
		}
		else if(courseid[0]=="5"){
			teacherCourseid = "化学";
			
		}
		else if(courseid[0]=="6"){
			teacherCourseid = "生物";
			
		}
		else if(courseid[0]=="7"){
			teacherCourseid = "历史";
			
		}
		else if(courseid[0]=="8"){
			teacherCourseid = "地理";
			
		}
		else if(courseid[0]=="9"){
			teacherCourseid = "政治";
			
		}else if(courseid[0]=="10"){
			teacherCourseid = "科学";
			
		}else if(courseid[0]=="11"){
			teacherCourseid = "音乐";
			
		}else if(courseid[0]=="12"){
			teacherCourseid = "美术";
			
		}else if(courseid[0]=="13"){
			teacherCourseid = "体育";
			
		}else if(courseid[0]=="14"){
			teacherCourseid = "信息";
			
		}else if(courseid[0]=="0"){
			teacherCourseid = "全学科";
			
		}
		
		if(gradeid == "1"){
			teacherGradeid = "小学";
			
		}
		else if(gradeid == "2"){
			teacherGradeid = "初中";
			
		}
		else if(gradeid == "3"){
			teacherGradeid = "高中";
			
		}else if(gradeid == "0"){
			teacherGradeid = "全学段";
			
		}
		
		var ordertype=obja.data.list[j].ordertype
		
		
		var nicknameValue=document.getElementById("nickname");
		var courseidValue=document.getElementById("xuanze");
		var gradeidValue=document.getElementById("xuanze1");
		var remarkValue=document.getElementById("remark");
		var teachplacetypeValue=document.getElementsByClassName("ButtonZ");
		console.log(teachplacetypeValue)
		nicknameValue.value=nickname;
		courseidValue.value=teacherCourseid;
		gradeidValue.value=teacherGradeid;
		remarkValue.value=remark;
		if(teachplacetype=="0"){
			var address=document.getElementById("address");
			var addressss=document.getElementsByClassName("addressss")[0];
			teachplacetypeValue[0].style.backgroundColor="#1dacfa";
			teachplacetypeValue[0].checked=true;
			teachplacetypeValue[1].style.backgroundColor="#ffffff"
			teachplacetypeValue[1].checked=false;
			teachplacetypeValue[2].style.backgroundColor="#ffffff"
			teachplacetypeValue[2].checked=false;
			address.removeAttribute("disabled")
			addressss.style.display="block";
			address.style.backgroundColor="white";
			address.style.color="black";
			address.value=addressa;
			address.setAttribute("placeholder","请输入详细地址")
		}else if(teachplacetype=="1"){
			var address=document.getElementById("address");
			var addressss=document.getElementsByClassName("addressss")[0];
			teachplacetypeValue[1].style.backgroundColor="#1dacfa";
			teachplacetypeValue[1].checked=true;
			teachplacetypeValue[0].style.backgroundColor="#FFFFFF"
			teachplacetypeValue[0].checked=false;
			teachplacetypeValue[2].style.backgroundColor="#FFFFFF"
			address.setAttribute("disabled","disabled")
			address.style.backgroundColor="slategray";
			address.style.color="white";
			address.value="到老师指定地点";
			addressss.style.display="none";
		}else if(teachplacetype=="2"){
			var address=document.getElementById("address");
			var addressss=document.getElementsByClassName("addressss")[0];
			teachplacetypeValue[2].style.backgroundColor="#1dacfa";
			teachplacetypeValue[2].checked=true;
			teachplacetypeValue[1].style.backgroundColor="#FFFFFF"
			teachplacetypeValue[1].checked=false;
			teachplacetypeValue[0].style.backgroundColor="#FFFFFF"
			teachplacetypeValue[0].checked=false;
			address.setAttribute("disabled","disabled")
			address.style.backgroundColor="slategray";
			address.style.color="white";
			address.value="该用户对此无要求";
			addressss.style.display="none";
		}
		var genderValue=document.getElementsByName("sex");
		
	if(teachersex=="1"){
		genderValue[0].checked=true;
		genderValue[1].checked=false;
		genderValue[2].checked=false;
	}else if(teachersex=="2"){
		genderValue[1].checked=true;
		genderValue[0].checked=false;
		genderValue[2].checked=false;
	}else if(teachersex=="0"){
		genderValue[2].checked=true;
		genderValue[1].checked=false;
		genderValue[0].checked=false;
	}
		var addprovincenameValue=document.getElementById("addprovincenameValue");
		var addcitynameValue=document.getElementById("addcitynameValue");
		var addareanameValue=document.getElementById("addareanameValue");
		addprovincenameValue.innerHTML=addprovincename;
		addcitynameValue.innerHTML=addcityname;
		addareanameValue.innerHTML=addareaname;
		
		addprovincenameValue.value=addprovincecode;
		addcitynameValue.value=addcitycode;
		addareanameValue.value=addareacode;
		
		//console.log(addcitycode);
		var addressValue=document.getElementById("address");
		addressValue.value=addressa;
		}
	    
		
		var phoneValue=document.getElementById("phone");
		phoneValue.value=phone;
		
		
		},function(code){
			console.log(code.status);
		});
		}
		
		



var DelT=document.getElementById("DelT");
	console.log(DelT);
	DelT.onclick=function(){
		Myajax("demandTime","GET","http://manage.woyaoxuexue.com/guns/app/deleteteachorder",
		{
			"orderid":orderid
		},10000,
		function(msg){
			var str=msg.responseText;
			var obja=eval("("+str+")");
			console.log(obja);
			location.href="P_publish.html"
		},function(code){
			console.log(code.status);
		})
	}



var code;

confirmx.onclick=function(){
	var nickname=document.getElementById("nickname").value;
	var gradeid=document.getElementById("xuanze1").value;
	var gender=document.getElementsByName("sex");
	console.log(gender)
	var teachersex;
	if(gender[0].checked){
		teachersex="1";
	}else if(gender[1].checked){
		teachersex="2";
	}else if(gender[2].checked){
		teachersex="0";
	}
	
	if(gradeid=='小学'){
		gradeid="1";
	}else if(gradeid=='初中'){
		gradeid="2";
	}else if(gradeid=='高中'){
		gradeid="3";
	}else if(gradeid=='全学段'){
		gradeid="0";
	}
	var courseid=document.getElementById("xuanze").value;
	if(courseid=='语文'){
		courseid="1";
	}else if(courseid=='数学'){
		courseid="2";
	}else if(courseid=='英语'){
		courseid="3";
	}else if(courseid=='物理'){
		courseid="4";
	}else if(courseid=='化学'){
		courseid="5";
	}else if(courseid=='生物'){
		courseid="6";
	}else if(courseid=='历史'){
		courseid="7";
	}else if(courseid=='地理'){
		courseid="8";
	}else if(courseid=='政治'){
		courseid="9";
	}else if(courseid=='政治'){
		courseid="9";
	}else if(courseid=='科学'){
		courseid="10";
	}else if(courseid=='音乐'){
		courseid="11";
	}else if(courseid=='美术'){
		courseid="12";
	}else if(courseid=='体育'){
		courseid="13";
	}else if(courseid=='信息'){
		courseid="14";
	}else if(courseid=='全学科'){
		courseid="0";
	}
	var placetype=document.getElementsByName("placeA");
	var teachplacetype;
	if(placetype[0].checked){
		teachplacetype="0";
	}else if(placetype[1].checked){
		teachplacetype="1";
	}else if(placetype[2].checked){
		teachplacetype="2";
	}else{
		teachplacetype=" ";
	}
	var address=document.getElementById("address").value;
	var totaltimex=document.getElementById("ClassTimeX").value;
	var totaltime=parseInt(totaltimex.substring(4));
	var amountx=document.getElementById("AllmeonyX").value;
	var amount=parseFloat(amountx.substring(4));
	var price=document.getElementById("AllmeonyB").value;
	var remark=document.getElementById("remark").value;
	var phone=document.getElementById("phone").value;
	console.log(weeka)
	console.log(starttimea)
	console.log(endtimea)
	/* var listxs=[{"week":weeka,"starttime":starttimea,"endtime":endtimea},{"week":weekb,"starttime":starttimeb,"endtime":endtimeb}] */
	
	// if(weeka=="周一"){
	// 	weeka=1;
	// }else if(weeka=="周二"){
	// 	weeka=2;
	// }else if(weeka=="周三"){
	// 	weeka=3;
	// }else if(weeka=="周四"){
	// 	weeka=4;
	// }else if(weeka=="周五"){
	// 	weeka=5;
	// }else if(weeka=="周六"){
	// 	weeka=6;
	// }else if(weeka=="周七"){
	// 	weeka=7;
	// }
	
	
	
	// if(typeof(weeka)=='undefined'){
	// 	weeka=""
	// }
	// if(typeof(weekb)=='undefined'){
	// 	weekb=""
	// }
	// if(typeof(weekc)=='undefined'){
	// 	weekc=""
	// }
	// if(typeof(weekd)=='undefined'){
	// 	weekd=""
	// }
	// if(typeof(weeke)=='undefined'){
	// 	weeke=""
	// }
	// if(typeof(weekf)=='undefined'){
	// 	weekf=""
	// }
	// if(typeof(weekg)=='undefined'){
	// 	weekg=""
	// }
	
	
	if(typeof(starttimea)=='undefined'){
		starttimea=""
	}
	 if(typeof(starttimeb)=='undefined'){
		starttimeb=""
	}
	 if(typeof(starttimec)=='undefined'){
		starttimec=""
	}
	if(typeof(starttimed)=='undefined'){
		starttimed=""
	}
	if(typeof(starttimee)=='undefined'){
		starttimee=""
	}
	if(typeof(starttimef)=='undefined'){
		starttimef=""
	}
	if(typeof(starttimeg)=='undefined'){
		starttimeg=""
	}
	
	
	if(typeof(endtimea)=='undefined'){
		endtimea=""
	}
	if(typeof(endtimeb)=='undefined'){
		endtimeb=""
	}
	 if(typeof(endtimec)=='undefined'){
		endtimec=""
	}
	if(typeof(endtimed)=='undefined'){
		endtimed=""
	}
	if(typeof(endtimee)=='undefined'){
		endtimee=""
	}
	if(typeof(endtimef)=='undefined'){
		endtimef=""
	}
	if(typeof(endtimeg)=='undefined'){
		endtimeg=""
	}
	
	
	var codea;

	
	
	/* var listx="%5B%7B%22week%22:"+"%223%22"+",%22starttime%22:"+"%2210:00%22"+",%22endtime%22:"+"%2211:00%22"+"%7D%5D" */
	parentid=$("#addprovincename").find("option:selected").val()
	parentidh=$("#addprovincename").find("option:selected").text()
	parentidv=$("#addcityname").find("option:selected").val()
	parentidvh=$("#addcityname").find("option:selected").text()
	parentide=$("#addareaname").find("option:selected").val()
	parentideh=$("#addareaname").find("option:selected").text()
	address=$("#address").val();
	console.log(address);
	var orderidVip;
	
	
	if(parentidh=='undefined'){
		parentid="";
		parentidh="";
		parentidv="";
		parentidvh="";
		parentide="";
		address="";
		parentideh="请核实您的授课方式！"
	}
	if(parentidvh=='undefined'){
	parentid="";
	parentidh="";
	parentidv="";
	parentidvh="";
	parentide="";
	address="";
	parentideh="请核实您的授课方式！"
		
	}
	if(parentideh=="undefined"){
		parentid="";
		parentidh="";
		parentidv="";
		parentidvh="";
		parentide="";
		address="";
		parentideh="请核实您的授课方式！"
	}
	
	if(!parentidh){
		parentid="";
		parentidh="";
		parentidv="";
		parentidvh="";
		parentide="";
		address="";
		parentideh="请核实您的授课方式！"
	}
	if(!parentidvh){
	parentid="";
	parentidh="";
	parentidv="";
	parentidvh="";
	parentide="";
	address="";
	parentideh="请核实您的授课方式！"
		
	}
	if(!parentideh){
		parentid="";
		parentidh="";
		parentidv="";
		parentidvh="";
		parentide="";
		address="";
		parentideh="请核实您的授课方式！"
	}
	
	
	
	Myajax("demand","GET","http://manage.woyaoxuexue.com/guns/app/updateteachorderforweb",
	{
		"orderid":orderidTT,
		"nickname":nickname,
		"gradeid":gradeid,
		"courseid":courseid,
		"teachersex":teachersex,
		"teachplacetype":teachplacetype,
		"addprovincecode":parentid,
		"addprovincename":parentidh,
		"addcitycode":parentidv,
		"addcityname":parentidvh,
		"addareacode":parentide,
		"addareaname":parentideh,
		"address":address,
		"phone":phone,
		"totaltime":totaltime,
		"price":price,
		"amount":amount,
		"remark":remark,
		"latitude":100,
		"longitude":100
	},100000,
	function(msg){
		var str=msg.responseText;
		var obja=eval("("+str+")");
		console.log(obja);
		/* orderidVip=obja.data.orderid;
		console.log(orderidVip) */
		code=obja.code;
		
		var p;
		var g;
		var TimlistWeek=[weeka,weekb,weekc,weekd,weeke,weekf,weekg];
		console.log(TimlistWeek)
		var TimlistStarttime=[starttimea,starttimeb,starttimec,starttimed,starttimee,starttimef,starttimeg];
		console.log(TimlistStarttime)
		var TimlistEndtime=[endtimea,endtimeb,endtimec,endtimed,endtimee,endtimef,endtimeg];
		console.log(TimlistEndtime)
		//  for(p=0;p<TimlistWeek.length;p++){
		// Myajax("demandTime","GET","http://manage.woyaoxuexue.com/guns/app/addteachordertimeforweb",
		// {
		// 	"orderid":orderidTT,
		// 	"datestr":TimlistWeek[p],
		// 	"starttime":TimlistStarttime[p],
		// 	"endtime":TimlistEndtime[p]
		// },10000,
		// function(msg){
		// 	var str=msg.responseText;
		// 	var obja=eval("("+str+")");
		// 	console.log(obja);
			
		// },function(code){
		// 	console.log(code.status);
		// })
		//  }
		
		GetTmi(weeka,starttimea,endtimea,1,0,1,AlltimeValue1)
		GetTmi(weekb,starttimeb,endtimeb,2,2,3,AlltimeValue2)
		GetTmi(weekc,starttimec,endtimec,3,4,5,AlltimeValue3)
		GetTmi(weekd,starttimed,endtimed,4,6,7,AlltimeValue4)
		GetTmi(weeke,starttimee,endtimee,5,8,9,AlltimeValue5)
		GetTmi(weekf,starttimef,endtimef,6,10,11,AlltimeValue6)
		GetTmi(weekg,starttimeg,endtimeg,7,12,13,AlltimeValue7)
		
		function GetTmi(week,starttime,endtime,w,s,e,AlltimeValue){
				week=$("#dayID"+w+"").val();
				if(!week){
					week="";
				}
			starttime=$("#timeclass"+s+"").find("option:selected").text();
			endtime=$("#timeclass"+e+"").find("option:selected").text();
			console.log(week)
			console.log(starttime) 
			console.log(endtime) 
		AlltimeValue=parseInt(endtime)-parseInt(starttime)
		if(isNaN(AlltimeValue)){
			AlltimeValue=0
		}
		console.log(AlltimeValue)
		
		Myajax("demandTime","GET","http://manage.woyaoxuexue.com/guns/app/addteachordertimeforweb",
		{
			"orderid":orderidTT,
			"datestr":week,
			"starttime":starttime,
			"endtime":endtime
		},10000,
		function(msg){
			var str=msg.responseText;
			var obja=eval("("+str+")");
			console.log(obja);
			
		},function(code){
			console.log(code.status);
		})
		}
		
		
		function returnA(){
			if(code==100000){
				alert("添加需求成功");
				window.location.assign("P_publish.html");
			}else{
				alert("添加需求失败");
			}
		}
		returnA();
		
		
	},function(code){
		console.log(code.status);
	})
	
}

	
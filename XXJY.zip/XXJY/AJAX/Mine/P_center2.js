var userid;
var addressAll=[];
var email;
var address;
var headpic;
var nickname;
var sex;
var phone;
var birthday;
var nicknameValue
var nicknameValueX;
getUserId();
function getUserId(){
	userid=localStorage.getItem("Userid")
}
console.log(userid)
getUserContent()
function getUserContent(){
	Myajax("getUserContent","GET","http://manage.woyaoxuexue.com/guns/app/getuserinfo",
	{
		"userid":userid,
	},10000,function(msg){
		var stra=msg.responseText;
		/* console.log(stra); */
		var obja=eval("("+stra+")");
		console.log(obja);
		var nickname=obja.data.nickname;
		var headpic=obja.data.headpic;
		/* var ssq=obja.data.technicianinfo.ssq; */
		/* console.log(ssq); */
		/* addressAll=ssq.split(" "); */
		/* email=obja.data.technicianinfo.email; */
		if(nickname!="" && nickname!=null){
		$("#nicknameValue").empty();
		$("#nicknameValue").html(nickname)
		}
		console.log(headpic)
		if(headpic!="" && headpic!=null){
		$("#pickkk").attr("src",headpic);
		}
	},function(code){
		console.log(code.status);
	})
}

$("#btnclear").click(function(){
	/* sessionStorage.removeItem("ID"); */
	localStorage .removeItem("Userid");
	localStorage .removeItem("Useridx");
	localStorage .removeItem("userType");
	localStorage .removeItem("TecherId");
	localStorage .removeItem("TechnicianId");
	delCookie("userid","/");
	window.location.assign("../Mine/login.html");
	delCookie("userid","/");
})
var orderid;
var listLength;
var j;
var price;
var userid;
var allMoney;
var classnum;
var teacherIDX;
var skillid;
var ordertype;
getSkillId()
function getSkillId(){
    orderid = sessionStorage.getItem("ID");
 			GetOrederTeacher();
			console.log(orderid)
}
useridx()
function useridx(){
	userid=localStorage.getItem("Userid");
}


function GetOrederTeacher(){
	Myajax("getSkill","GET","http://manage.woyaoxuexue.com/guns/app/getjishiorderdetail",
	{
		"page":1,
		"rows":9999,
		"orderid":orderid
	},100000,
	function(msg){
		var str=msg.responseText;
		var obja=eval("("+str+")");
		console.log(obja);
		var firstname=obja.data.firstname+"老师";
		//console.log(firstname);
		id=obja.data.id;
		teacherIDX=obja.data.userid;
		var addareaname=obja.data.addareaname;
		var addprovincename=obja.data.addprovincename;
		var addcityname=obja.data.addcityname;
		var address=obja.data.address;
		/* console.log(id); */
		/* userid=obja.data.userid; */
		/* console.log(userid); */
		var photo=obja.data.photo;
		//console.log(photo);
		var sex=obja.data.sex;
		//console.log(sex);
		skillid=obja.data.skillid;
		//console.log(skillid);
		var amount=obja.data.amount;
		var introduction=obja.data.introduction;
		//console.log(introduction);
		var integrate=obja.data.integrate;
		var classnum=obja.data.classnum;
		//console.log(integrate);
		price=obja.data.price;
		/* console.log(price); */
		var teachplacetype=obja.data.teachplacetype;
		/* console.log(teachplacetype); */
		ordertype=obja.data.ordertype;
		/*技能 转化 */
		
		if(skillid==1){
			skillid="种植";
		}else if(skillid==2){
			skillid="茶艺"
		}else if(skillid==3){
			skillid="维修"
		}else if(skillid==4){
			skillid="健身"
		}else if(skillid==5){
			skillid="舞蹈"
		}
		//console.log(skillid)
		/* 性别转换 */
		
			if(sex==1){
			sex="男";
		}else if(sex==2){
			sex="女";
		}else{
			sex="出错了";
		}
		//console.log(sex)
		/* 上课方式转换 */		
			
		if(teachplacetype==0){
			teachplacetype="请老师上门";
		}else if(teachplacetype==1){
			teachplacetype="到老师指定地点";
		}
		/* var allmenoy;
		
		var ClassTime=document.getElementsByClassName("ClassTime");
			ClassTime.onmouseleave=function(){
			allmenoy=ClassTime.value*price;
			} */
		
			
			var useridChat=obja.data.technicianid;
			
			
			
			
			
			
			
			
			
			
			
			if ( ordertype== 0) {
				ordertype="订单已取消"
		var mainChilder="<h4>教师简介</h4><p>"+introduction+"</p><ul><li>综合评价</li><button type=\"button\" onclick=\"addCollect()\"><a><img src=\"content/img/fixed_img/点击收藏.jpg\" ></a></button><li>授课经验:"+integrate+"</li><li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+classnum+"</li><li id=\"change\">总价:"+amount+"</li></ul>";
		var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>技能：</li><span>"+skillid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form   class=\"form1\"><img  src=\""+photo+"\"></form></div><a onclick=\"ONUrl()\" ><button  onclick=\"setTouserid("+useridChat+",\'"+firstname+","+photo+"\')\" type=\"button\"><img src=\"content/img/fixed_img/在线联系.jpg\" ></button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+"."+addcityname+"."+addareaname+""+address+"</span></a></p>";
		$(".banner").append(bannerChildren)
		$(".main").append(mainChilder);
		
		
			} else if ( ordertype== 1) {
				ordertype="订单已发布"
			var mainChilder="<h4>教师简介</h4><p>"+introduction+"</p><ul><li>综合评价</li><button type=\"button\" onclick=\"addCollect()\"><a><img src=\"content/img/fixed_img/点击收藏.jpg\" ></a></button><li>授课经验:"+integrate+"</li><li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+classnum+"</li><li id=\"change\">总价:"+amount+"</li></ul><a><button onclick=\"ConfirmPay()\" type=\"button\">取消订单</button></a><br><br><a><button onclick=\"ConfirmPayQQ()\" type=\"button\">确认订单</button></a>";
			var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>技能：</li><span>"+skillid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form   class=\"form1\"><img  src=\""+photo+"\"></form></div><a onclick=\"ONUrl()\" ><button onclick=\"setTouserid("+useridChat+",\'"+firstname+","+photo+"\')\" type=\"button\"><img src=\"content/img/fixed_img/在线联系.jpg\" ></button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+"."+addcityname+"."+addareaname+""+address+"</span></a></p>";
			$(".banner").append(bannerChildren)
			$(".main").append(mainChilder);
			
			
			} else if(ordertype== 2){
				ordertype="订单已领取"
				var mainChilder="<h4>教师简介</h4><p>"+introduction+"</p><ul><li>综合评价</li><button type=\"button\" onclick=\"addCollect()\"><a><img src=\"content/img/fixed_img/点击收藏.jpg\" ></a></button><li>授课经验:"+integrate+"</li><li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+classnum+"</li><li id=\"change\">总价:"+amount+"</li></ul><a><button onclick=\"ConfirmPay()\" type=\"button\">取消订单</button></a><br><br><a><button onclick=\"ConfirmPayQQ()\" type=\"button\">确认订单</button></a>";
				var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>技能：</li><span>"+skillid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form   class=\"form1\"><img  src=\""+photo+"\"></form></div><a onclick=\"ONUrl()\" ><button onclick=\"setTouserid("+useridChat+",\'"+firstname+","+photo+"\')\" type=\"button\"><img src=\"content/img/fixed_img/在线联系.jpg\" ></button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+"."+addcityname+"."+addareaname+""+address+"</span></a></p>";
				$(".banner").append(bannerChildren)
				$(".main").append(mainChilder);
				
				
			}else if(ordertype== 3){
				ordertype="订单已完成"
			var mainChilder="<h4>教师简介</h4><p>"+introduction+"</p><ul><li>综合评价</li><button type=\"button\" onclick=\"addCollect()\"><a><img src=\"content/img/fixed_img/点击收藏.jpg\" ></a></button><li>授课经验:"+integrate+"</li><li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+classnum+"</li><li id=\"change\">总价:"+amount+"</li></ul>";
			var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>技能：</li><span>"+skillid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form   class=\"form1\"><img  src=\""+photo+"\"></form></div><a onclick=\"ONUrl()\" ><button onclick=\"setTouserid("+useridChat+",\'"+firstname+","+photo+"\')\" type=\"button\"><img src=\"content/img/fixed_img/在线联系.jpg\" ></button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+"."+addcityname+"."+addareaname+""+address+"</span></a></p>";
			$(".banner").append(bannerChildren)
			$(".main").append(mainChilder);
			
			
			}else if(ordertype== 4){
				ordertype="订单进行中"
				var mainChilder="<h4>教师简介</h4><p>"+introduction+"</p><ul><li>综合评价</li><button type=\"button\" onclick=\"addCollect()\"><a><img src=\"content/img/fixed_img/点击收藏.jpg\" ></a></button><li>授课经验:"+integrate+"</li><li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+classnum+"</li><li id=\"change\">总价:"+amount+"</li></ul><a><button onclick=\"ConfirmPay()\" type=\"button\">取消订单</button></a><br><br><a><button onclick=\"ConfirmPayQQ()\" type=\"button\">确认订单</button></a>";
				var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>技能：</li><span>"+skillid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form   class=\"form1\"><img  src=\""+photo+"\"></form></div><a onclick=\"ONUrl()\" ><button onclick=\"setTouserid("+useridChat+",\'"+firstname+","+photo+"\')\" type=\"button\"><img src=\"content/img/fixed_img/在线联系.jpg\" ></button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+"."+addcityname+"."+addareaname+""+address+"</span></a></p>";
				$(".banner").append(bannerChildren)
				$(".main").append(mainChilder);
				
				
			}else if(ordertype== 5){
				ordertype="订单待支付"
			var mainChilder="<h4>教师简介</h4><p>"+introduction+"</p><ul><li>综合评价</li><button type=\"button\" onclick=\"addCollect()\"><a><img src=\"content/img/fixed_img/点击收藏.jpg\" ></a></button><li>授课经验:"+integrate+"</li><li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+classnum+"</li><li id=\"change\">总价:"+amount+"</li></ul><a><button onclick=\"ConfirmPay()\" type=\"button\">取消订单</button></a><br><br><a><button onclick=\"ConfirmPayQQ()\" type=\"button\">确认订单</button></a>";
			var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>技能：</li><span>"+skillid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form   class=\"form1\"><img  src=\""+photo+"\"></form></div><a onclick=\"ONUrl()\" ><button onclick=\"setTouserid("+useridChat+",\'"+firstname+","+photo+"\')\" type=\"button\"><img src=\"content/img/fixed_img/在线联系.jpg\" ></button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+"."+addcityname+"."+addareaname+""+address+"</span></a></p>";
			$(".banner").append(bannerChildren)
			$(".main").append(mainChilder);
			
			
			}
			
			
			
			
			
			
			
			
			
			
	},function(code){
		console.log(code.status);
	}
	);
};
function money(){
	//console.log("333");
	
	//console.log(ClassTime.demo.value);
	classnum=demo.value;
	allMoney=demo.value*price;
	if(allMoney<0){
		allMoney=0;
	}
	$("#change").text("总价:"+allMoney);
}
function addCollect(){
	Myajax("collectionuserid","GET","http://manage.woyaoxuexue.com/guns/app/addcollection",
	{
		"collectionuserid":teacherIDX,
		"userid":userid,
		"usertype":2
	},100000,function(msg){
		var str=msg.responseText;
		var objb=eval("("+str+")");
		console.log(objb);
		console.log(userid)
	var msgor=objb.msg;
	var codeor=objb.code;
	if(codeor=="100000"){
	alert("收藏成功");
	window.location.assign("../Mine/P_collect.html")
	}else if(msgor=="已添加当前数据，请勿重复添加"){
		alert(msgor);
	}
	},function(code){
		console.log(code.status);
	})
}


function ConfirmPay(){
	
	Myajax("cellPay","GET","http://manage.woyaoxuexue.com/guns/app/technicianconfirmjishiorder",
	{
		
		"orderid":orderid,
		"ordertype":0
	},10000,function(msg){
		var strr=msg.responseText;
		/* console.log(strr) */
		var objr=eval("("+strr+")")
		 console.log(objr) 
		 var msgpay=objr.msg;
		 console.log(teacherIDX)
		 var codepay=objr.code;
		 if(msgpay=="添加用户技师需求失败"){
			 alert(msgpay)
		 }else if(codepay=="100000"){
			 alert("取消成功");
			 window.location.assign("../Mine/P_order2.html");
			 
		 }
		 
		 
	},function(code){
		console.log(code.status)
	})
}


function ConfirmPayQQ(){
	
	Myajax("cellPay","GET","http://manage.woyaoxuexue.com/guns/app/technicianconfirmjishiorder",
	{
		
		"orderid":orderid,
		"ordertype":5
	},10000,function(msg){
		var strr=msg.responseText;
		/* console.log(strr) */
		var objr=eval("("+strr+")")
		 console.log(objr) 
		 var msgpay=objr.msg;
		 console.log(teacherIDX)
		 var codepay=objr.code;
		 if(msgpay=="添加用户技师需求失败"){
			 alert(msgpay)
		 }else if(codepay=="100000"){
			 alert("确认订单成功");
			 window.location.assign("../Mine/P_order2.html");
			 
		 }
		 
		 
	},function(code){
		console.log(code.status)
	})
}

function ONUrl(){
	if(getCookie("userid","/")){
	 		 window.location.assign("../Index/xiaoxi.html");
	}else{
	 		 window.location.assign("../Mine/login.1.html")
	}
}
function setTouserid(touserid,name,photo){
	sessionStorage.removeItem("Touserid");
	sessionStorage.removeItem("Name");
	sessionStorage.removeItem("Photo");
	sessionStorage.setItem("Touserid", touserid);
	sessionStorage.setItem("Name", name);
	sessionStorage.setItem("Photo", photo);
	//}
	}

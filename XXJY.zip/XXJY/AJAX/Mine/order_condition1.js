var orderid;
var courseid;
var gradeid;
var userid;
var useridx;
var HTMLCONT="../Good_tea/tea_content.5.html"
GERid()
function GERid(){
    orderid = localStorage.getItem("ID");
	//id = Id;
	/* console.log(userid); */
	teacherid=localStorage.getItem("TecherId");
	console.log(orderid)
	OrderCondition();
}

function OrderCondition(){
	Myajax("OrderCondition","GET","http://manage.woyaoxuexue.com/guns/app/getteachorderlist",
	{
		"page":1,
		"rows":9999,
		"orderid":orderid
	},10000,function(msg){
		var str=msg.responseText;
		var obja=eval("("+str+")");
		console.log(obja)
		var weekArry=[];
		var endtimeArry=[];
		var starttimeArry=[];
		var listLength=obja.data.list.length;
		/* console.log(listLength) */
		var eee="";
		for(var j=0;j<listLength;j++){
			var teacheridaaa=obja.data.list[j].teacherid;
			var nickname=obja.data.list[j].nickname;
			/* console.log(nickname); */
			var addareaname=obja.data.list[j].addareaname;
			/* console.log(addareaname); */
			var addprovincename=obja.data.list[j].addprovincename;
			/* console.log(addprovincename); */
			var addcityname=obja.data.list[j].addcityname;
			/* console.log(addcityname); */
			var address=obja.data.list[j].address;
			//console.log(address);
			var totaltime=obja.data.list[j].totaltime;
		/* console.log(totaltime); */
		var price=obja.data.list[j].price;
		useridx=obja.data.list[j].userid;
		//console.log(price);
		var amount=obja.data.list[j].amount;
		//console.log(amount);
		var headpic=obja.data.list[j].headpic;
		//console.log(headpic);
		var remark=obja.data.list[j].remark;
		if(typeof(remark)=='undefined'){
			remark="<span>系统提示<\span>：他暂时没什么想说的"
		}
		//console.log(remark);
		courseid=obja.data.list[j].courseid;
		//console.log(courseid);
		gradeid=obja.data.list[j].gradeid;
		//console.log(gradeid);
		var teachersex=obja.data.list[j].teachersex;
		//console.log(teachersex);
		if(teachersex=="1"){
			teachersex="男"
		}else if(teachersex=="2"){
			teachersex="女"
		}
		var teachplacetype=obja.data.list[j].teachplacetype;
		//console.log(teachplacetype);
		if(teachplacetype=="1"){
			teachplacetype="请老师上门"
		}else if(teachplacetype=="2"){
			teachplacetype="到老师指定地点"
		}
		id=obja.data.list[j].id;
		console.log(id);
		var timeListArry=obja.data.list[j].timelist;
		/* console.log(timeListArry); */
		var timelistArryLength=timeListArry.length
		/* console.log(timelistArryLength) */
		for(var t=0;t<timelistArryLength;t++){
			var week=timeListArry[t].week;
			//console.log(week)
			var endtime=timeListArry[t].endtime;
			//console.log(endtime)
			var starttime=timeListArry[t].starttime;
			//console.log(starttime)
			var endtimeValue=endtime.split(" ")
			//console.log(endtimeValue)
			var endtimeValue=String(endtimeValue[0])
			var endtimeValue=endtimeValue.slice(0,5)
			//console.log(endtimeValue)
			var starttimeValue=starttime.split(" ")
			var starttimeValue=String(starttimeValue[0])
			//console.log(starttimeValue)
			var starttimeValue=starttimeValue.slice(0,5)
			//console.log(starttimeValue)
			var datestr=timeListArry[t].datestr;
			console.log(datestr)
			datestr=datestr.split(" ")
			datestr=datestr[0]
			datestr=datestr.split("-")
			datestr=datestr.join("/")
			console.log(datestr)
			if(week=="1"){
				week="周一"
			}else if(week=="2"){
				week="周二"
			}else if(week=="3"){
				week="周三"
			}else if(week=="4"){
				week="周四"
			}else if(week=="5"){
				week="周五"
			}else if(week=="6"){
				week="周六"
			}else if(week=="7"){
				week="周七"
			}
			week=datestr+"&nbsp"+week
		weekArry.push(week);
		starttimeArry.push(starttimeValue);
		endtimeArry.push(endtimeValue);
		//console.log(weekArry)
		//console.log(starttimeArry)
		//console.log(endtimeArry)
		}
		
		
		
		var teacherCourseid;
		var teacherGradeid;
		if(courseid[0]=="1"){
			teacherCourseid = "语文";
			
		}
		else if(courseid[0]=="2"){
			teacherCourseid = "数学";
			
		}
		else if(courseid[0]=="3"){
			teacherCourseid = "英语";
			
		}
		else if(courseid[0]=="4"){
			teacherCourseid = "物理";
			
		}
		else if(courseid[0]=="5"){
			teacherCourseid = "化学";
			
		}
		else if(courseid[0]=="6"){
			teacherCourseid = "生物";
			
		}
		else if(courseid[0]=="7"){
			teacherCourseid = "历史";
			
		}
		else if(courseid[0]=="8"){
			teacherCourseid = "地理";
			
		}
		else if(courseid[0]=="9"){
			teacherCourseid = "政治";
			
		}
		else if(courseid[0]=="10"){
			teacherCourseid = "科学";
			
		}
		else if(courseid[0]=="11"){
			teacherCourseid = "音乐";
			
		}
		else if(courseid[0]=="12"){
			teacherCourseid = "美术";
			
		}
		else if(courseid[0]=="13"){
			teacherCourseid = "体育";
			
		}
		else if(courseid[0]=="14"){
			teacherCourseid = "信息";
			
		}else if(courseid[0]=="0"){
			teacherCourseid = "全学科";
			
		}
		
		if(gradeid == "1"){
			teacherGradeid = "小学";
			
		}
		else if(gradeid == "2"){
			teacherGradeid = "初中";
			
		}
		else if(gradeid == "3"){
			teacherGradeid = "高中";
			
		}else if(gradeid == "0"){
			teacherGradeid = "全学段";
			
		}
/* 		var contentMainValue="<div class=\"normal\"><p>基本信息</p><div class=\"weui-flex\"><div class=\"weui-flex__item normal_content\"><span>昵称：</span><span>"+nickname+"</span><br/><span>需求科目：</span><span>"+teacherCourseid+"</span><br/><span>需求学段：</span><span>"+teacherGradeid+"</span><br/><span>性别：</span><span>"+teachersex+"</span><br/><span>上课方式：</span><span>"+teachplacetype+"</span></div><div class=\"weui-flex__item normal_img\"><img src=\""+headpic+"\" /></div></div></div><div class=\"class_adr\"><p>上课地点</p><div class=\"class_adrs\"><span>"+addareaname+"&nbsp;"+addprovincename+"&nbsp;"+addcityname+"&nbsp;"+address+"<p></p></span></div></div><div class=\"class_time\"><p>计划课时安排</p><div class=\"time_content\"><p id=\"timelist0\">"+weekArry[0]+"&nbsp;&nbsp;"+starttimeArry[0]+"--"+endtimeArry[0]+"</p>"+eee+"<p id=\"timelist1\">"+weekArry[1]+"&nbsp;&nbsp;"+starttimeArry[1]+"--"+endtimeArry[1]+"</p>"+eee+"<p id=\"timelist2\">"+weekArry[2]+"&nbsp;&nbsp;"+starttimeArry[2]+"--"+endtimeArry[2]+"</p>"+eee+"<p id=\"timelist3\">"+weekArry[3]+"&nbsp;&nbsp;"+starttimeArry[3]+"--"+endtimeArry[3]+"</p>"+eee+"<p id=\"timelist4\">"+weekArry[4]+"&nbsp;&nbsp;"+starttimeArry[4]+"--"+endtimeArry[4]+"</p>"+eee+"<p id=\"timelist5\">"+weekArry[5]+"&nbsp;&nbsp;"+starttimeArry[5]+"--"+endtimeArry[5]+"</p>"+eee+"<p id=\"timelist6\">"+weekArry[6]+"&nbsp;&nbsp;"+starttimeArry[6]+"--"+endtimeArry[6]+"</p>"+eee+"</div></div><div class=\"one_fee\"><p>单次课程费用</p><div class=\"one_fees\"><span>"+price+"元</span></div></div><div class=\"all_time\"><p>总课时</p><div class=\"all_times\"><span>"+totaltime+"课时</span></div></div><div class=\"all_fee\"><p>总费用</p><div class=\"all_fees\"><span>"+amount+"元</span></div></div><div class=\"notice\"><p>备注</p><div class=\"notice_c\"><p>"+remark+"</p></div></div><div class=\"btn\"><a onclick=\"cofirREN()\" href=\"javascript:;\" class=\"weui-btn bg-blue\">认领</a></div>"; */
				var contentMainValue="<div class=\"banner\"><ul class=\"order_c_ul\"><li>基本信息</li><br><li>昵称：</li><span>"+nickname+"</span><li>需求科目：</li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>"+teacherCourseid+"</span><li>需求学段：</li><span>"+teacherGradeid+"</span><li>性别：</li><span>"+teachersex+"</span></ul><div class=\"headerKuang\"><form  id=\"form1\" class=\"form1\"><img id=\"pic\" src=\""+headpic+"\">   </form></div><p class=\"order_cp\">授课地点:</p><p class=\"order_cp\">&nbsp;&nbsp;&nbsp;&nbsp;"+addprovincename+"&nbsp;"+addcityname+"&nbsp;"+addareaname+"&nbsp;"+address+"</p><br><p class=\"order_cp\">计划课时安排:</p><p class=\"order_cp\" id=\"timelist0\">"+weekArry[0]+"&nbsp;&nbsp;"+starttimeArry[0]+"--"+endtimeArry[0]+"</p>"+eee+"<p id=\"timelist1\">"+weekArry[1]+"&nbsp;&nbsp;"+starttimeArry[1]+"--"+endtimeArry[1]+"</p>"+eee+"<p id=\"timelist2\">"+weekArry[2]+"&nbsp;&nbsp;"+starttimeArry[2]+"--"+endtimeArry[2]+"</p>"+eee+"<p id=\"timelist3\">"+weekArry[3]+"&nbsp;&nbsp;"+starttimeArry[3]+"--"+endtimeArry[3]+"</p>"+eee+"<p id=\"timelist4\">"+weekArry[4]+"&nbsp;&nbsp;"+starttimeArry[4]+"--"+endtimeArry[4]+"</p>"+eee+"<p id=\"timelist5\">"+weekArry[5]+"&nbsp;&nbsp;"+starttimeArry[5]+"--"+endtimeArry[5]+"</p>"+eee+"<p id=\"timelist6\">"+weekArry[6]+"&nbsp;&nbsp;"+starttimeArry[6]+"--"+endtimeArry[6]+"</p>"+eee+"<br><p class=\"order_cp\">当次课程费用</p><p class=\"order_cp\">&nbsp;&nbsp;&nbsp;&nbsp;"+price+"元</p><br><p class=\"order_cp\">总费用</p><p class=\"order_cp\">&nbsp;&nbsp;&nbsp;&nbsp;"+amount+"元</p><br><p class=\"order_cp\">备注</p><p class=\"order_cp\">&nbsp;&nbsp;&nbsp;&nbsp;"+remark+"</p><br><p class=\"order_cp\" id=\"fanrenlei\" style=\"text-align: center;font-size: 12px\">订单支付中……</p></div><br><br><br><br><br><br><br><br><div class=\"btns\"><button class=\"find_teacher\"><a onclick=\"holdId("+teacheridaaa+")\" href=\""+HTMLCONT+"\">查看老师</a></button><button onclick=\"payconfir()\" class=\"retire_teacher\" >完成订单</button></div>"
		
		$(".MainContin").append(contentMainValue)
		
		if(weekArry.length<2){
			$("#timelist1").remove();
			$("#timelist2").remove();
			$("#timelist3").remove();
			$("#timelist4").remove();
			$("#timelist5").remove();
			$("#timelist6").remove();
		}else if(weekArry.length<3){
			$("#timelist2").remove();
			$("#timelist3").remove();
			$("#timelist4").remove();
			$("#timelist5").remove();
			$("#timelist6").remove();
		}else if(weekArry.length<4){
			$("#timelist3").remove();
			$("#timelist4").remove();
			$("#timelist5").remove();
			$("#timelist6").remove();
		}else if(weekArry.length<5){
			
			$("#timelist4").remove();
			$("#timelist5").remove();
			$("#timelist6").remove();
		}else if(weekArry.length<6){
			
			
			$("#timelist5").remove();
			$("#timelist6").remove();
		}else if(weekArry.length<7){
			$("#timelist6").remove();
		}
		
		var orderno=obja.data.list[j].orderno;
		var ordertype=obja.data.list[j].ordertype;
		var teacherid=obja.data.list[j].teacherid;
		var technicianid=obja.data.list[j].technicianid;
		GETorderno(orderno,ordertype,teacherid,technicianid)
		
		
		
		}
		
		
		 
		function GETorderno(orderno,ordertype,teacherid,technicianid){
			sessionStorage.removeItem("OrderNO");
			sessionStorage.removeItem("Ordertype");
			sessionStorage.removeItem("Teacherid");
			sessionStorage.removeItem("Technicianid");
			
			sessionStorage.setItem("OrderNO",orderno)
			sessionStorage.setItem("Ordertype",ordertype)
			sessionStorage.setItem("Teacherid",teacherid)
			sessionStorage.setItem("Technicianid",technicianid)
		}
		
	},function(code){
		console.log(code.status);
	})
}




function holdId(Id){
		sessionStorage.removeItem("ID");
		//if (typeof(Storage) !== "undefined") {
	    // 存储
		console.log(Id);
	    sessionStorage.setItem("ID", Id);
		//}
		//var jsId = window.sessionStorage;
		//jsId = Id;
	}
	


	function payconfir(){
		console.log(orderid)
		console.log(useridx)
		console.log(userid)
		Myajax("payconfir","GET","http://manage.woyaoxuexue.com/guns/app/userconfirmteachorder",
		{
			"orderid":orderid,
			"userid":useridx
		},10000,function(msg){
			var str=msg.responseText;
			var obja=eval("("+str+")");
			console.log(obja)
			var code=obja.code;
			if(code==100000){
				alert("订单完成成功")
				window.location.assign("../Mine/pingfen.html")
			}else{
				alert("出错了")
			}
		},function(code){
			console.log(code.status)
		})
	}
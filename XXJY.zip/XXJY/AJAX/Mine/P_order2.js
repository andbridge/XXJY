var teacherid;
var page=1;
var rows=9999;
var technicianid;
var id;
var orderid;
var ordertype;
var ordertypex;
var userid;
GetTeacherID();
function GetTeacherID(){
	teacherid=localStorage.getItem("TecherId");
	technicianid=localStorage.getItem("TechnicianId");
	console.log(teacherid);
	/* console.log(userid) */
	console.log(technicianid);
	GoodTeacherOrder();
	GoodJSOrder();
	GoodXQOrder();
}



function GoodXQOrder(){
	console.log(teacherid)
	Myajax("GoodTeacherOrder","GET","http://manage.woyaoxuexue.com/guns/app/getteachorderlist",
	{
		"page":page,    
		"rows":rows,     
		"teacherid":teacherid    
	},10000,function(msg){
		var HTMLURL="../Index/need_c.5.html"
		var strre=msg.responseText;
		/* console.log(strre); */
		var objh=eval("("+strre+")");
		console.log(objh)
		var lengthList=objh.data.list.length;
		console.log(lengthList)
		for(var h=0;h<lengthList;h++){
			var amount=objh.data.list[h].amount;
			/* console.log(amount); */
			var totaltime=objh.data.list[h].totaltime;
			/* console.log(classnum); */
			id=objh.data.list[h].id;
			console.log(id);
			ordertype=objh.data.list[h].ordertype;
			 userid=objh.data.list[h].userid;
			 var photo=objh.data.list[h].photo;
			 console.log(photo)
			if ( ordertype== 0) {
				ordertype="订单已取消"
				var OrderValue="<div class=\"publish\"><a  href=\""+HTMLURL+"\" onclick=\"holdId("+id+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+classnum+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a><br></div>"
				$(".publishX").append(OrderValue)
			} else if ( ordertype == 1) {
				ordertype="等待老师确认"
				var OrderValue="<div class=\"publish\"><a  href=\""+HTMLURL+"\" onclick=\"holdId("+id+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+classnum+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a><br></div>"
				$(".publishX").append(OrderValue)
			} else if(ordertype== 2){
				ordertype="待支付"
				var OrderValue="<div class=\"publish\"><a href=\""+HTMLURL+"\"  onclick=\"holdId("+id+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+totaltime+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a></div>"
				$(".publishX").append(OrderValue)
			}else if(ordertype== 3){
				ordertype="订单已完成"
				var OrderValue="<div class=\"publish\"><a href=\""+HTMLURL+"\"  onclick=\"holdId("+id+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+totaltime+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a></div>"
				$(".publishX").append(OrderValue)
			}else if(ordertype== 4){
				ordertype="订单进行中"
				var OrderValue="<div class=\"publish\"><a href=\""+HTMLURL+"\"  onclick=\"holdId("+id+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+totaltime+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a></div>"
				$(".publishX").append(OrderValue)
			}// }else if(ordertype== 5){
			// 	ordertype="订单待支付"
			// 	var OrderValue="<div class=\"publish\"><a href=\""+HTMLURL+"\"  onclick=\"holdId("+id+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+totaltime+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a></div>"//<a  onclick=\"xQreder("+id+","+userid+")\" class=\"cancel_btn\">取消订单</a><a onclick=\"QOreder("+id+")\" class=\"confirm_btn\">确定订单</a>
			// 	$(".publishX").append(OrderValue)
			// }
			/* console.log(ordertype); */
		
			console.log(id)
		
			
		}
	},function(code){
		console.log(code.status);
	})

}


function GoodTeacherOrder(){
	$(".publishX").empty;
	Myajax("GoodTeacherOrder","GET","http://manage.woyaoxuexue.com/guns/app/getmingshiorderbyteacherid",
	{
		"page":page,    
		"rows":rows,    
		"teacherid":teacherid     
	},10000,function(msg){
		var HTMLURL="../Good_tea/OrederTeacher.html"
		var strre=msg.responseText;
		/* console.log(strre); */
		var objh=eval("("+strre+")");
		console.log(objh)
		var lengthList=objh.data.list.length;
		console.log(lengthList)
		for(var h=0;h<lengthList;h++){
			var amount=objh.data.list[h].amount;
			/* console.log(amount); */
			var classnum=objh.data.list[h].classnum;
			/* console.log(classnum); */
			orderid=objh.data.list[h].orderid;
			console.log(orderid);
			ordertype=objh.data.list[h].ordertype;
			var photo=objh.data.list[h].photo;
			console.log(photo)
			if ( ordertype== 0) {
				ordertype="订单已取消"
					var OrderValue="<div class=\"publish\"><a href=\""+HTMLURL+"\"  onclick=\"holdId("+orderid+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+classnum+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a><br></div>"
					$(".publishX").append(OrderValue)
					
			} else if ( ordertype== 1) {
				ordertype="等待老师确认"
				var OrderValue="<div class=\"publish\"><a   href=\""+HTMLURL+"\" onclick=\"holdId("+orderid+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+classnum+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a><br></div>"
				$(".publishX").append(OrderValue)
			} else if(ordertype== 2){
				ordertype="待支付"
				var OrderValue="<div class=\"publish\"><a href=\""+HTMLURL+"\"  onclick=\"holdId("+orderid+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+classnum+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a><br></div>"
				$(".publishX").append(OrderValue)
			}else if(ordertype== 3){
				ordertype="订单已完成"
				var OrderValue="<div class=\"publish\"><a href=\""+HTMLURL+"\"  onclick=\"holdId("+orderid+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+classnum+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a><br></div>"
				$(".publishX").append(OrderValue)
			}else if(ordertype== 4){
				ordertype="订单进行中"
				var OrderValue="<div class=\"publish\"><a href=\""+HTMLURL+"\"  onclick=\"holdId("+orderid+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+classnum+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a><br></div>"
				$(".publishX").append(OrderValue)
			}// }else if(ordertype== 5){
			// 	ordertype="订单待支付"
			// 	var OrderValue="<div class=\"publish\"><a href=\""+HTMLURL+"\"  onclick=\"holdId("+orderid+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+classnum+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a><br></div>"//<a  onclick=\"xQreder("+orderid+")\" class=\"cancel_btn\">取消订单</a><a onclick=\"QOreder("+orderid+")\" class=\"confirm_btn\">确定订单</a>
			// 	$(".publishX").append(OrderValue)
			// }
			/* console.log(ordertype); */
		
			console.log(orderid)
	
		}
	},function(code){
		console.log(code.status);
	})

}






function GoodJSOrder(){
	$(".publishX").empty;
	Myajax("GoodTeacherOrder","GET","http://manage.woyaoxuexue.com/guns/app/getjishiorderbytechnicianid",
	{
		"page":page,
		"rows":rows,
		"technicianid":technicianid
	},10000,function(msg){
		var HTMLURL="../Skill/OrderConten.html"
		var strre=msg.responseText;
		/* console.log(strre); */
		var objh=eval("("+strre+")");
		console.log(objh)
		console.log(technicianid)
		var lengthList=objh.data.list.length;
		console.log(lengthList)
		for(var h=0;h<lengthList;h++){
			var amount=objh.data.list[h].amount;
			console.log(amount);
			
			var classnum=objh.data.list[h].classnum;
			console.log(classnum);
			var orderid=objh.data.list[h].orderid;
			console.log(orderid);
			var ordertype=objh.data.list[h].ordertype;
			var photo=objh.data.list[h].photo;
			console.log(photo)
			if ( ordertype== 0) {
				ordertype="订单已取消"
					var OrderValue="<div class=\"publish\"><a href=\""+HTMLURL+"\" onclick=\"holdId("+orderid+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+classnum+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a><br></div>"
					$(".publishX").append(OrderValue)
					
			} else if ( ordertype== 1) {
				ordertype="等待老师确认"
				var OrderValue="<div class=\"publish\"><a href=\""+HTMLURL+"\"  onclick=\"holdId("+orderid+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+classnum+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a></div>"
				$(".publishX").append(OrderValue)
			} else if(ordertype== 2){
				ordertype="待支付"
				var OrderValue="<div class=\"publish\"><a href=\""+HTMLURL+"\"  onclick=\"holdId("+orderid+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+classnum+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a></div>"
				$(".publishX").append(OrderValue)
			}else if(ordertype== 3){
				ordertype="订单已完成"
				var OrderValue="<div class=\"publish\"><a href=\""+HTMLURL+"\"  onclick=\"holdId("+orderid+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+classnum+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a></div>"
				$(".publishX").append(OrderValue)
			}else if(ordertype== 4){
				ordertype="订单进行中"
				var OrderValue="<div class=\"publish\"><a href=\""+HTMLURL+"\"  onclick=\"holdId("+orderid+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+classnum+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a></div>"
				$(".publishX").append(OrderValue)
			}// }else if(ordertype== 5){
			// 	ordertype="订单待支付"
			// 	var OrderValue="<div class=\"publish\"><a href=\""+HTMLURL+"\"  onclick=\"holdId("+orderid+")\" class=\"weui-media-box weui-media-box_appmsg\"><div class=\"weui-media-box__hd need_tx\"><img src=\""+photo+"\" /></div><div class=\"weui-media-box__bd fabu_left\"><div class=\"tea_name\"><p>有人找你上课啦</p></div><div class=\"subject\"><p>总费用："+amount+"</p></div><div class=\"tea_grade\"><span>总课时："+classnum+"</span></div><div class=\"exercise\"><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ordertype+"</p></div></div></a></div>"//<a  onclick=\"xQreder("+orderid+")\" class=\"cancel_btn\">取消订单</a><a onclick=\"QJOreder("+orderid+")\" class=\"confirm_btn\">确定订单</a>
			// 	$(".publishX").append(OrderValue)
			// }
			console.log(ordertype);
	
		}
	},function(code){
		console.log(code.status);
	})
}


function holdId(Id){
	sessionStorage.removeItem("ID");
	//if (typeof(Storage) !== "undefined") {
    // 存储
	console.log(Id);
    sessionStorage.setItem("ID", Id);
	//}
	//var jsId = window.sessionStorage;
	//jsId = Id;
}

function QOreder(orderidx){
	console.log(orderidx)
	console.log(userid)
				
				Myajax("GoodTeacherOrder","GET","http://manage.woyaoxuexue.com/guns/app/teacherconfirmmingshiorder",
				{
					"userid":userid,
					"orderid":orderidx,
					"ordertype":2
				},10000,function(msg){
					var strree=msg.responseText;
					/* console.log(strree); */
					var objhh=eval("("+strree+")");
					console.log(objhh)
				},function(code){
					console.log(code.status);
				})
			
			}
			
			
			
			function xQreder(orderidx,userid){
				console.log(orderidx)
				console.log(userid)
							
							Myajax("GoodTeacherOrder","GET","http://manage.woyaoxuexue.com/guns/app/cancelteacherlteachorder",
							{
								"userid":userid,
								"orderid":orderidx,
								"ordertype":0
							},10000,function(msg){
								var strree=msg.responseText;
								/* console.log(strree); */
								var objhh=eval("("+strree+")");
								console.log(objhh)
								var code=objhh.code;
								if(code=="100000"){
									alert("取消成功")
									window.location.assign("../Mine/P_order2.html");
								}else{
									alert("出错了")
								}
							},function(code){
								console.log(code.status);
							})
						
						}
			
			
			
			
			/* function XQconfir(orderidx){
				console.log(orderidx)
				console.log(userid)
							
							Myajax("GoodTeacherOrder","GET","http://manage.woyaoxuexue.com/guns/app/teacherconfirmmingshiorder",
							{
								
								"orderid":orderidx,
								"ordertype":2
							},10000,function(msg){
								var strree=msg.responseText;
							
								var objhh=eval("("+strree+")");
								console.log(objhh)
								var code=objhh.code;
								if(code=="100000"){
									alert("已经完成")
								}else{
									alert("出错了")
								}
							},function(code){
								console.log(code.status);
							})
						
						} */
			
			
			
			function QJOreder(orderidx){
				console.log(orderidx)
				
							
							Myajax("GoodTeacherOrder","GET","http://manage.woyaoxuexue.com/guns/app/technicianconfirmjishiorder",
							{
								"orderid":orderidx,
								"ordertype":2
							},10000,function(msg){
								var strree=msg.responseText;
								/* console.log(strree); */
								var objhh=eval("("+strree+")");
								console.log(objhh)
							},function(code){
								console.log(code.status);
							})
						
						}
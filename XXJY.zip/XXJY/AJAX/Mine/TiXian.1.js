var userid;
var payaccount;
var accounttype;
var amount;
var bankname;
var payaccount;
var userid;
var username;
var TPay=document.getElementById("TPay");
var wx=document.getElementById("wx");
var zfb=document.getElementById("zfb");
var moneyTixian=document.getElementById("moneyTixian");
var accountid;
getAccountid()
function getAccountid(){
			
			//if (typeof(Storage) !== "undefined") {
		    // 存储
			accountid=sessionStorage.getItem("Accountid")
		    console.log(accountid)
			//}
			//var jsId = window.sessionStorage;
			//jsId = Id;
			
		}
wx.onclick=function(){
	window.location.assign("TiXian.html")
}
zfb.onclick=function(){
	window.location.assign("TiXian.2.html")
}
/* getUserid()
function getUserid(){
	userid=localStorage.getItem("Useridx");
	console.log(userid)
} */

Myajax("TiXian","GET","http://manage.woyaoxuexue.com/guns/app/getaccountdetail",
{
	 "accountid":accountid
},10000,function(msg){
	var strPayT=msg.responseText;
	var objT=eval("("+strPayT+")")
	console.log(objT)
	
	accounttype=objT.data.accounttype;
	console.log(accounttype)
	 bankname=objT.data.bankname;
	 userid=objT.data.userid;
	 username=objT.data.username;
	 payaccount=objT.data.payaccount;
	 console.log(bankname)
	 console.log(username)
	 console.log(payaccount)
	 var payaccountArry=payaccount.split("");
	 console.log(payaccountArry)
	 var inz=payaccountArry.length
	 if(inz>=4){
		 moneyTixian.value=bankname+payaccountArry[inz-4]+payaccountArry[inz-3]+payaccountArry[inz-2]+payaccountArry[inz-1]
	 }else if(inz>=3){
		 moneyTixian.value=bankname+payaccountArry[inz-3]+payaccountArry[inz-2]+payaccountArry[inz-1]
	 }else if(inz>=2){
		 moneyTixian.value=bankname+payaccountArry[inz-2]+payaccountArry[inz-1]
	 }else if(inz>=1){
		 moneyTixian.value=bankname+payaccountArry[inz-1]
	 }else if(inz==0){
		 moneyTixian.value=bankname
	 }
	
},function(code){
	var error=code.responseText;
	console.log(error)
})

TPay.onclick=function(){
amount=document.getElementById("accountname").value;

console.log(accounttype)
Myajax("TiXian","GET","http://manage.woyaoxuexue.com/guns/app/addcashapply",
{
	 "userid":userid,
	 "payaccount":payaccount,
	 "accounttype":accounttype,
	 "username":username,
	 "bankname":bankname,
	 "amount":amount,
},10000,function(msg){
	var strPayT=msg.responseText;
	
	
	var objT=eval("("+strPayT+")")
	console.log(objT)
	var codea=objT.code;
	console.log(codea)
	if(codea==100000){
		alert("提现金额:"+amount+"（预计在3-5个工作日到账，请耐心等待）")
	}else{
		alert("提现申请失败")
	}
},function(code){
	var error=code.responseText;
	console.log(error)
})
}

		
var id;
var listLength;
var j;
var price;
var courseid;
var gradeid;
//var teacherIDX;
var allMoney;
var userid;
var classnum;
var teacherid;
var orderid;
var ordertype;
var ssq;
var orderno;
GetorderID()
function GetorderID(){
    userid = localStorage.getItem("Userid");
// 	//id = Id;
// 	/* console.log(userid); */
// 	teacherid=localStorage.getItem("TecherId");
	orderid=sessionStorage.getItem("OrderId");
	ordertype=sessionStorage.getItem("OrderType");
	//console.log(localStorage.getItem("OrderId"));
	//console.log(localStorage.getItem("OrderType"));
	getTeacher();
}
console.log(orderid)

// getTeacherID()
// function getTeacherID(){
//     id = sessionStorage.getItem("ID");
// 	//id = Id;
// 	console.log(id);
//  			getTeacher();
// }


function getTeacher(){
	/* console.log("1"); */
	Myajax("getTeacher","GET","http://manage.woyaoxuexue.com/guns/app/getjishiorderdetail",
	{
		"page":1,
		"rows":99,
		"orderid":orderid,
	},100000,
	function(msg){
		var str=msg.responseText;
		/* console.log(str); */
		var obja=eval("("+str+")");
		console.log(obja);
		var firstname=obja.data.firstname;//昵称
		var addprovincename=obja.data.addprovincename;
		var addcityname=obja.data.addcityname;
		var addareaname=obja.data.addareaname;
		userid=obja.data.userid;
		console.log(userid)
		//console.log(firstname);
		/* var id=obja.data.id; */
		//console.log(id);
		//teacherIDX=obja.data.userid;
		//console.log(userid);
		var photo="..\\content\\img\\up_img\\tx1.jpg"
		//var photo=obja.data.list[0].headpic;//头像
		//console.log(photo);
		var sex=obja.data.sex;
		console.log(sex);
		var skillid=obja.data.skillid;
		if(skillid==1){
			skillid="种植";
		}else if(skillid==2){
			skillid="茶艺"
		}else if(skillid==3){
			skillid="维修"
		}else if(skillid==4){
			skillid="健身"
		}else if(skillid==5){
			skillid="舞蹈"
		}
		//courseid=obja.data.courseid;
		//console.log(courseid);
		//var gradeid=obja.data.gradeid;
		/* console.log(gradeid); */
		var introduction=obja.data.introduction;
		if(introduction==null)
			introduction="无";
		//console.log(introduction);
		var integrate=obja.data.integrate;
		//console.log(integrate);
		price=obja.data.price;
		/* console.log(price); */
		var teachplacetype=obja.data.teachplacetype;
		/* console.log(teachplacetype); */
		ssq=obja.data.address;
		orderno=obja.data.orderno;
		/*技能 转化 */
		var amount=obja.data.amount;
		var timeNum=obja.data.totaltime;
		var classnum=obja.data.classnum;
		//var time;
		
		
// 		for(var i=0;i<timeNum;i++){
// 			if(i==0){
// 				time="星期"+obja.data.list[0].timelist[i].week+"&nbsp,&nbsp"+obja.data.list[0].timelist[i].starttime+"->"+obja.data.list[0].timelist[i].endtime;
// 			}
// 			else{
// 				time=time+"</br>星期"+obja.data.list[0].timelist[i].week+"&nbsp,&nbsp"+obja.data.list[0].timelist[i].starttime+"->"+obja.data.list[0].timelist[i].endtime;
// 			}
// 		}
		var button="<a><button onclick=\"\" type=\"button\" disable=\"true\">订单已完成</button></a>";
		if(ordertype==5){
			button="<a><button onclick=\"ConfirmPay()\" type=\"button\">支付</button></a>";
		}
		else if(ordertype==4){
			button="<a><button onclick=\"userQueRen()\" type=\"button\">确认完成</button></a>";
		}
		else if(ordertype==3){
			button="<a><button onclick=\"\" type=\"button\">订单已完成</button></a>";
		}
		else if(ordertype==2){
			button="<a><button onclick=\"\" type=\"button\">等待老师确认</button><\br><button onclick=\"Xfinish()\" type=\"button\">取消订单</button></a>";
		}else if(ordertype==0){
			var button="<a><button onclick=\"\" type=\"button\" disable=\"true\">订单已取消</button></a>";
		}else if(ordertype==1){
			var button="<a><button onclick=\"\" type=\"button\" disable=\"true\">订单已发布</button></a>";
		}
		
// 		if(courseid=="1"){
// 			courseid="语文";
// 		}else if(courseid=="2"){
// 			courseid="数学"
// 		}else if(courseid=="3"){
// 			courseid="英语"
// 		}else if(courseid=="4"){
// 			courseid="物理"
// 		}else if(courseid=="5"){
// 			courseid="化学"
// 		}else if(courseid=="6"){
// 			courseid="生物"
// 		}else if(courseid=="7"){
// 			courseid="历史"
// 		}else if(courseid=="8"){
// 			courseid="地理"
// 		}else if(courseid=="9"){
// 			courseid="政治"
// 		}
		//console.log(skillid)
		/* 性别转换 */
		
			if(sex=="1"){
			sex="男";
		}else if(sex=="2"){
			sex="女";
		}else{
			sex="出错了";
		}
		//console.log(sex)
		/* 上课方式转换 */		
			
		if(teachplacetype=="0"){
			teachplacetype="请老师上门";
		}else if(teachplacetype=="1"){
			teachplacetype="到老师指定地点";
		}
		/* 年级转换 */
// 		if(gradeid=="1"){
// 			gradeid="小学";
// 		}else if(gradeid=="2"){
// 			gradeid="初中";
// 		}else if(gradeid=="3"){
// 			gradeid="高中";
// 		}else{
// 			gradeid="出错了";
// 		}
		/* var allmenoy;
		
		var ClassTime=document.getElementsByClassName("ClassTime");
			ClassTime.onmouseleave=function(){
			allmenoy=ClassTime.value*price;
			} */
			var photo=obja.data.photo;
			//<ul><li>计划课时安排</li><p>"+time+"</p><li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li id=\"change\">总价:"+amount+"</li></ul>
			var mark=obja.data.mark;
			var markImg;
			if(mark=="1"){
				markImg="content/img/up_img/pingfen1.jpg";
			}else if(mark=="2"){
				markImg="content/img/up_img/pingfen2.jpg";
			}else if(mark=="3"){
				markImg="content/img/up_img/pingfen3.jpg";
			}else if(mark=="4"){
				markImg="content/img/up_img/pingfen4.jpg";
			}else if(mark=="5"){
				markImg="content/img/up_img/pingfen5.jpg";
			}
			var useridChat=obja.data.technicianid;
		var mainChilder="<h4>教师简介</h4><p>"+introduction+"</p><ul><li>综合评价</li><img src=\""+markImg+"\"><li>授课经验:"+integrate+"课时</li><li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+classnum+"课时</li><li id=\"change\">总价:"+amount+"元</li></ul>"+button+"";
		var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>科目：</li><span>"+skillid+"</span><br><li>授课方式：</li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form class=\"form1\"><img  src=\""+photo+"\"></form></div><a onclick=\"ONUrl()\"><button onclick=\"setTouserid("+useridChat+",\'"+firstname+","+photo+"\')\" type=\"button\"><img src=\"content/img/fixed_img/在线联系.jpg\" ></button></a><br>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" class=\"ssq\" >&nbsp&nbsp&nbsp&nbsp"+addprovincename+"&nbsp"+addcityname+"&nbsp"+addareaname+"&nbsp"+ssq+"</a>";
		$(".banner").append(bannerChildren)
		$(".main").append(mainChilder);
	},function(code){
		console.log(code.status);
	}
	);
};
function money(){
	//console.log("333");
	classnum=demo.value;
	//console.log(ClassTime.demo.value);
	allMoney=demo.value*price;
	if(allMoney<0){
		allMoney=0;
	}
	$("#change").text("总价:"+allMoney+"元");	
}


function addCollect(){
	Myajax("collectionuserid","GET","http://manage.woyaoxuexue.com/guns/app/addcollection",
	{
		"collectionuserid":teacherIDX,
		"userid":userid,
		"usertype":1
	},100000,function(msg){
		var str=msg.responseText;
		var objb=eval("("+str+")");
		console.log(objb);
		console.log(userid)
		var msgoo=objb.msg;
		var codeoo=objb.code;
		if(codeoo=="100000"){
		alert("收藏成功");
		window.location.assign("../Mine/P_collect.html")
		}else if(msgoo=="已添加当前数据，请勿重复添加"){
			alert(msgoo);
		}
	},function(code){
		console.log(code.status);
	})
}


function ConfirmPay(){
	
	
	var strPay;
			var DivPay=document.getElementById("PAYjs");
		console.log(orderno)
			Myajax("PAY","GET","http://manage.woyaoxuexue.com/guns/app/payorder",
			{
				"orderno":orderno,
				"returnUrl":"http://www.woyaoxuexue.com/Mine/P_order5.html"
			},10000,function(msg){
				strPay=msg.responseText;
				console.log(strPay)
				
				
			$("#PAYjs").append(strPay)
			
			},function(code){
				
			})	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}




function finish(){
	Myajax("finish","GET","http://manage.woyaoxuexue.com/guns/app/userconfirmjishiorder",
	{
		"orderid":orderid,
	},10000,function(msg){
		var strr=msg.responseText;
		/* console.log(strr) */
		var objr=eval("("+strr+")")
		 console.log(objr) 
		 var msgpay=objr.msg;
		 var codepay=objr.code;
		 if(msgpay=="添加用户名师需求失败"){
			 alert(msgpay)
		 }else if(codepay=="100000"){
			 alert("支付成功");
			 window.location.assign("../Mine/P_order5.html");
		 }
		 
		 
	},function(code){
		console.log(code.status)
	})
}


console.log(userid)
function userQueRen(){
	Myajax("finish","GET","http://manage.woyaoxuexue.com/guns/app/userconfirmjishiorder",
	{
		"orderid":orderid,
		"userid":userid
	},10000,function(msg){
		var strr=msg.responseText;
		/* console.log(strr) */
		var objr=eval("("+strr+")")
		 console.log(objr) 
		 console.log(orderid) 
		 var msgpay=objr.msg;
		 var codepay=objr.code;
		 if(msgpay=="添加用户名师需求失败"){
			 alert(msgpay)
		 }else if(codepay=="100000"){
			 alert("订单完成");
			 window.location.assign("../Mine/P_order5.html");
		 }
		 
		 
	},function(code){
		console.log(code.status)
	})
}


function Xfinish(){
	Myajax("finish","GET","http://manage.woyaoxuexue.com/guns/app/technicianconfirmjishiorder",
	{
		"orderid":orderid,
		"ordertype":0
	},10000,function(msg){
		var strr=msg.responseText;
		/* console.log(strr) */
		var objr=eval("("+strr+")")
		 console.log(objr) 
		 console.log(orderid) 
		 var msgpay=objr.msg;
		 var codepay=objr.code;
		 if(msgpay=="添加用户名师需求失败"){
			 alert(msgpay)
		 }else if(codepay=="100000"){
			 alert("取消成功");
			 window.location.assign("../Mine/P_order5.html");
		 }
		 
		 
	},function(code){
		console.log(code.status)
	})
}


function ONUrl(){
	if(getCookie("userid","/")){
	 		 window.location.assign("../Index/xiaoxi.html");
	}else{
	 		 window.location.assign("../Mine/login.1.html")
	}
}
function setTouserid(touserid,name,photo){
	sessionStorage.removeItem("Touserid");
	sessionStorage.removeItem("Name");
	sessionStorage.removeItem("Photo");
	sessionStorage.setItem("Touserid", touserid);
	sessionStorage.setItem("Name", name);
	sessionStorage.setItem("Photo", photo);
	//}
	}
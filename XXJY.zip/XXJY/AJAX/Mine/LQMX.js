var teacherid;
var technicianid;
getUserid()
function getUserid(){
	teacherid=localStorage.getItem("TecherId");
	technicianid=localStorage.getItem("TechnicianId");
}

if("undefined"==technicianid){
Myajax("LQMX","GET","http://manage.woyaoxuexue.com/guns/app/getbalancechangelist",
{
	"teacherid":teacherid
},10000,function(msg){
	var MXstr=msg.responseText;
	var MXobj=eval("("+MXstr+")");
	console.log(MXobj)
	var dataLeng=MXobj.data.length;
	for(var i=0 ;i <dataLeng;i++){
	var changebalance=MXobj.data[i].changebalance
	console.log(changebalance);
	var changedate=MXobj.data[i].changedate
	console.log(changedate);
	var content=MXobj.data[i].content
	console.log(content);
	var content=content.split("：");
	console.log(content[0]);
	
		
	
	var HTMLmx="<ul><li>"+content[0]+"<span class=\"moneMX\">"+changebalance+"</span></li><li>"+changedate+"</li><hr ></ul>"
	if(changebalance){
	$(".LQ").append(HTMLmx);
	}
	}
	
	
},function(code){
	
})
}else{

Myajax("LQMX","GET","http://manage.woyaoxuexue.com/guns/app/getbalancechangelist",
{
	"technicianid":technicianid
},10000,function(msg){
	var MXstr=msg.responseText;
	var MXobj=eval("("+MXstr+")");
	console.log(MXobj)
	var dataLeng=MXobj.data.length;
	for(var i=0 ;i <dataLeng;i++){
	var changebalance=MXobj.data[i].changebalance
	console.log(changebalance);
	if(!changebalance){
		changebalance=0;
	}
	var changedate=MXobj.data[i].changedate
	console.log(changedate);
	var content=MXobj.data[i].content
	console.log(content);
	var content=content.split("：");
	console.log(content[0]);
	var HTMLmx="<ul><li>"+content[0]+"<span class=\"moneMX\">"+changebalance+"</span></li><li>"+changedate+"</li><hr ></ul>"
	$(".LQ").append(HTMLmx);
}
},function(code){
	
})
}
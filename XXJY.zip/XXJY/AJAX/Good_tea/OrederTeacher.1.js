var id;
var listLength;
var j;
var price;
var courseid;
var gradeid;
var userid;
var teacherIDX;
var allMoney;
var classnum;
var orderid;
var teacherid;
GetuserID()
function GetuserID(){
    userid = localStorage.getItem("Userid");
	//id = Id;
	/* console.log(userid); */
	teacherid=localStorage.getItem("TecherId");
}
getTeacherOrederID()
function getTeacherOrederID(){
    orderid = sessionStorage.getItem("ID");
	//id = Id;
	console.log(orderid);
 			getTeacherOreder();
}


function getTeacherOreder(){
	/* console.log("1"); */
	Myajax("getTeacher","GET","http://manage.woyaoxuexue.com/guns/app/getteachorderlist",
	{
		"page":1,
		"rows":9999,
		"orderid":orderid
	},100000,
	function(msg){
		var str=msg.responseText;
		/* console.log(str); */
		var obja=eval("("+str+")");
		console.log(obja);
		
		
		
		
		var firstname=obja.data.list[0].nickname;
		//console.log(firstname);
		/* var id=obja.data.id; */
		//console.log(id);
		teacherIDX=obja.data.list[0].userid;
		//console.log(userid);
		var addareaname=obja.data.list[0].addareaname;
		var addprovincename=obja.data.list[0].addprovincename;
		var addcityname=obja.data.list[0].addcityname;
		var address=obja.data.list[0].address;
		var headpic=obja.data.list[0].headpic;
		//console.log(photo);
		var sex=obja.data.list[0].teachersex;
		console.log(sex);
		courseid=obja.data.list[0].courseid;
		//console.log(courseid);
		var gradeid=obja.data.list[0].gradeid;
		/* console.log(gradeid); */
		var introduction=obja.data.list[0].introduction;
		//console.log(introduction);
		var integrate=obja.data.list[0].totaltime;
		//console.log(integrate);
		price=obja.data.list[0].price;
		var amount=obja.data.list[0].amount;
		teacherid=obja.data.list[0].teacherid;
		/* console.log(price); */
		var teachplacetype=obja.data.list[0].teachplacetype;
		/* console.log(teachplacetype); */
		var ordertype=obja.data.list[0].ordertype;
		/*技能 转化 */
		
	if(courseid=="1"){
		courseid="语文";
	}else if(courseid=="2"){
		courseid="数学"
	}else if(courseid=="3"){
		courseid="英语"
	}else if(courseid=="4"){
		courseid="物理"
	}else if(courseid=="5"){
		courseid="化学"
	}else if(courseid=="6"){
		courseid="生物"
	}else if(courseid=="7"){
		courseid="历史"
	}else if(courseid=="8"){
		courseid="地理"
	}else if(courseid=="9"){
		courseid="政治"
	}else if(courseid=="10"){
		courseid="科学"
	}else if(courseid=="11"){
		courseid="音乐"
	}else if(courseid=="12"){
		courseid="美术"
	}else if(courseid=="13"){
		courseid="体育"
	}else if(courseid=="14"){
		courseid="信息"
	}
		//console.log(skillid)
		/* 性别转换 */
		
			if(sex=="1"){
			sex="男";
		}else if(sex=="2"){
			sex="女";
		}else{
			sex="出错了";
		}
		//console.log(sex)
		/* 上课方式转换 */		
			
		if(teachplacetype=="0"){
			teachplacetype="请老师上门";
		}else if(teachplacetype=="1"){
			teachplacetype="到老师指定地点";
		}
		/* 年级转换 */
		if(gradeid=="1"){
			gradeid="小学";
		}else if(gradeid=="2"){
			gradeid="初中";
		}else if(gradeid=="3"){
			gradeid="高中";
		}else{
			gradeid="出错了";
		}
		if ( ordertype== 0) {
			ordertype="订单已取消"
		var mainChilder="<ul><li>备注:</li>"+introduction+"<li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+integrate+"课时</li><li id=\"change\">总价:"+amount+"元</li></ul>";
		var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>科目：</li><span>"+courseid+"</span><li>学段：</li><span>"+gradeid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form class=\"form1\"><img  src=\""+headpic+"\"></form></div><a ><button type=\"button\"><img src=\"content/img/fixed_img/在线联系.png\" >在线联系</button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+""+addcityname+""+addareaname+""+address+"</span></a></p>";
		$(".banner").append(bannerChildren)
		$(".main").append(mainChilder);
		} else if ( ordertype== 1) {
			ordertype="订单已发布"
			var mainChilder="<ul><li>备注:</li>"+introduction+"<li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+integrate+"课时</li><li id=\"change\">总价:"+amount+"元</li></ul><br><a><button onclick=\"cellPay()\" type=\"button\">取消订单</button></a>";
			var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>科目：</li><span>"+courseid+"</span><li>学段：</li><span>"+gradeid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form class=\"form1\"><img  src=\""+headpic+"\"></form></div><a ><button type=\"button\"><img src=\"content/img/fixed_img/在线联系.png\" >在线联系</button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+""+addcityname+""+addareaname+""+address+"</span></a></p>";
			$(".banner").append(bannerChildren)
			$(".main").append(mainChilder);
		} else if(ordertype== 2){
			ordertype="订单已领取"
			var mainChilder="<ul><li>备注:</li>"+introduction+"<li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+integrate+"课时</li><li id=\"change\">总价:"+amount+"元</li></ul><br><a><button onclick=\"cellPay()\" type=\"button\">取消订单</button></a>";
			var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>科目：</li><span>"+courseid+"</span><li>学段：</li><span>"+gradeid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form class=\"form1\"><img  src=\""+headpic+"\"></form></div><a ><button type=\"button\"><img src=\"content/img/fixed_img/在线联系.png\" >在线联系</button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+""+addcityname+""+addareaname+""+address+"</span></a></p>";
			$(".banner").append(bannerChildren)
			$(".main").append(mainChilder);
		}else if(ordertype== 3){
			ordertype="订单已完成"
			var mainChilder="<ul><li>备注:</li>"+introduction+"<li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+integrate+"课时</li><li id=\"change\">总价:"+amount+"元</li></ul>";
			var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>科目：</li><span>"+courseid+"</span><li>学段：</li><span>"+gradeid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form class=\"form1\"><img  src=\""+headpic+"\"></form></div><a><button type=\"button\"><img src=\"content/img/fixed_img/在线联系.png\" >在线联系</button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+""+addcityname+""+addareaname+""+address+"</span></a></p>";
			$(".banner").append(bannerChildren)
			$(".main").append(mainChilder);
		}else if(ordertype== 4){
			ordertype="订单进行中"
			var mainChilder="<ul><li>备注:</li>"+introduction+"<li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+integrate+"课时</li><li id=\"change\">总价:"+amount+"元</li></ul><br><a><button onclick=\"cellPay()\" type=\"button\">取消订单</button></a>";
			var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>科目：</li><span>"+courseid+"</span><li>学段：</li><span>"+gradeid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form class=\"form1\"><img  src=\""+headpic+"\"></form></div><a ><button type=\"button\"><img src=\"content/img/fixed_img/在线联系.png\" >在线联系</button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+""+addcityname+""+addareaname+""+address+"</span></a></p>";
			$(".banner").append(bannerChildren)
			$(".main").append(mainChilder);
		}else if(ordertype== 5){
			ordertype="订单待支付"
		var mainChilder="<ul><li>备注:</li>"+introduction+"<li>课时单价:<span>"+price+"</span>元/课时（小时）</li><li>课时数:"+integrate+"课时</li><li id=\"change\">总价:"+amount+"元</li></ul><br><a><button onclick=\"cellPay()\" type=\"button\">取消订单</button></a>";
		var bannerChildren="<h4>基本信息</h4><ul><li>姓名：</li><span>"+firstname+"</span><li>性别：</li><span>"+sex+"</span><li>科目：</li><span>"+courseid+"</span><li>学段：</li><span>"+gradeid+"</span><li>授课方式：</li><span>"+teachplacetype+"</span></ul><div class=\"headerKuang\"><form class=\"form1\"><img  src=\""+headpic+"\"></form></div><a ><button type=\"button\"><img src=\"content/img/fixed_img/在线联系.png\" >在线联系</button></a><p>授课地点:<a ><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+addprovincename+""+addcityname+""+addareaname+""+address+"</span></a></p>";
		$(".banner").append(bannerChildren)
		$(".main").append(mainChilder);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/* var allmenoy;
		
		
		
		
		
		
		
		
		var ClassTime=document.getElementsByClassName("ClassTime");
			ClassTime.onmouseleave=function(){
			allmenoy=ClassTime.value*price;
			} */
		
			
	},function(code){
		console.log(code.status);
	}
	);
};


function cellPay(){
	if(courseid=="语文"){
		courseid="1";
	}else if(courseid=="数学"){
		courseid="2"
	}else if(courseid=="英语"){
		courseid="3"
	}else if(courseid=="物理"){
		courseid="4"
	}else if(courseid=="化学"){
		courseid="5"
	}else if(courseid=="生物"){
		courseid="6"
	}else if(courseid=="历史"){
		courseid="7"
	}else if(courseid=="地理"){
		courseid="8"
	}else if(courseid=="政治"){
		courseid="9"
	}
	Myajax("cellPay","GET","http://manage.woyaoxuexue.com/guns/app/cancelteacherlteachorder",
	{
		"userid":teacherIDX,
		"orderid":orderid
	},10000,function(msg){
		var strr=msg.responseText;
		/* console.log(strr) */
		var objr=eval("("+strr+")")
		 console.log(objr) 
		 var msgpay=objr.msg;
		 console.log(teacherIDX)
		 var codepay=objr.code;
		 if(msgpay=="添加用户名师需求失败"){
			 alert(msgpay)
		 }else if(codepay=="100000"){
			 alert("取消成功");
			 window.location.assign("../Mine/P_order2.html");
			 
		 }
		 
		 
	},function(code){
		console.log(code.status)
	})
}
  $("#MineUrl").click(function(){
	 if(getCookie("userid","/")){
		 window.location.assign("../Mine/P_center2.html");
	 }else{
		 window.location.assign("../Mine/login.1.html")
	 }
 })
 
 
 $("#ChatUrl").click(function(){
 	 if(getCookie("userid","/")){
 		 window.location.assign("../Index/chat.html");
 	 }else{
 		 window.location.assign("../Mine/login.1.html")
 	 }
 })
 
 $("#IndexUrl").click(function(){
 	 if(getCookie("userid","/")){
 		 window.location.assign("../Index/index.html");
 	 }else{
 		 window.location.assign("../index.html")
 	 }
 })
 
 
 $("#demanUrl").click(function(){
 	 if(getCookie("userid","/")){
 		 window.location.assign("../Index/demand.html");
 	 }else{
 		 window.location.assign("../Mine/login.1.html")
 	 }
 })
 
 $("#JoinUrl").click(function(){
 	 if(getCookie("userid","/")){
 		 window.location.assign("../Join/jion.html");
 	 }else{
 		 window.location.assign("../Mine/login.1.html")
 	 }
 })
 
 
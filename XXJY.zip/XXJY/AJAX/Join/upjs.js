		var userid;
		var technicianid;
		var imageurla;
		var imageurlb;
		var imageurlc;
		var imageurld;
		var addprovincenameValue;
		var addprovinceList;
		var addprovincecode;
		var addcitynameValue;
		var addcityList;
		var addcitycode;
		var parentidv;
		var parentid;
		var parentide;
		var parentidvh;
		var parentidh;
		var parentideh;
		var addareanameValue;
		var addareaList;
		var addareacode;
		
		var addprovincenameINNHTML;
		var addprovincename = document.getElementById("addprovincename");
		var ProvinceIDName=document.getElementsByClassName("ProvinceIDName")
		var addareaname = document.getElementById("addareaname")
		GETUERID()
		function GETUERID(){
		    userid = localStorage.getItem("Userid");
		};
		/* 省份地址 */
		getaddressProvince()
		function getaddressProvince() {
		Myajax("getaddressProvince","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
		{
			"parentid":100000,
			"leveltype":1,
		},100000,function(msg){
			var strq=msg.responseText;
			/* console.log(str); */
			var objc=eval("("+strq+")");
			/* console.log(objc); */
			addprovinceList=objc.data.length;
			for(var j=0;j<addprovinceList;j++){
			addprovincenameValue=objc.data[j].name;
			addprovincecode=objc.data[j].id
		/* console.log(addprovincecode); */
			/* console.log(addprovincenameValue); */
           addprovincenameINNHTML= "<option value=\""+addprovincecode+"\" class=\"ProvinceIDName\" >"+addprovincenameValue+"</option>";
			$("#addprovincename").append(addprovincenameINNHTML);
			/* console.log(ProvinceIDName[j].value) */
			}
			$("#addprovincename").change(function(){
		$("#addcityname").empty()
		parentid=$("#addprovincename").find("option:selected").val()
		parentidh=$("#addprovincename").find("option:selected").text()
		/* console.log(parentidh) */
			/* console.log(parentid) */
		GETaddcityname();
		
			})
		},function(code){
			console.log(code.status);
		})
		};
	
		/* 城市 */	
		
		function GETaddcityname(){
			Myajax("getaddCITYress","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
			{
				"parentid":parentid,
				"leveltype":2,
			},100000,function(msg){
				var strq=msg.responseText;
				// console.log(str);
				var objd=eval("("+strq+")");
				/* console.log(objd); */                                                    
				addcityList=objd.data.length;
				for(var j=0;j<addcityList;j++){
				addcitynameValue=objd.data[j].name;
				addcitycode=objd.data[j].id
		addcitynameINNHTML= "<option value=\""+addcitycode+"\">"+addcitynameValue+"</option>";
					$("#addcityname").append(addcitynameINNHTML);
				}
				parentidv=$("#addcityname").find("option:selected").val()
				parentidvh=$("#addcityname").find("option:selected").text()
				GETaddarea();
				$("#addareaname").empty();
				/* console.log(parentidvh) */
				$("#addcityname").change(function(){
				$("#addareaname").empty()
				parentidv=$("#addcityname").find("option:selected").val()
				parentidvh=$("#addcityname").find("option:selected").text()
				/* console.log(parentidvh) */
				GETaddarea();
				
					})
				
			},function(code){
				console.log(code.status);
			})
		}
		/* 地区 */
		function GETaddarea(){
			Myajax("getaddAREAress","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
			{
				"parentid":parentidv,
				"leveltype":3,
			},100000,function(msg){
				var stre=msg.responseText;
				// console.log(str);
				var obje=eval("("+stre+")");
				/* console.log(obje); */
				 /* console.log(str); */
				addareaList=obje.data.length;
				for(var j=0;j<addareaList;j++){
				addareanameValue=obje.data[j].name;
				addareacode=obje.data[j].id
		addareanameINNHTML= "<option value=\""+addareacode+"\">"+addareanameValue+"</option>";
					$("#addareaname").append(addareanameINNHTML);
				}
				parentide=$("#addareaname").find("option:selected").val()
				parentideh=$("#addareaname").find("option:selected").text()
				/* console.log(parentideh) */
				
				$("#addareaname").change(function(){
				parentide=$("#addareaname").find("option:selected").val()
				parentideh=$("#addareaname").find("option:selected").text()
				/* console.log(parentideh) */
				})
			},function(code){
				console.log(code.status);
			})
		}
		
			 
		  
		 
	//jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj
	
	
	Myajax("zhiye","GET","http://manage.woyaoxuexue.com/guns/app/gettechnicianinfo",
			{
				"userid":userid
			},100000,function(msg){
					console.log(userid)
			var str=msg.responseText;
			// console.log(str)
			var obj=eval("("+str+")")
			console.log(obj)
			
			addareacode=obj.data.addareacode;
			
			addareaname=obj.data.addareaname;
			addcitycode=obj.data.addcitycode;
			addcityname=obj.data.addcityname;
			addprovincecode=obj.data.addprovincecode;
			addprovincename=obj.data.addprovincename;
			addressa=obj.data.address;
			cardid=obj.data.cardid;
			cardnega=obj.data.cardneg;
			cardposa=obj.data.cardpos;
			company=obj.data.company;
			skillid=obj.data.skillid;
			firstname=obj.data.firstname;
			gradeid=obj.data.gradeid;
			introduction=obj.data.introduction;
			phone=obj.data.phone;
			photoa=obj.data.photo;
			price=obj.data.price;
			qualificationa=obj.data.qualification;
			secondname=obj.data.secondname;
			sex=obj.data.sex;
			teacherid=obj.data.teacherid;
			teachplacetype=obj.data.teachplacetype;
			title=obj.data.title;
			
			
			
			if(skillid==1){
				skillid="种植";
			}else if(skillid==2){
				skillid="茶艺"
			}else if(skillid==3){
				skillid="维修"	
			}else if(skillid==4){
				skillid="健身"
			}else if(skillid==5){
				skillid="舞蹈"
			}
			
			
			$("#firstname").val(firstname)
			$("#secondname").val(secondname)
			$("#cardid").val(cardid)
			$("#picp").attr('src',cardposa);
			$("#picn").attr('src',cardnega);
			
			var gender=document.getElementsByName("tea_sex");
			
			
			
			$("#xueke_pick").val(skillid)
			$("#price").val(price)
			if(title=='1'){
				title="三级";
			}else if(title=='2'){
				title="二级";
			}else if(title=='3'){
				title="一级";
			}else if(title=='4'){
				title="高级";
			}else if(title=='5'){
				title="正高级";
			}else{
				title="0";
			}
			$("#zhicheng_pick").val(title)
			$("#danwei_pick").val(company)
			
			// console.log(placetype[0].checked)
			// console.log(placetype[1].checked)
			// console.log(placetype[1].checked)
			
			
			
			var addressss=document.getElementsByClassName("addressss")[0];
			var ButtonZ=document.getElementsByClassName("ButtonZ");
			if(teachplacetype=="0"){
				ButtonZ[0].checked=true
				var address=document.getElementById("address");
				ButtonZ[0].style.backgroundColor="#1dacfa";
				ButtonZ[0].checked=true;
				ButtonZ[1].style.backgroundColor="#ffffff"
				ButtonZ[1].checked=false;
				ButtonZ[2].style.backgroundColor="#FFFFFF"
				ButtonZ[2].checked=false;
				address.removeAttribute("disabled")
				addressss.style.display="block";
				address.value="";
				// address.setAttribute("placeholder",'请输入详细的地址')
				address.style.backgroundColor="white";
				address.style.color="black";
			}else if(teachplacetype=='1'){
				
				ButtonZ[1].checked=true
				var address=document.getElementById("address");
					ButtonZ[1].style.backgroundColor="#1dacfa";
					ButtonZ[1].checked=true;
					ButtonZ[0].style.backgroundColor="#FFFFFF"
					ButtonZ[0].checked=false;
					ButtonZ[2].style.backgroundColor="#FFFFFF"
					ButtonZ[2].checked=false;
					address.value='';
					address.setAttribute("disabled","disabled")
					address.style.backgroundColor="slategray";
					address.style.color="white";
					addressss.style.display="none";
				
			}else if(teachplacetype=='2'){
				ButtonZ[2].checked=true;
				var address=document.getElementById("address");
					ButtonZ[1].style.backgroundColor="#FFFFFF";
					ButtonZ[1].checked=false;
					ButtonZ[0].style.backgroundColor="#FFFFFF"
					ButtonZ[0].checked=false;
					ButtonZ[2].style.backgroundColor="#1dacfa"
					ButtonZ[2].checked=true;
				address.value='';
				address.setAttribute("disabled","disabled")
				address.style.backgroundColor="slategray";
				address.style.color="white";
				addressss.style.display="none";
			}
			// 	parentid=$("addprovincename").val()
			// 	parentidh=$("addprovincename").text()
			// 	parentidv=$("addcityname").val()
			// 	parentidvh=$("addcityname").text()
			// 	parentide=$("addareaname").val()
			// 	parentideh=$("addareaname").text()
				
			
		  parentidh=$("#addprovincename").find("option:selected").text(addprovincename)
		  parentidh=$(parentidh).text()
			parentidvh=$("#addcityname").find("option:selected").text(addcityname)
			parentidvh=$(parentidvh).text()
			parentideh=$("#addareaname").find("option:selected").text(addareaname)
			parentideh=$(parentideh).text()
			
			parentid=$("#addprovincename").find("option:selected").val(addprovincecode)
			parentid=$(parentid).val()
			parentidv=$("#addcityname").find("option:selected").val(addcitycode)
			parentidv=$(parentidv).val()
			parentide=$("#addareaname").find("option:selected").val(addareacode)
			parentide=$(parentide).val()
			// console.log(parentideh)
			$("#address").val(addressa)
			$("#phone").val(phone)
			
			
			$("#picx").attr('src',photoa);
			$("#pixs").attr('src',qualificationa);
			
			
			$("#introduction").val(introduction)
		
		
		var gender=document.getElementsByName("tea_sex");
		
		if(sex==1){
			// console.log(1111)
			gender[0].checked=true;
		}else if(sex==2){
			gender[1].checked=true;
			// console.log(122111)
		}
		
		
		
			},function(code){
				console.log(code.status);
			})
			
	
	
	
	
	
	
			
	var confirm=document.getElementById("confirm");
			confirm.onclick=function(){
				/* console.log(userid); */
			var firstname=document.getElementById("firstname").value;
			/* console.log(firstname); */
			var cardpos=document.getElementById("uploadp").files[0];
			var secondname=document.getElementById("secondname").value;
			var cardid=document.getElementById("cardid").value;
		
			
			var cardneg=document.getElementById("uploadn").files[0];
			
		
			
			
			var gender=document.getElementsByName("tea_sex");
			var sex;
			if(gender[0].checked){
				sex="1";
			}else{
				sex="2";
			}
			var skillid=document.getElementById("xueke_pick").value;
			if(skillid=='种植'){
				skillid="1";
			}else if(skillid=='茶艺'){
				skillid="2";
			}else if(skillid=='维修'){
				skillid="3";
			}else if(skillid=='健身'){
				skillid="4";
			}else if(skillid=='舞蹈'){
				skillid="5";
			}else{
				skillid="0";
			}
			var price=document.getElementById("price").value;
			var title=document.getElementById("zhicheng_pick").value;
				if(title=='三级'){
					title="1";
				}else if(title=='二级'){
					title="2";
				}else if(title=='一级'){
					title="3";
				}else if(title=='高级'){
					title="4";
				}else if(title=='正高级'){
					title="5";
				}else{
					title="0";
				}
			var company=document.getElementById("danwei_pick").value;
			var placetype=document.getElementsByName("place");
			var address=document.getElementById("address").value;
			var teachplacetype;
			if(placetype[0].checked){
				teachplacetype="0";
			}else if(placetype[1].checked){
				teachplacetype="1";
			}else if(placetype[2].checked){
				teachplacetype="2";
			}else{
				teachplacetype=" ";
			}
			var phone=document.getElementById("phone").value;
			
			
			var photo=document.getElementById("uploadx").files[0];
			var shenhe=document.getElementById("uploadxs").files[0];
			var introduction=document.getElementById("introduction").value;
			/* console.log(cardpos) url("blob:http://127.0.0.1:8848/7b774dad-03ad-4f68-8836-54a40e4ec527") */
			/* console.log(cardneg) url("blob:http://127.0.0.1:8848/0537a241-bfe4-4aef-bf53-8e4fcc7b9adf") */
			
			
			
			
			imageurla=document.getElementById("picp").src;
			 imageurla=document.getElementById("picx").src;
			 imageurla=imageurla.split("http://manage.woyaoxuexue.com/guns/kaptcha/");
			 imageurla=imageurla.pop();
			 console.log(imageurla)
			 imageurlb=document.getElementById("picn").src;
			 imageurlb=imageurlb.split("http://manage.woyaoxuexue.com/guns/kaptcha/");
			 imageurlb=imageurlb.pop();
			 console.log(imageurlb)
			 imageurlc=document.getElementById("picx").src;
			 imageurlc=imageurlc.split("http://manage.woyaoxuexue.com/guns/kaptcha/");
			 imageurlc=imageurlc.pop();
			 console.log(imageurlc)
			 imageurld=document.getElementById("pixs").src;
			imageurld=imageurld.split("http://manage.woyaoxuexue.com/guns/kaptcha/");
			imageurld=imageurld.pop();
			console.log(imageurlc)
		
		
		
		// parentid=$("addprovincename").val(addprovincecode)
		// parentidh=$("addprovincename").text(addprovincename)
		// parentidv=$("addcityname").val(addcitycode)
		// parentidvh=$("addcityname").text(addcityname)
		// parentide=$("addareaname").val(addareacode)
		// parentideh=$("addareaname").text(addareaname)
		
		
		// $("#addprovincename").find("option:selected").text(addprovincename)
		// $("#addcityname").find("option:selected").text(addcityname)
		// $("#addareaname").find("option:selected").text(addareaname)
		// $("#address").val(addressa)
		
		// 	parentid=$("addprovincename").val()
		// 	parentidh=$("addprovincename").text()
		// 	parentidv=$("addcityname").val()
		// 	parentidvh=$("addcityname").text()
		// 	parentide=$("addareaname").val()
		// 	parentideh=$("addareaname").text()
			
			
		// 	console.log(addcityname)
		// 	console.log(addareacode)
			/* headpicX=document.getElementById("upload").files[0]; */
			console.log(Boolean(cardpos))
			// console.log(cardpos)
			if(cardpos){
			var formDataa = new FormData();
			formDataa.append('image', cardpos);
			$.ajax({
					async:false,//同步，异步
					url:"http://manage.woyaoxuexue.com/guns/app/uploadImg", //请求的服务端地址
					type:"post",
					data:formDataa,
			                contentType: false,
			                processData: false,
			                mimeType: "multipart/form-data",
			                success: function (msg) {
			                  
							console.log(msg)
							imageurla=msg.data.imgurl;
							console.log(imageurla)
							
			                },
			                error: function (data) {
			                    console.log(data);
			                }
			            });
							}
						if(cardneg){
						var formDatab = new FormData();
						formDatab.append('image', cardneg);
						$.ajax({
								async:false,//同步，异步
								url:"http://manage.woyaoxuexue.com/guns/app/uploadImg", //请求的服务端地址
								type:"post",
								data:formDatab,
						                contentType: false,
						                processData: false,
						                mimeType: "multipart/form-data",
						                success: function (msg) {
						                  
										console.log(msg)
										imageurlb=msg.data.imgurl;
										console.log(imageurlb)
										
						                },
						                error: function (data) {
						                    console.log(data);
						                }
						            });
									
									}									
									
									if(photo){
										
								
									
									var formDatac = new FormData();
									formDatac.append('image', photo);
									$.ajax({
											async:false,//同步，异步
											url:"http://manage.woyaoxuexue.com/guns/app/uploadImg", //请求的服务端地址
											type:"post",
											data:formDatac,
									                contentType: false,
									                processData: false,
									                mimeType: "multipart/form-data",
									                success: function (msg) {
									                  
													console.log(msg)
													imageurlc=msg.data.imgurl;
													console.log(imageurlc)
													
									                },
									                error: function (data) {
									                    console.log(data);
									                }
									            });
													}
					
					if(shenhe){
			var formDatad = new FormData();
			formDatad.append('image', shenhe);
			$.ajax({
					async:false,//同步，异步
					url:"http://manage.woyaoxuexue.com/guns/app/uploadImg", //请求的服务端地址
					type:"post",
					data:formDatad,
			                contentType: false,
			                processData: false,
			                mimeType: "multipart/form-data",
			                success: function (msg) {
			                  
							console.log(msg)
							imageurld=msg.data.imgurl;
							console.log(imageurld)
							
			                },
			                error: function (data) {
			                    console.log(data);
			                }
			            });
						
				}
			
			GETtechnicianid()
		function GETtechnicianid(){
			// localStorage .removeItem("TechnicianId");
			technicianid=localStorage.getItem("TechnicianIdSS")
		     console.log(technicianid)
		}
		
		
		
		
		
		
		if(parentidh=='undefined'){
			parentid="";
			parentidh="";
			parentidv="";
			parentidvh="";
			parentide="";
			address="";
			parentideh="请核实您的授课方式！"
		}
		if(parentidvh=='undefined'){
		parentid="";
		parentidh="";
		parentidv="";
		parentidvh="";
		parentide="";
		address="";
		parentideh="请核实您的授课方式！"
			
		}
		if(parentideh=="undefined"){
			parentid="";
			parentidh="";
			parentidv="";
			parentidvh="";
			parentide="";
			address="";
			parentideh="请核实您的授课方式！"
		}
		
		if(!parentidh){
			parentid="";
			parentidh="";
			parentidv="";
			parentidvh="";
			parentide="";
			address="";
			parentideh="请核实您的授课方式！"
		}
		if(!parentidvh){
		parentid="";
		parentidh="";
		parentidv="";
		parentidvh="";
		parentide="";
		address="";
		parentideh="请核实您的授课方式！"
			
		}
		if(!parentideh){
			parentid="";
			parentidh="";
			parentidv="";
			parentidvh="";
			parentide="";
			address="";
			parentideh="请核实您的授课方式！"
		}
		
		
		
			
			Myajax("userid","GET","http://manage.woyaoxuexue.com/guns/app/updatetechnicianinfo",
			{
				"technicianid":technicianid,
				"firstname":firstname,
				"secondname":secondname,
				"cardid":cardid,
				"cardpos":imageurla,
				"cardneg":imageurlb,
				"sex":sex,
				"skillid":skillid,
				"price":price,
				"title":title,
				"company":company,
				"teachplacetype":teachplacetype,
				"addprovincecode":parentid,
				"addprovincename":parentidh,
				"addcitycode":parentidv,
				"addcityname":parentidvh,
				"addareacode":parentide,
				"addareaname":parentideh,
				"address":address,
				"phone":phone,
				"photo":imageurlc,
				"introduction":introduction,
				"qualification":imageurld
			},100000,function(msg){
				var str=msg.responseText;
				var obja=eval("("+str+")");
				console.log(obja);
				console.log(userid);
				var code=obja.code;
				if(code=="100000"){
					alert("更新成功");
				}else{
					alert("更新失败")
				}
				
			},function(code){
				console.log(code.status);
			});
			}; 
			// $("#erroBtn").click(function(){
			// 	window.location.assign("../Join/jion.html");
			// })
			
			
			
			
			
			
			$("#erroBtn").click(function(){
				
					
					
						Myajax("P_Scoll","GET","http://manage.woyaoxuexue.com/guns/app/deletetechnician",
						{
							"userid":userid
						},1000,function(msg){
							location.href="../Good_tea/zhiye.html"
						},function(code){
							
						})
					
					return false
					dropid.cancelBubble=true;//取消冒泡
				
			})
		var userid;
		var imageurla;
		var imageurlb;
		var imageurlc;
		var imageurld;
		var addprovincenameValue;
		var addprovinceList;
		var addprovincecode;
		var addcitynameValue;
		var addcityList;
		var addcitycode;
		var parentidv;
		var parentid;
		var parentide;
		var parentidvh;
		var parentidh;
		var parentideh;
		var addareanameValue;
		var addareaList;
		var addareacode;
		var addprovincenameINNHTML;
		var addprovincename = document.getElementById("addprovincename");
		var ProvinceIDName=document.getElementsByClassName("ProvinceIDName")
		var addareaname = document.getElementById("addareaname")
		/* 省份地址 */
		getaddressProvince()
		function getaddressProvince() {
		Myajax("getaddressProvince","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
		{
			"parentid":100000,
			"leveltype":1,
		},100000,function(msg){
			var strq=msg.responseText;
			/* console.log(str); */
			var objc=eval("("+strq+")");
			/* console.log(objc); */
			addprovinceList=objc.data.length;
			for(var j=0;j<addprovinceList;j++){
			addprovincenameValue=objc.data[j].name;
			addprovincecode=objc.data[j].id
		/* console.log(addprovincecode); */
			/* console.log(addprovincenameValue); */
           addprovincenameINNHTML= "<option value=\""+addprovincecode+"\" class=\"ProvinceIDName\" >"+addprovincenameValue+"</option>";
			$("#addprovincename").append(addprovincenameINNHTML);
			/* console.log(ProvinceIDName[j].value) */
			}
			$("#addprovincename").change(function(){
		$("#addcityname").empty()
		parentid=$("#addprovincename").find("option:selected").val()
		parentidh=$("#addprovincename").find("option:selected").text()
		/* console.log(parentidh) */
			/* console.log(parentid) */
		GETaddcityname();
		
			})
		},function(code){
			console.log(code.status);
		})
		};
	
		/* 城市 */	
		
		function GETaddcityname(){
			Myajax("getaddCITYress","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
			{
				"parentid":parentid,
				"leveltype":2,
			},100000,function(msg){
				var strq=msg.responseText;
				// console.log(str);
				var objd=eval("("+strq+")");
				/* console.log(objd); */                                                    
				addcityList=objd.data.length;
				for(var j=0;j<addcityList;j++){
				addcitynameValue=objd.data[j].name;
				addcitycode=objd.data[j].id
		addcitynameINNHTML= "<option value=\""+addcitycode+"\">"+addcitynameValue+"</option>";
					$("#addcityname").append(addcitynameINNHTML);
				}
				parentidv=$("#addcityname").find("option:selected").val()
				parentidvh=$("#addcityname").find("option:selected").text()
				$("#addareaname").empty();
				GETaddarea();
				/* console.log(parentidvh) */
				$("#addcityname").change(function(){
				$("#addareaname").empty()
				parentidv=$("#addcityname").find("option:selected").val()
				parentidvh=$("#addcityname").find("option:selected").text()
				console.log(parentidvh)
				GETaddarea();
				
					})
				
			},function(code){
				console.log(code.status);
			})
		}
		/* 地区 */
		function GETaddarea(){
			Myajax("getaddAREAress","GET","http://manage.woyaoxuexue.com/guns/app/getarea",
			{
				"parentid":parentidv,
				"leveltype":3,
			},100000,function(msg){
				var stre=msg.responseText;
				// console.log(str);
				var obje=eval("("+stre+")");
				/* console.log(obje); */
				 /* console.log(str); */
				addareaList=obje.data.length;
				for(var j=0;j<addareaList;j++){
				addareanameValue=obje.data[j].name;
				addareacode=obje.data[j].id
		addareanameINNHTML= "<option value=\""+addareacode+"\">"+addareanameValue+"</option>";
					$("#addareaname").append(addareanameINNHTML);
				}
				parentide=$("#addareaname").find("option:selected").val()
				parentideh=$("#addareaname").find("option:selected").text()
				/* console.log(parentideh) */
				
				$("#addareaname").change(function(){
				parentide=$("#addareaname").find("option:selected").val()
				parentideh=$("#addareaname").find("option:selected").text()
				/* console.log(parentideh) */
				})
			},function(code){
				console.log(code.status);
			})
		}
		
			 
		  











/* jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj */
	GETUERID()
	function GETUERID(){
	    userid = localStorage.getItem("Userid");
	}
	var confirm=document.getElementById("confirm");
			confirm.onclick=function(){
				/* console.log(userid); */
				/* var REG=new RegExp("[a-zA-z]+://[^\s]*"); */
			var organizationname=document.getElementById("organizationname").value;
			var businesslicense=document.getElementById("uploadx").files[0];
			var address=document.getElementById("address").value;
			var introduction=document.getElementById("introduction").value;
			var characteristic=document.getElementById("characteristic").value;
			var curriculum=document.getElementById("curriculum").value;
			var organizationphoto1=document.getElementById("upload1").files[0];
			var organizationphoto2=document.getElementById("upload2").files[0];
			var organizationphoto3=document.getElementById("upload3").files[0];
			var teachernumber=document.getElementById("teachernumber").value;
			var websit=document.getElementById("websit").value;
			var linkman=document.getElementById("linkman").value;
			var phone=document.getElementById("phone").value;
			var email=document.getElementById("email").value;
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			/* headpicX=document.getElementById("upload").files[0]; */
			var formDataa = new FormData();
			formDataa.append('image', businesslicense);
			$.ajax({
					async:false,//同步，异步
					url:"http://101.37.12.157:8080/guns/app/uploadImg", //请求的服务端地址
					type:"post",
					data:formDataa,
			                contentType: false,
			                processData: false,
			                mimeType: "multipart/form-data",
			                success: function (msg) {
			                  
							console.log(msg)
							imageurla=msg.data.imgurl;
							console.log(imageurla)
							
			                },
			                error: function (data) {
			                    console.log(data);
			                }
			            });
						
						
						var formDatab = new FormData();
						formDatab.append('image', organizationphoto1);
						$.ajax({
								async:false,//同步，异步
								url:"http://101.37.12.157:8080/guns/app/uploadImg", //请求的服务端地址
								type:"post",
								data:formDatab,
						                contentType: false,
						                processData: false,
						                mimeType: "multipart/form-data",
						                success: function (msg) {
						                  
										console.log(msg)
										imageurlb=msg.data.imgurl;
										console.log(imageurlb)
										
						                },
						                error: function (data) {
						                    console.log(data);
						                }
						            });
									
									
									
									
									
									var formDatac = new FormData();
									formDatac.append('image', organizationphoto2);
									$.ajax({
											async:false,//同步，异步
											url:"http://101.37.12.157:8080/guns/app/uploadImg", //请求的服务端地址
											type:"post",
											data:formDatac,
									                contentType: false,
									                processData: false,
									                mimeType: "multipart/form-data",
									                success: function (msg) {
									                  
													console.log(msg)
													imageurlc=msg.data.imgurl;
													console.log(imageurlc)
													
									                },
									                error: function (data) {
									                    console.log(data);
									                }
									            });
						
						
						
						
						
						
						var formDatad = new FormData();
						formDatad.append('image', organizationphoto3);
						$.ajax({
								async:false,//同步，异步
								url:"http://101.37.12.157:8080/guns/app/uploadImg", //请求的服务端地址
								type:"post",
								data:formDatad,
						                contentType: false,
						                processData: false,
						                mimeType: "multipart/form-data",
						                success: function (msg) {
						                  
										console.log(msg)
										imageurld=msg.data.imgurl;
										console.log(imageurld)
										
						                },
						                error: function (data) {
						                    console.log(data);
						                }
						            });
												
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			Myajax("userid","GET","http://manage.woyaoxuexue.com/guns/app/joinxuexue",
			{
				"usertype":3,
				"userid":userid,
				"organizationname":organizationname,
				"businesslicense":imageurla,
				"introduction":introduction,
				"characteristic":characteristic,
				"curriculum":curriculum,
				"organizationphoto1":imageurlb,
				"organizationphoto2":imageurlc,
				"organizationphoto3":imageurld,
				"teachernumber":teachernumber,
				"addprovincecode":parentid,
				"addprovincename":parentidh,
				"addcitycode":parentidv,
				"addcityname":parentidvh,
				"addareacode":parentide,
				"addareaname":parentideh,
				"address":address,
				"websit":websit,
				"linkman":linkman,
				"phone":phone,
				"email":email
			},100000,function(msg){
				var str=msg.responseText;
				var obja=eval("("+str+")");
				console.log(obja);
				var msgoss=obja.msg;
				if(msgoss=="用户已加入学学"){
					alert(msgoss);
				}else if(msgoss=="用户加入失败！"){
					alert(msgoss);
				}else if(msgoss=="加入学学成功"){
					alert(msgoss+",信息变更，请重新登录");
					localStorage .removeItem("Userid");
					localStorage .removeItem("Useridx");
					localStorage .removeItem("userType");
					localStorage .removeItem("TecherId");
					localStorage .removeItem("TechnicianId");
					window.location.assign("../Mine/login.html");
				}
			},function(code){
				console.log(code.status);
			});
			}; 
	$("#erroBtn").click(function(){
		window.location.assign("../Join/jion.html");
	})
	
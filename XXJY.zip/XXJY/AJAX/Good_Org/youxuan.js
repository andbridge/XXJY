var id;
getOrgID()
function getOrgID(){
// 检索
    id = sessionStorage.getItem("OrgID");
	//id = Id;
	console.log(id);
 			getOrg();
}


function getOrg(){
	console.log("2");
	$.ajax({
			async:false,//同步，异步
			url:"http://manage.woyaoxuexue.com/guns/app/getyxjgdetail", //请求的服务端地址
			data:{
				"id":id,
			},
			type:"get",
			dataType:"json",
// 			beforeSend:function(){
// 			    $("#more").show();
// 			},
			
			success:function(data){
	            console.log(data)
				var curriculum = data.data.curriculum;
				if(curriculum==null){
					curriculum="暂无资料";
				}
				var characteristic = data.data.characteristic;
				if(characteristic==null){
					characteristic="暂无资料";
				}
				var introduction = data.data.introduction;
				if(introduction==null){
					introduction="暂无资料";
				}
				var organizationname = data.data.organizationname;
				if(organizationname==null){
					organizationname="暂无资料";
				}
				var teachernumber = data.data.teachernumber;
				if(teachernumber==null){
					teachernumber="暂无资料";
				}
				else
					teachernumber = teachernumber+"人";
				var address = data.data.address;
				if(address==null){
					address="暂无资料";
				}
				var ssq=data.data.ssq;
				if(ssq==null){
					ssq="暂无资料";
				}
				var mainOrg = "<div class=\"contenta\"><span><a href=\"\"><b>"+organizationname+"</b></a></span><br><span class=\"teachernum\"><b>教师数量：</b><span class=\"numbers\">"+teachernumber+"</span></span> <button type=\"button\" class=\"relation\"><a id=\"ONUrl\" ><img src=\"content/img/fixed_img/在线联系.jpg\" ></a></button><div class=\"map\"><a href=\"\"><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+ssq+"</span><br><span class=\"detail\">"+address+"</span></a></div></div><div class=\"contentb\"><h3>机构简介</h3><input type=\"text\" id=\"matter\" value=\""+introduction+"\" disabled=\"disabled\" /></div><div class=\"contentb\"><h3>机构特色</h3><input type=\"text\" id=\"matter\" value=\""+characteristic+"\" disabled=\"disabled\" /></div><div class=\"contentb\"><h3>课程设置</h3><input type=\"text\" id=\"matter\" value=\""+curriculum+"\" disabled=\"disabled\" /></div>";
// 				var mainOrg = "<span><a href=\"\"><b>"+organizationname+"</b></a></span><br><span class=\"teachernum\"><b>教师数量：</b><span class=\"numbers\">"+teachernumber+"人</span></span> <button type=\"button\" class=\"relation\"><a href=\"\"><img src=\"content/img/fixed_img/在线联系.png\" ><span class=\"relationFont\">在线联系</span></a></button><div class=\"map\"><a href=\"\"><img src=\"content/img/fixed_img/地点图标.png\" ><span>"+ssq+"</span><br><span class=\"detail\">"+address+"</span></a></div>";
// 				console.log(mainOrg);
// 				
// 				var a="<h3>机构简介</h3><input type=\"text\" id=\"matter\" value=\""+introduction+"\" disabled=\"disabled\" />";
// 				var b="<h3>机构特色</h3><input type=\"text\" id=\"matter\" value=\""+characteristic+"\" disabled=\"disabled\" />";
// 				var c="<h3>课程设置</h3><input type=\"text\" id=\"matter\" value=\""+curriculum+"\" disabled=\"disabled\" />";
// 				
				
				
				//console.log(mainOrg);
				
				$(".content").append(mainOrg);
				organizationphoto1=data.data.organizationphoto1;
				organizationphoto2=data.data.organizationphoto2;
				organizationphoto3=data.data.organizationphoto3;
				console.log(organizationphoto1)
				console.log(organizationphoto2)
				console.log(organizationphoto3)
				if(organizationphoto1 && organizationphoto2 && organizationphoto3){
					var bannerFourth=document.getElementById("bannerFourth")
					var bannerFirst=document.getElementById("bannerFirst")
					var bannerSecond=document.getElementById("bannerSecond")
					bannerFourth.src=organizationphoto1
					bannerFirst.src=organizationphoto1
					bannerSecond.src=organizationphoto1
				}else if(organizationphoto1 && organizationphoto2){
					var bannerFourth=document.getElementById("bannerFourth")
					var bannerFirst=document.getElementById("bannerFirst")
					bannerFourth.src=organizationphoto1
					bannerFirst.src=organizationphoto1
				}else if(organizationphoto1){
					var bannerFourth=document.getElementById("bannerFourth")
					bannerFourth.src=organizationphoto1
				}
				
				$("#ONUrl").click(function(){
					if(getCookie("userid","/")){
					 		 window.location.assign("../Index/chat.html");
					}else{
					 		 window.location.assign("../Mine/login.1.html")
					}
				})
				
				
				
				
				
			
	}
	});
};
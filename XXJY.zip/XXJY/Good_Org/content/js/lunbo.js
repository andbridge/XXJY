window.onload=function(){

    /* banner */
    var lunbotulist=document.getElementsByClassName("lunbotu");
    var list=document.getElementsByClassName("list");
    var index=0;
    for(var i=0;i < lunbotulist.length;i++){
        lunbotulist[i].className="lunbotu";
        list[i].style.background="whitesmoke";
    }
    lunbotulist[index].className= lunbotulist[index].className + " LboC"; /* 0 1 2 3 0 1 2 3 */
    list[index].style.background="#337ab7";

    var time=setInterval(function(){
        if(index < lunbotulist.length-1){
            index++; /*-1 0 1 2 0 1 2 */   /* index=++index��index=index++������*/
        }else{
            index=0; /* 0 0 */
        }
        for(var i=0;i < lunbotulist.length;i++){
            lunbotulist[i].className="lunbotu";
            list[i].style.background="whitesmoke";
        }
        lunbotulist[index].className= lunbotulist[index].className + " LboC"; /* 0 1 2 3 0 1 2 3 */
        list[index].style.background="#337ab7";
    },2000);

    for(var j=0;j<list.length;j++){


        list[j].num=j;

        list[j].onclick=function(){
            var x=this.num;
            for(var i=0;i < lunbotulist.length;i++){
                list[i].style.background="whitesmoke";
                lunbotulist[i].className="lunbotu";
            }
            list[x].style.backgroundColor="#337ab7";
            list[x]=lunbotulist[x].className=lunbotulist[x].className + " LboC";
        };
    }
};